import { useState, useEffect } from "react";

import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import { Helmet } from "react-helmet-async";
//react bootstrap
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Accordion from "react-bootstrap/Accordion";
import {purchaseHistory,purchaseHistoryDetails,purchaseHistoryItems} from "./core/_request"

const Orderlist = () => {

  const [purchaseList, setPurchaselist] = useState([])
  const [purchaseDetails, setPurchaseDetails] = useState([])
  const [purchaseItems, setPurchaseItems] = useState([])

  const purchareHis = async() =>{
    const orderhistry = await purchaseHistory()
    setPurchaselist(orderhistry.data)
    console.log("orde",orderhistry);
  }

  const purchareDetails = async(id) =>{
    const orderhistry = await purchaseHistoryDetails(id)
    setPurchaseDetails(orderhistry.data)
    console.log("orde",orderhistry);
  }
  const purchareItems = async(id) =>{
    const orderhistry = await purchaseHistoryItems(id)
    setPurchaseItems(orderhistry.data)
    console.log("purchaseItems",orderhistry);
  }

  useEffect(()=>{
  purchareHis();
  },[])

  return (
    <>
      <div className="contact-head head-fixed">
        <Header />
      </div>

      <div className="head-sm">
        <div className="d-flex justify-content-between">
          <div>
            <i className="fa fa-chevron-left"></i>
          </div>
          <div className="text-center">
            <span>Order List</span>
          </div>
          <div>
            <i className="fa fa-bell" aria-hidden="true"></i>
          </div>
        </div>
      </div>
      <div className="d-sm-none container position-relative mt-3">
        <input type='text' placeholder="Search..." className="rounded-pill " />
          <i className="fa fa-search searchButton position-absolute"></i>
      </div>

      {/* profile/Oder List  */}
      <section id="order-list">
        <div className="container">
          <h4 className="mb-5 mt-5 d-lg-block d-md-block d-none">
            <a href="#">Home</a> / <a href="#">Order List</a>
          </h4>
          <small className="d-lg-block d-md-block d-none">Showing 1 To 1</small>
          <div className="orderList"> 
          {
            purchaseList.length > 0 ?
              purchaseList.map((data,index) => {
                purchareItems(data.id);
                return(
                  <Accordion defaultActiveKey="0">
                  <Accordion.Item eventKey="0" className="mt-5 mb-5">
                    <Accordion.Header >
                      <Row>
                        <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
                          <div className="orderId ">
                            <span>Order ID:</span>
                            <h5 className="text-truncate">{data.code}</h5>
                          </div>
                        </Col>
                        <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
                          <div className="orderDate ">
                            <span>OrderDate:</span>
                            <h5>{data.date}</h5>
                          </div>
                        </Col>
                        <Col  xs="12" className="d-md-none d-flex justify-content-between lh-sm mb-2">
            
                          <div className="orderDate  ">
                            <span>OrderDate:</span>
                            <h5>{data.date}</h5>
                          </div>
                          <div className="orderId  overflow-hidden">
                            <span>Order ID:</span>
                            <h5>{data.code}</h5>
                          </div>
                          
                        </Col>
                        <Col lg="2" md="2">
                          <div className="orderTotal d-md-block d-none">
                            <span>OrderTotal:</span>
                            <h5>{data.grand_total}</h5>
                          </div>
                        </Col>
                        <Col lg="2" md="2" xs="4"  >
                          <img
                            src="/assets/img/images/image_2022_11_21T05_15_52_002Z.png"
                            className="  rounded mb-2"
                          />
                        </Col>
                        <Col xs="8" className="d-md-none overflow-hidden">
                          <span>Dinem Shirts</span>
                          <div className="d-flex ">
                                    <h5>{data.grand_total}</h5>
                                    <h5 className="text-decoration-line-through fw-light mx-1">
                                      ₹1,249.00
                                    </h5>
                                    <h5 className=" text-danger">(60%OFF)</h5>
                                  </div>
                          <span className="text-warning">{data.delivery_status_string}</span>
            
                        </Col>
                        <Col lg="4" md="4">
                          <button type="button" className="px-3 py-0 rounded d-md-block d-none">
                            <small>{data.delivery_status}</small>
                          </button>
                          <div className="d-md-flex d-none">
                            <div className="progress1 mx-2 "></div>
                            <div className="progress2 mx-2"></div>
                            <div className="progress2 mx-2"></div>
                            <div className="progress2 mx-2"></div>
                          </div>
                        </Col>
                      </Row>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div className="mt-4 mb-4">
                        <Row>
                          <Col md="3" sm="6" xs="12">
                            <div className="order-D">
                              <h4>Shipping Information:</h4>
                              <p className="mb-3">
                                Peter Paker Gangai Amman Kovil Street Virugambakkam
                                Chennai, Tamil Nadu 600092 India
                              </p>
                            </div>
                          </Col>
                          <Col md="3" sm="6" xs="12">
                            <div className="order-D">
                              <h4>Shipping Method:</h4>
                              <p className="mb-3">
                                Free Shipping - Free Waiting for tracking
                                information
                              </p>
                            </div>
                          </Col>
                          <Col md="3" sm="6" xs="12">
                            <div className="order-D">
                              <h4>Billing Infomation:</h4>
                              <p className="mb-3">
                                Peter Paker Gangai Amman Kovil Street Virugambakkam
                                Chennai, Tamil Nadu 600092 India
                              </p>
                            </div>
                          </Col>
                          <Col md="3" sm="6" xs="12">
                            <div className="order-D">
                              <h4>Payment Method:</h4>
                              <p className="mb-3">{data.payment_type}</p>
                            </div>
                          </Col>
                        </Row>
                        <Row className="mt-5">
                          <Col lg="7">
                            <div className="rounded shadow-sm order-items p-3">
                              <h4 className="fw-bold">Items</h4>
                              <Row>
                                <Col md="3" sm="6" xs="4">
                                  {" "}
                                  <img
                                    src="assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                                    className="rounded"
                                  />
                                </Col>
                                <Col md="3" sm="6" xs="8">
                                  <div>
                                    <h4>Dinem Shirts</h4>
                                    <h5>Color:<span className="bg-secondary mx-2 rounded-1 py-0 p-2"></span> </h5>
                                    <div className="row"><h5 className="col">Qty: <span>1</span></h5> 
                                    <h5 className="col d-md-inline d-none text-end">Size: <span>L</span></h5></div>
                                  </div>
                                </Col>
                                <Col md="6" sm="12" xs="12">
                                  <div className="d-flex  py-4">
                                    <h4>₹600.00</h4>
                                    <p className="text-decoration-line-through fw-light mx-3">
                                      ₹1,249.00
                                    </p>
                                    <h4 className="mx-3 text-danger">(60%OFF)</h4>
                                  </div>
                                </Col>
                              </Row>
                            </div>
                          </Col>
                          <Col lg="5">
                            <div className="rounded shadow-sm p-2">
                              <h4 className="fw-bold">Order Total:</h4>
                              <div className="d-flex justify-content-between">
                                <div className="text-start">
                                  <h4 className="fw-tight">Subtotal</h4>
                                  <h4 className="fw-tight">Tax</h4>
                                  <h4 className="fw-tight">Shipping</h4>
                                  <h4 className="fw-bold">Total</h4>
                                </div>
                                <div className="text-end ">
                                  <h4 className="fw-tight">{data.grand_total}</h4>
                                  <h4 className="fw-tight">₹ 0</h4>
                                  <h4 className="fw-tight">₹ 0</h4>
                                  <h4 className="fw-bold">{data.grand_total}</h4>
                                </div>
                              </div>
                            </div>
                          </Col>
                        </Row>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
                )
              }) :
     <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0" className="mt-5 mb-5">
        <Accordion.Header >
          <Row>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderId ">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderDate ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
            </Col>
            <Col  xs="12" className="d-md-none d-flex justify-content-between lh-sm mb-2">

              <div className="orderDate  ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
              <div className="orderId  overflow-hidden">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
              
            </Col>
            <Col lg="2" md="2">
              <div className="orderTotal d-md-block d-none">
                <span>OrderTotal:</span>
                <h5>₹ 600.00</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="4"  >
              <img
                src="/assets/img/images/image_2022_11_21T05_15_52_002Z.png"
                className="  rounded mb-2"
              />
            </Col>
            <Col xs="8" className="d-md-none overflow-hidden">
              <span>Dinem Shirts</span>
              <div className="d-flex ">
                        <h5>₹600.00</h5>
                        <h5 className="text-decoration-line-through fw-light mx-1">
                          ₹1,249.00
                        </h5>
                        <h5 className=" text-danger">(60%OFF)</h5>
                      </div>
              <span className="text-warning">Order Completed</span>

            </Col>
            <Col lg="4" md="4">
              <button type="button" className="px-3 py-0 rounded d-md-block d-none">
                <small>Processing</small>
              </button>
              <div className="d-md-flex d-none">
                <div className="progress1 mx-2 "></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
              </div>
            </Col>
          </Row>
        </Accordion.Header>
        <Accordion.Body>
          <div className="mt-4 mb-4">
            <Row>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Information:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Method:</h4>
                  <p className="mb-3">
                    Free Shipping - Free Waiting for tracking
                    information
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Billing Infomation:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Payment Method:</h4>
                  <p className="mb-3">Credit Card (Rupay)</p>
                </div>
              </Col>
            </Row>
            <Row className="mt-5">
              <Col lg="7">
                <div className="rounded shadow-sm order-items p-3">
                  <h4 className="fw-bold">Items</h4>
                  <Row>
                    <Col md="3" sm="6" xs="4">
                      {" "}
                      <img
                        src="assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                        className="rounded"
                      />
                    </Col>
                    <Col md="3" sm="6" xs="8">
                      <div>
                        <h4>Dinem Shirts</h4>
                        <h5>Color:<span className="bg-secondary mx-2 rounded-1 py-0 p-2"></span> </h5>
                        <div className="row"><h5 className="col">Qty: <span>1</span></h5> 
                        <h5 className="col d-md-inline d-none text-end">Size: <span>L</span></h5></div>
                      </div>
                    </Col>
                    <Col md="6" sm="12" xs="12">
                      <div className="d-flex  py-4">
                        <h4>₹600.00</h4>
                        <p className="text-decoration-line-through fw-light mx-3">
                          ₹1,249.00
                        </p>
                        <h4 className="mx-3 text-danger">(60%OFF)</h4>
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>
              <Col lg="5">
                <div className="rounded shadow-sm p-2">
                  <h4 className="fw-bold">Order Total:</h4>
                  <div className="d-flex justify-content-between">
                    <div className="text-start">
                      <h4 className="fw-tight">Subtotal</h4>
                      <h4 className="fw-tight">Tax</h4>
                      <h4 className="fw-tight">Shipping</h4>
                      <h4 className="fw-bold">Total</h4>
                    </div>
                    <div className="text-end ">
                      <h4 className="fw-tight">₹ 600.00</h4>
                      <h4 className="fw-tight">₹ 60</h4>
                      <h4 className="fw-tight">₹ 50</h4>
                      <h4 className="fw-bold">₹ 710.00</h4>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>
          }
          
          </div>
{/* {
  purchaseList.length == 0 ? 

  purchaseList.map((data,index) => {
    return(
      <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0" className="mt-5 mb-5">
        <Accordion.Header >
          <Row>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderId ">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderDate ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
            </Col>
            <Col  xs="12" className="d-md-none d-flex justify-content-between lh-sm mb-2">

              <div className="orderDate  ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
              <div className="orderId  overflow-hidden">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
              
            </Col>
            <Col lg="2" md="2">
              <div className="orderTotal d-md-block d-none">
                <span>OrderTotal:</span>
                <h5>₹ 600.00</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="4"  >
              <img
                src="/assets/img/images/image_2022_11_21T05_15_52_002Z.png"
                className="  rounded mb-2"
              />
            </Col>
            <Col xs="8" className="d-md-none overflow-hidden">
              <span>Dinem Shirts</span>
              <div className="d-flex ">
                        <h5>₹600.00</h5>
                        <h5 className="text-decoration-line-through fw-light mx-1">
                          ₹1,249.00
                        </h5>
                        <h5 className=" text-danger">(60%OFF)</h5>
                      </div>
              <span className="text-warning">Order Completed</span>

            </Col>
            <Col lg="4" md="4">
              <button type="button" className="px-3 py-0 rounded d-md-block d-none">
                <small>Processing</small>
              </button>
              <div className="d-md-flex d-none">
                <div className="progress1 mx-2 "></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
              </div>
            </Col>
          </Row>
        </Accordion.Header>
        <Accordion.Body>
          <div className="mt-4 mb-4">
            <Row>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Information:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Method:</h4>
                  <p className="mb-3">
                    Free Shipping - Free Waiting for tracking
                    information
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Billing Infomation:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Payment Method:</h4>
                  <p className="mb-3">Credit Card (Rupay)</p>
                </div>
              </Col>
            </Row>
            <Row className="mt-5">
              <Col lg="7">
                <div className="rounded shadow-sm order-items p-3">
                  <h4 className="fw-bold">Items</h4>
                  <Row>
                    <Col md="3" sm="6" xs="4">
                      {" "}
                      <img
                        src="assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                        className="rounded"
                      />
                    </Col>
                    <Col md="3" sm="6" xs="8">
                      <div>
                        <h4>Dinem Shirts</h4>
                        <h5>Color:<span className="bg-secondary mx-2 rounded-1 py-0 p-2"></span> </h5>
                        <div className="row"><h5 className="col">Qty: <span>1</span></h5> 
                        <h5 className="col d-md-inline d-none text-end">Size: <span>L</span></h5></div>
                      </div>
                    </Col>
                    <Col md="6" sm="12" xs="12">
                      <div className="d-flex  py-4">
                        <h4>₹600.00</h4>
                        <p className="text-decoration-line-through fw-light mx-3">
                          ₹1,249.00
                        </p>
                        <h4 className="mx-3 text-danger">(60%OFF)</h4>
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>
              <Col lg="5">
                <div className="rounded shadow-sm p-2">
                  <h4 className="fw-bold">Order Total:</h4>
                  <div className="d-flex justify-content-between">
                    <div className="text-start">
                      <h4 className="fw-tight">Subtotal</h4>
                      <h4 className="fw-tight">Tax</h4>
                      <h4 className="fw-tight">Shipping</h4>
                      <h4 className="fw-bold">Total</h4>
                    </div>
                    <div className="text-end ">
                      <h4 className="fw-tight">₹ 600.00</h4>
                      <h4 className="fw-tight">₹ 60</h4>
                      <h4 className="fw-tight">₹ 50</h4>
                      <h4 className="fw-bold">₹ 710.00</h4>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>
    )
  })

  :
  <div className="orderList">
  <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0" className="mt-5 mb-5">
        <Accordion.Header >
          <Row>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderId ">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderDate ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
            </Col>
            <Col  xs="12" className="d-md-none d-flex justify-content-between lh-sm mb-2">

              <div className="orderDate  ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
              <div className="orderId  overflow-hidden">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
              
            </Col>
            <Col lg="2" md="2">
              <div className="orderTotal d-md-block d-none">
                <span>OrderTotal:</span>
                <h5>₹ 600.00</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="4"  >
              <img
                src="/assets/img/images/image_2022_11_21T05_15_52_002Z.png"
                className="  rounded mb-2"
              />
            </Col>
            <Col xs="8" className="d-md-none overflow-hidden">
              <span>Dinem Shirts</span>
              <div className="d-flex ">
                        <h5>₹600.00</h5>
                        <h5 className="text-decoration-line-through fw-light mx-1">
                          ₹1,249.00
                        </h5>
                        <h5 className=" text-danger">(60%OFF)</h5>
                      </div>
              <span className="text-warning">Order Completed</span>

            </Col>
            <Col lg="4" md="4">
              <button type="button" className="px-3 py-0 rounded d-md-block d-none">
                <small>Processing</small>
              </button>
              <div className="d-md-flex d-none">
                <div className="progress1 mx-2 "></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
              </div>
            </Col>
          </Row>
        </Accordion.Header>
        <Accordion.Body>
          <div className="mt-4 mb-4">
            <Row>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Information:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Method:</h4>
                  <p className="mb-3">
                    Free Shipping - Free Waiting for tracking
                    information
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Billing Infomation:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Payment Method:</h4>
                  <p className="mb-3">Credit Card (Rupay)</p>
                </div>
              </Col>
            </Row>
            <Row className="mt-5">
              <Col lg="7">
                <div className="rounded shadow-sm order-items p-3">
                  <h4 className="fw-bold">Items</h4>
                  <Row>
                    <Col md="3" sm="6" xs="4">
                      {" "}
                      <img
                        src="assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                        className="rounded"
                      />
                    </Col>
                    <Col md="3" sm="6" xs="8">
                      <div>
                        <h4>Dinem Shirts</h4>
                        <h5>Color:<span className="bg-secondary mx-2 rounded-1 py-0 p-2"></span> </h5>
                        <div className="row"><h5 className="col">Qty: <span>1</span></h5> 
                        <h5 className="col d-md-inline d-none text-end">Size: <span>L</span></h5></div>
                      </div>
                    </Col>
                    <Col md="6" sm="12" xs="12">
                      <div className="d-flex  py-4">
                        <h4>₹600.00</h4>
                        <p className="text-decoration-line-through fw-light mx-3">
                          ₹1,249.00
                        </p>
                        <h4 className="mx-3 text-danger">(60%OFF)</h4>
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>
              <Col lg="5">
                <div className="rounded shadow-sm p-2">
                  <h4 className="fw-bold">Order Total:</h4>
                  <div className="d-flex justify-content-between">
                    <div className="text-start">
                      <h4 className="fw-tight">Subtotal</h4>
                      <h4 className="fw-tight">Tax</h4>
                      <h4 className="fw-tight">Shipping</h4>
                      <h4 className="fw-bold">Total</h4>
                    </div>
                    <div className="text-end ">
                      <h4 className="fw-tight">₹ 600.00</h4>
                      <h4 className="fw-tight">₹ 60</h4>
                      <h4 className="fw-tight">₹ 50</h4>
                      <h4 className="fw-bold">₹ 710.00</h4>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>

    <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0" className="mt-5 mb-5">
        <Accordion.Header >
          <Row>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderId ">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderDate ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
            </Col>
            <Col  xs="12" className="d-md-none d-flex justify-content-between lh-sm mb-2">

              <div className="orderDate  ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
              <div className="orderId  overflow-hidden">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
              
            </Col>
            <Col lg="2" md="2">
              <div className="orderTotal d-md-block d-none">
                <span>OrderTotal:</span>
                <h5>₹ 600.00</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="4"  >
              <img
                src="/assets/img/images/image_2022_11_21T05_15_52_002Z.png"
                className="  rounded mb-2"
              />
            </Col>
            <Col xs="8" className="d-md-none overflow-hidden">
              <span>Dinem Shirts</span>
              <div className="d-flex ">
                        <h5>₹600.00</h5>
                        <h5 className="text-decoration-line-through fw-light mx-1">
                          ₹1,249.00
                        </h5>
                        <h5 className=" text-danger">(60%OFF)</h5>
                      </div>
              <span className="text-warning">Order Completed</span>

            </Col>
            <Col lg="4" md="4">
              <button type="button" className="px-3 py-0 rounded d-md-block d-none">
                <small>Processing</small>
              </button>
              <div className="d-md-flex d-none">
                <div className="progress1 mx-2 "></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
              </div>
            </Col>
          </Row>
        </Accordion.Header>
        <Accordion.Body>
          <div className="mt-4 mb-4">
            <Row>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Information:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Method:</h4>
                  <p className="mb-3">
                    Free Shipping - Free Waiting for tracking
                    information
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Billing Infomation:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Payment Method:</h4>
                  <p className="mb-3">Credit Card (Rupay)</p>
                </div>
              </Col>
            </Row>
            <Row className="mt-5">
              <Col lg="7">
                <div className="rounded shadow-sm order-items p-3">
                  <h4 className="fw-bold">Items</h4>
                  <Row>
                    <Col md="3" sm="6" xs="4">
                      {" "}
                      <img
                        src="assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                        className="rounded"
                      />
                    </Col>
                    <Col md="3" sm="6" xs="8">
                      <div>
                        <h4>Dinem Shirts</h4>
                        <h5>Color:<span className="bg-secondary mx-2 rounded-1 py-0 p-2"></span> </h5>
                        <div className="row"><h5 className="col">Qty: <span>1</span></h5> 
                        <h5 className="col d-md-inline d-none text-end">Size: <span>L</span></h5></div>
                      </div>
                    </Col>
                    <Col md="6" sm="12" xs="12">
                      <div className="d-flex  py-4">
                        <h4>₹600.00</h4>
                        <p className="text-decoration-line-through fw-light mx-3">
                          ₹1,249.00
                        </p>
                        <h4 className="mx-3 text-danger">(60%OFF)</h4>
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>
              <Col lg="5">
                <div className="rounded shadow-sm p-2">
                  <h4 className="fw-bold">Order Total:</h4>
                  <div className="d-flex justify-content-between">
                    <div className="text-start">
                      <h4 className="fw-tight">Subtotal</h4>
                      <h4 className="fw-tight">Tax</h4>
                      <h4 className="fw-tight">Shipping</h4>
                      <h4 className="fw-bold">Total</h4>
                    </div>
                    <div className="text-end ">
                      <h4 className="fw-tight">₹ 600.00</h4>
                      <h4 className="fw-tight">₹ 60</h4>
                      <h4 className="fw-tight">₹ 50</h4>
                      <h4 className="fw-bold">₹ 710.00</h4>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>

    <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0" className="mt-5">
        <Accordion.Header >
          <Row>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderId ">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderDate ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
            </Col>
            <Col  xs="12" className="d-md-none d-flex justify-content-between lh-sm mb-2">

              <div className="orderDate  ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
              <div className="orderId  overflow-hidden">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
              
            </Col>
            <Col lg="2" md="2">
              <div className="orderTotal d-md-block d-none">
                <span>OrderTotal:</span>
                <h5>₹ 600.00</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="4"  >
              <img
                src="/assets/img/images/image_2022_11_21T05_15_52_002Z.png"
                className="  rounded mb-2"
              />
            </Col>
            <Col xs="8" className="d-md-none overflow-hidden">
              <span>Dinem Shirts</span>
              <div className="d-flex ">
                        <h5>₹600.00</h5>
                        <h5 className="text-decoration-line-through fw-light mx-1">
                          ₹1,249.00
                        </h5>
                        <h5 className=" text-danger">(60%OFF)</h5>
                      </div>
              <span className="text-warning">Order Completed</span>

            </Col>
            <Col lg="4" md="4">
              <button type="button" className="px-3 py-0 rounded d-md-block d-none">
                <small>Processing</small>
              </button>
              <div className="d-md-flex d-none">
                <div className="progress1 mx-2 "></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
              </div>
            </Col>
          </Row>
        </Accordion.Header>
        <Accordion.Body>
          <div className="mt-4 mb-4">
            <Row>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Information:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Method:</h4>
                  <p className="mb-3">
                    Free Shipping - Free Waiting for tracking
                    information
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Billing Infomation:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Payment Method:</h4>
                  <p className="mb-3">Credit Card (Rupay)</p>
                </div>
              </Col>
            </Row>
            <Row className="mt-5">
              <Col lg="7">
                <div className="rounded shadow-sm order-items p-3">
                  <h4 className="fw-bold">Items</h4>
                  <Row>
                    <Col md="3" sm="6" xs="4">
                      {" "}
                      <img
                        src="assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                        className="rounded"
                      />
                    </Col>
                    <Col md="3" sm="6" xs="8">
                      <div>
                        <h4>Dinem Shirts</h4>
                        <h5>Color:<span className="bg-secondary mx-2 rounded-1 py-0 p-2"></span> </h5>
                        <div className="row"><h5 className="col">Qty: <span>1</span></h5> 
                        <h5 className="col d-md-inline d-none text-end">Size: <span>L</span></h5></div>
                      </div>
                    </Col>
                    <Col md="6" sm="12" xs="12">
                      <div className="d-flex  py-4">
                        <h4>₹600.00</h4>
                        <p className="text-decoration-line-through fw-light mx-3">
                          ₹1,249.00
                        </p>
                        <h4 className="mx-3 text-danger">(60%OFF)</h4>
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>
              <Col lg="5">
                <div className="rounded shadow-sm p-2">
                  <h4 className="fw-bold">Order Total:</h4>
                  <div className="d-flex justify-content-between">
                    <div className="text-start">
                      <h4 className="fw-tight">Subtotal</h4>
                      <h4 className="fw-tight">Tax</h4>
                      <h4 className="fw-tight">Shipping</h4>
                      <h4 className="fw-bold">Total</h4>
                    </div>
                    <div className="text-end ">
                      <h4 className="fw-tight">₹ 600.00</h4>
                      <h4 className="fw-tight">₹ 60</h4>
                      <h4 className="fw-tight">₹ 50</h4>
                      <h4 className="fw-bold">₹ 710.00</h4>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>

    <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0" className="mt-5 mb-5">
        <Accordion.Header >
          <Row>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderId ">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderDate ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
            </Col>
            <Col  xs="12" className="d-md-none d-flex justify-content-between lh-sm mb-2">

              <div className="orderDate  ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
              <div className="orderId  overflow-hidden">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
              
            </Col>
            <Col lg="2" md="2">
              <div className="orderTotal d-md-block d-none">
                <span>OrderTotal:</span>
                <h5>₹ 600.00</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="4"  >
              <img
                src="/assets/img/images/image_2022_11_21T05_15_52_002Z.png"
                className="  rounded mb-2"
              />
            </Col>
            <Col xs="8" className="d-md-none overflow-hidden">
              <span>Dinem Shirts</span>
              <div className="d-flex ">
                        <h5>₹600.00</h5>
                        <h5 className="text-decoration-line-through fw-light mx-1">
                          ₹1,249.00
                        </h5>
                        <h5 className=" text-danger">(60%OFF)</h5>
                      </div>
              <span className="text-warning">Order Completed</span>

            </Col>
            <Col lg="4" md="4">
              <button type="button" className="px-3 py-0 rounded d-md-block d-none">
                <small>Processing</small>
              </button>
              <div className="d-md-flex d-none">
                <div className="progress1 mx-2 "></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
              </div>
            </Col>
          </Row>
        </Accordion.Header>
        <Accordion.Body>
          <div className="mt-4 mb-4">
            <Row>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Information:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Method:</h4>
                  <p className="mb-3">
                    Free Shipping - Free Waiting for tracking
                    information
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Billing Infomation:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Payment Method:</h4>
                  <p className="mb-3">Credit Card (Rupay)</p>
                </div>
              </Col>
            </Row>
            <Row className="mt-5">
              <Col lg="7">
                <div className="rounded shadow-sm order-items p-3">
                  <h4 className="fw-bold">Items</h4>
                  <Row>
                    <Col md="3" sm="6" xs="4">
                      {" "}
                      <img
                        src="assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                        className="rounded"
                      />
                    </Col>
                    <Col md="3" sm="6" xs="8">
                      <div>
                        <h4>Dinem Shirts</h4>
                        <h5>Color:<span className="bg-secondary mx-2 rounded-1 py-0 p-2"></span> </h5>
                        <div className="row"><h5 className="col">Qty: <span>1</span></h5> 
                        <h5 className="col d-md-inline d-none text-end">Size: <span>L</span></h5></div>
                      </div>
                    </Col>
                    <Col md="6" sm="12" xs="12">
                      <div className="d-flex  py-4">
                        <h4>₹600.00</h4>
                        <p className="text-decoration-line-through fw-light mx-3">
                          ₹1,249.00
                        </p>
                        <h4 className="mx-3 text-danger">(60%OFF)</h4>
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>
              <Col lg="5">
                <div className="rounded shadow-sm p-2">
                  <h4 className="fw-bold">Order Total:</h4>
                  <div className="d-flex justify-content-between">
                    <div className="text-start">
                      <h4 className="fw-tight">Subtotal</h4>
                      <h4 className="fw-tight">Tax</h4>
                      <h4 className="fw-tight">Shipping</h4>
                      <h4 className="fw-bold">Total</h4>
                    </div>
                    <div className="text-end ">
                      <h4 className="fw-tight">₹ 600.00</h4>
                      <h4 className="fw-tight">₹ 60</h4>
                      <h4 className="fw-tight">₹ 50</h4>
                      <h4 className="fw-bold">₹ 710.00</h4>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>

    <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0" className="mt-5 mb-5">
        <Accordion.Header >
          <Row>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderId ">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="6" className="d-md-block d-none ">
              <div className="orderDate ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
            </Col>
            <Col  xs="12" className="d-md-none d-flex justify-content-between lh-sm mb-2">

              <div className="orderDate  ">
                <span>OrderDate:</span>
                <h5>12 Auguest 2021</h5>
              </div>
              <div className="orderId  overflow-hidden">
                <span>Order ID:</span>
                <h5>INV97864644354</h5>
              </div>
              
            </Col>
            <Col lg="2" md="2">
              <div className="orderTotal d-md-block d-none">
                <span>OrderTotal:</span>
                <h5>₹ 600.00</h5>
              </div>
            </Col>
            <Col lg="2" md="2" xs="4"  >
              <img
                src="/assets/img/images/image_2022_11_21T05_15_52_002Z.png"
                className="  rounded mb-2"
              />
            </Col>
            <Col xs="8" className="d-md-none overflow-hidden">
              <span>Dinem Shirts</span>
              <div className="d-flex ">
                        <h5>₹600.00</h5>
                        <h5 className="text-decoration-line-through fw-light mx-1">
                          ₹1,249.00
                        </h5>
                        <h5 className=" text-danger">(60%OFF)</h5>
                      </div>
              <span className="text-warning">Order Completed</span>

            </Col>
            <Col lg="4" md="4">
              <button type="button" className="px-3 py-0 rounded d-md-block d-none">
                <small>Processing</small>
              </button>
              <div className="d-md-flex d-none">
                <div className="progress1 mx-2 "></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
                <div className="progress2 mx-2"></div>
              </div>
            </Col>
          </Row>
        </Accordion.Header>
        <Accordion.Body>
          <div className="mt-4 mb-4">
            <Row>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Information:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Shipping Method:</h4>
                  <p className="mb-3">
                    Free Shipping - Free Waiting for tracking
                    information
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Billing Infomation:</h4>
                  <p className="mb-3">
                    Peter Paker Gangai Amman Kovil Street Virugambakkam
                    Chennai, Tamil Nadu 600092 India
                  </p>
                </div>
              </Col>
              <Col md="3" sm="6" xs="12">
                <div className="order-D">
                  <h4>Payment Method:</h4>
                  <p className="mb-3">Credit Card (Rupay)</p>
                </div>
              </Col>
            </Row>
            <Row className="mt-5">
              <Col lg="7">
                <div className="rounded shadow-sm order-items p-3">
                  <h4 className="fw-bold">Items</h4>
                  <Row>
                    <Col md="3" sm="6" xs="4">
                      {" "}
                      <img
                        src="assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                        className="rounded"
                      />
                    </Col>
                    <Col md="3" sm="6" xs="8">
                      <div>
                        <h4>Dinem Shirts</h4>
                        <h5>Color:<span className="bg-secondary mx-2 rounded-1 py-0 p-2"></span> </h5>
                        <div className="row"><h5 className="col">Qty: <span>1</span></h5> 
                        <h5 className="col d-md-inline d-none text-end">Size: <span>L</span></h5></div>
                      </div>
                    </Col>
                    <Col md="6" sm="12" xs="12">
                      <div className="d-flex  py-4">
                        <h4>₹600.00</h4>
                        <p className="text-decoration-line-through fw-light mx-3">
                          ₹1,249.00
                        </p>
                        <h4 className="mx-3 text-danger">(60%OFF)</h4>
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>
              <Col lg="5">
                <div className="rounded shadow-sm p-2">
                  <h4 className="fw-bold">Order Total:</h4>
                  <div className="d-flex justify-content-between">
                    <div className="text-start">
                      <h4 className="fw-tight">Subtotal</h4>
                      <h4 className="fw-tight">Tax</h4>
                      <h4 className="fw-tight">Shipping</h4>
                      <h4 className="fw-bold">Total</h4>
                    </div>
                    <div className="text-end ">
                      <h4 className="fw-tight">₹ 600.00</h4>
                      <h4 className="fw-tight">₹ 60</h4>
                      <h4 className="fw-tight">₹ 50</h4>
                      <h4 className="fw-bold">₹ 710.00</h4>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>
  </div>
} */}
        </div>
      </section>

      <Footer />
    </>
  );
};

export default Orderlist;
