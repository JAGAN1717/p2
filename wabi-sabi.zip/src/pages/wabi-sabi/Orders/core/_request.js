import React from "react";
// Axios
import axios from "axios";

const API_URL = process.env.REACT_APP_WABI

export const PURCHASE_HISTRY_URL = `${API_URL}/purchase-history`
export const PURCHASE_HISTRY_DETAILS_URL = `${API_URL}/purchase-history`
export const  PURCHASE_HISTRY_ITEMS_URL = `${API_URL}/purchase-history-items`
export const  DELIVERY_INFO_URL = `${API_URL}/delivery-info`

const token = localStorage.getItem('token')
const config = {
    headers: { Authorization: `Bearer ${token}` }
};


// purchase history
export function purchaseHistory(){
    return axios.get(PURCHASE_HISTRY_URL,config)
    .then(response => response.data);
}

// purchase history Details
export function purchaseHistoryDetails(id){
    return axios.get(PURCHASE_HISTRY_DETAILS_URL + '/' + id,config)
    .then(response => response.data);
}

// purchase history items
export function purchaseHistoryItems(id){
    return axios.get(PURCHASE_HISTRY_ITEMS_URL + '/' + id,config)
    .then(response => response.data);
}
