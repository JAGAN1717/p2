import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "../Header/Header";
import Footer from "../Footer/Footer";

const OrderFailed = () => {
  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>

      <section id="orderFailed ">
        <div className="container">
          <div className="oderMsg row justify-content-center my-5">
            <div class="card p-5 col-lg-5 col-md-8 col-sm-10 shadow ">
              <div class="card-body text-center">
                <div className="wrong mb-3">
                  <i class="fa fa-times" aria-hidden="true"></i>
                </div>
                <h4 class="card-title">Failed</h4>
                <p className="text-center">
                  Unfortunately Your order was failed
                </p>
                <p class="card-text fw-light">
                  page while be automatically redirected to the main page (or)
                  click button below
                </p>
                <button type="button" className="btn btn-dark rounded">
                  back
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default OrderFailed;
