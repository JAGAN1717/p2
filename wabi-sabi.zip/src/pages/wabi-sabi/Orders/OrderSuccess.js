import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "../Header/Header";
import Footer from "../Footer/Footer";

const OrderSuccess = () => {
  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>

      <section id="orderSuccess ">
        <div className="container">
          <div className="oderMsg row justify-content-center my-5">
            <div class="card p-5 col-lg-5 col-md-8 col-sm-10 shadow ">
              <div class="card-body text-center">
                <div className="success mb-3">
                  <i class="fa fa-check" aria-hidden="true"></i>
                </div>
                <h4 class="card-title">THANK YOU FOR YOUR PURCHASE</h4>
                <p className="text-center">You order Number is : 00000872</p>
                <p class="card-text fw-light">
                  we'll email you an order confirmation with details and
                  tracking info
                </p>
                <button type="button" className="btn btn-dark rounded">
                  Continue Shopping
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default OrderSuccess;
