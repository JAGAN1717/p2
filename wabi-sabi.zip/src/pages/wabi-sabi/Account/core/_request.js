// Axios
import axios from "axios";

const API_URL = process.env.REACT_APP_WABI

export const UPDATE_PROFILE_URL = `${API_URL}/profile/update`

