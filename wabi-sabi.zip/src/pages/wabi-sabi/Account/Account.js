import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "../Header/Header";
import Footer from "../Footer/Footer";

const AccountInfo1 = () => {

  const [edit,setEdit] = useState();



  return (
    <>
      <div className="contact-head head-fixed">
        <Header />
      </div>

      <div className="head-sm mb-5">
        <div className="d-flex justify-content-between">
          <div>
            <i class="fa fa-chevron-left"></i>
          </div>
          <div className="text-center">
            <span>Account Information</span>
          </div>
          <div>
            <i className="fa fa-bell" aria-hidden="true"></i>
          </div>
        </div>
      </div>

      <section id="accountinfo">
        <div className="container">
          <h4 className="mb-5 mt-5 head-path1 d-lg-block d-md-block d-none">
            <a href="#">Home</a> / <a href="#">Profile</a> /{" "}
            <a href="#">Account Information</a>
          </h4>

          <h5 className="text-center d-lg-block d-md-block d-none">
            Account Information{" "}
          </h5>
          <div className="account-info  shadow rounded  mt-5">
            <form>
              <div className="row ">
                <div className="col-md-6 px-5">
                  <label className="form-label fw-bold">Name</label>
                  <input type="text" className="form-control mb-4" disabled={true}/>
                </div>
                <div className="col-md-6 px-5">
                  <label className="form-label fw-bold">City</label>
                  <input type="text" className="form-control mb-4" />
                </div>
              </div>
              <div className="row ">
                <div className="col-md-6 px-5">
                  <label className="form-label fw-bold">Email</label>
                  <input type="text" className="form-control mb-4" />
                </div>
                <div className="col-md-6 px-5">
                  <label className="form-label fw-bold">Country</label>
                  <input type="text" className="form-control mb-4" />
                </div>
              </div>
              <div className="row ">
                <div className="col-md-6 px-5">
                  <label className="form-label fw-bold">Date of Birth</label>
                  <input
                    type="text"
                    className="form-control mb-4"
                    aria-label="First name"
                  />
                </div>
                <div className="col-md-6 px-5">
                  <label className="form-label fw-bold">Zip Code</label>
                  <input type="text" className="form-control mb-4" />
                </div>
              </div>
              {
                edit ? 
                <div>
                <div className="row ">
                <div className="col-md-6 px-5">
                  <label className="form-label fw-bold">Old Password</label>
                  <input type="Password" className="form-control mb-4" />
                </div>
                <div className="col-md-6 px-5">
                  <label className="form-label fw-bold">Confirm Password</label>
                  <input type="Password" className="form-control mb-4" />
                </div>
              </div>
                <div className="text-center">
                <button type="button" className="mb-4" onClick={()=>setEdit(false)} >
                  SAVE
                </button>
              </div>
              </div>
              :
              <div>
              <div className="row ">
                <div className="col-md-6 px-5">
                  <label className="form-label fw-bold">Password</label>
                  <input type="Password" className="form-control mb-4" />
                </div>
              </div>
              <div className="text-center ">
                <button type="button" className="mb-4" onClick={()=>setEdit(true)}>
                  EDIT
                </button>
              </div>
              </div>
              }
            </form>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default AccountInfo1;
