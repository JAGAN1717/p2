import React from "react";
// Axios
import axios from "axios";

const API_URL = process.env.REACT_APP_WABI
// const API_URL  = 'http://192.168.1.4/wabi-sabi/api/v2'

export const FEATURED_URL = `${API_URL}/products/featured`
export const TODAYDEAL_URL = `${API_URL}/products/todays-deal`
export const BRAND_URL = `${API_URL}/brands`
export const CATEGORIES_URL = `${API_URL}/categories`

// feature products
export function getFeatured(pageNo){
    return axios.get(FEATURED_URL,{params:{page:pageNo}})
    .then(responce => responce.data)
}

// deal of day
export function getTodayDeal(){
    return axios.get(TODAYDEAL_URL)
    .then(responce => responce.data)
}

// brand
export function getBrand(){
    return axios.get(BRAND_URL)
    .then(response =>response.data)
}

// Categories API
export function getCategories(){
    return axios.get(CATEGORIES_URL)
    .then(response =>response.data)
}
