import { useEffect, useRef, useState } from "react";
import {testimonialsList} from "../core/_request";
import {getFeatured,getTodayDeal,getCategories,getBrand} from './core/_request'    

// font awesome
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faCoffee } from '@fortawesome/free-solid-svg-icons'

// antd icon
import { HeartOutlined, } from "@ant-design/icons";

//React bootstrap
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Card from "react-bootstrap/Card";

//axios
 import axios from "axios";

//swipper
import { Swiper, SwiperSlide,  } from "swiper/react";
import { FreeMode,Grid } from "swiper";
import { Pagination, Navigation } from "swiper";
import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/grid";
import "swiper/css/pagination";

import Slider from "react-slick";

import {useNavigate,Link } from "react-router-dom";

//carousal
import Carousel from "react-elastic-carousel";

//header nad footer
import Footer from "../Footer/Footer";
import Header from "../Header/Header";



// breakpoint
const breakpoints = [
  { width: 1, itemsToShow: 1 },
  { width: 550, itemsToShow: 2 },
  { width: 768, itemsToShow: 3 },
  { width: 1200, itemsToShow: 3 },
];



const HomeWabisabi = () => {

  const navigate = useNavigate();
console.log("jfjfjkbjk",process.env.REACT_APP_WABI);
  const [brand, setBrand] = useState([]);
  const [btnPre, setPrebtn] = useState(false);
  const [btnNxt, setNxtbtn] = useState(false);
  const swiperRef = useRef();
  const swiperRef2 = useRef();
  const swiperRef3 = useRef();
  const [category, setCategory] = useState([]);
  const [Trending, setTrending] = useState([]);
  const [deal, setDeal] = useState([]);
  const [pages, setPages] = useState(1);
  const[testmon,setTestmon] = useState([])


  
  const Categories = async() => {
      const clotheCategory = await getCategories()
      console.log("categories", clotheCategory);
      setCategory(clotheCategory.data)
  };



  
  const swipeNxt = () => {
    swiperRef2.current?.slideNext()
    swiperRef3.current?.slideNext()
    swiperRef.current?.slideNext();
    // featureProduct(2);
  }
  const swipePre = () => {
    swiperRef2.current?.slidePrev()
    swiperRef3.current?.slidePrev()
    swiperRef.current?.slidePrev()
    // featureProduct(1);
  }


  const Brand = async() => {
    // try {
    //   const url = process.env.REACT_APP_BRAND_API;
    //   axios.get(url).then((res) => {
    //     console.log("data", res.data.data);
    //     setBrand(res.data.data);
    //   });
    // } catch (error) {
    //   console.log("err", error.messages);
    // }
    const featureBrands = await getBrand()
    console.log('brand',featureBrands);
    setBrand(featureBrands.data)
  };

  const featureProduct = async(page) =>{
    const trending = await getFeatured(page)
    var trendingList = [];
    trendingList.push(trending.data)
    setTrending(trending.data);
    console.log('feart',trending.data)
  }

  const todayDeal = async() =>{
    const Todaydeal = await getTodayDeal()
    console.log('todatDeal',Todaydeal)
    setDeal(Todaydeal.data)
  }
 


  const TestimonialList = async() =>{
    const Testlist = await testimonialsList()
    console.log("testmonial",Testlist.data)
    setTestmon(Testlist.data)  
  }


  useEffect(() => {
    window.scrollTo(0, 0);
    Brand();
    Categories();
    featureProduct(pages);
    todayDeal();
    TestimonialList();
  }, []);

  return (
    <>
      <div className="head-fixed ">
        <Header />
      </div>
      {/* category section */}
      <section className="category-clothes mt-5">
        <div className="container">
          <div className="text-head">
            <Row className="d-md-none">
              <Col lg="3" md="3" sm="3" xs="3">
                <div className="d-flex ">
                  <img
                    src="/assets/img/Icons/Imported_Cloths.svg"
                    className="img-fuid"
                  />
                  <h4 className="word">Imported Clothes</h4>
                </div>
              </Col>
              <Col lg="3" md="3" sm="3" xs="3">
                <div className="d-flex ">
                  <img
                    src="/assets/img/Icons/Free_Shipping.svg"
                    className="img-fuid"
                  />
                  <h4 className="word">Free Shipping</h4>
                </div>
              </Col>
              <Col lg="3" md="3" sm="3" xs="3">
                <div className="d-flex ">
                  <img
                    src="/assets/img/Icons/Easy Return.svg"
                    className="img-fuid"
                  />
                  <h4 className="word">Easy Returns</h4>
                </div>
              </Col>
              <Col lg="3" md="3" sm="3" xs="3">
                <div className="d-flex">
                  <img
                    src="/assets/img/Icons/Quality Ass.svg"
                    className="img-fuid"
                  />
                  <h4 className="word">Quality Assuarance</h4>
                </div>
              </Col>
            </Row>
            <div className="d-md-flex d-none justify-content-between">
              <div className="d-flex">
                <img
                  src="/assets/img/Icons/Imported_Cloths.svg"
                  className="img-fluid"
                />
                <h4 className="word">
                  Imported
                  Clothes
                </h4>
              </div>
              <div className="d-flex ">
                <img src="/assets/img/Icons/Free_Shipping.svg" />
                <h4 className="word">
                  Free
                  Shipping
                </h4>
              </div>
              <div className="d-flex ">
                <img src="/assets/img/Icons/Easy Return.svg" />
                <h4 className="word">
                  Easy
                  Returns
                </h4>
              </div>
              <div className="d-flex">
                <img src="/assets/img/Icons/Quality Ass.svg" />
                <h4 className="word">
                  Quality
                  Assuarance
                </h4>
              </div>
            </div>
          </div>
          <div className="collection-i mt-5">
            <Row className=" row justify-content-md-center">
              <Col md="4" sm="4" xs="4" className="px-2">
                <div className="banner-grid1">
                  <img src="/assets/img/images/image_2022_11_21T05_15_03_256Z.png" />
                  <div className="callec-title1 ">
                    <h3>KIDS CORNER</h3>
                  </div>
                </div>
              </Col>
              <Col md="8" sm="8" xs="8" className="px-2">
                <div className="banner-grid2">
                  <img
                    src="/assets/img/images/image_2022_11_21T05_15_11_873Z.png"
                    className="img-fluid"
                  />
                  <div className="callec-title2">
                    <h3>SUSTAINABILITY</h3>
                  </div>
                </div>
              </Col>
            </Row>
            <Row className="mt-3">
              <Col lg="4" md="4" sm="4" xs="4" className="px-2 ">
                <div className="banner-grid3">
                  <img src="/assets/img/images/image_2022_11_21T05_15_15_581Z.png"  />
                  <div className="callec-title3">
                    <h3>BEST OF MEN</h3>
                  </div>
                </div>
              </Col>
              <Col lg="4" md="4" sm="4" xs="4" className="px-2">
                <div className="banner-grid4">
                  <img src="/assets/img/images/image_2022_11_21T05_15_18_958Z.png" />
                  <div className="callec-title3 text-truncate px-lg-0">
                    <h3>WOMEN COLLECTION</h3>
                  </div>
                </div>
              </Col>
              <Col lg="4" md="4" sm="4" xs="4" className="px-2">
                <div className="banner-grid5">
                  <img src="/assets/img/images/image_2022_11_21T05_15_21_895Z.png" />
                  <div className="callec-title3">
                    <h3>SELL WITH US</h3>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </section>

      {/* trending product */}
      <section className="trending-products ">
        <div className="container">
          <div className="trend-prod mt-5">
            <div className="text-center wabi-tittle pt-5">
              <h3>Trending Products</h3>
            </div>
            <div className="text-end d-lg-block d-none arr">
              <button
                onMouseOver={() => setPrebtn(true)}
                onMouseOut={() => setPrebtn(false)}
                onClick={() => swipePre()}
                className={`previous text-center ${
                  btnPre ? "shadow" : ""
                }  mx-2 text-dark`}
              >
                &#8249;
              </button>
              <button
                onMouseOver={() => setNxtbtn(true)}
                onMouseOut={() => setNxtbtn(false)}
                onClick={() => swipeNxt()}
                className={`next  ${btnNxt ? "shadow" : ""} mx-auto`}
              >
                &#8250;
              </button>
            </div> 

            <div className="d-none">
            <Swiper 
                    // grid={2}
                      // freeMode={true}
                      grabCursor={true}
                      // modules={[FreeMode]}
                      className="mySwipper1"
                      slidesPerView={5}
                      grid={{
                        rows:2,
                        fill:"row"
                      }}
                      modules={[Grid]}
                      //  loop={true}
                      onBeforeInit={(swiper) => {
                        swiperRef2.current = swiper;
                      }}
                      breakpoints={{
                        0: {
                          slidesPerView: 2,
                          spaceBetween: 10,
                        },
                        480: {
                          slidesPerView: 2,
                          spaceBetween: 10,
                        },
                        768: {
                          slidesPerView: 3,
                          spaceBetween: 15,
                        },
                        1024: {
                          slidesPerView: 4,
                          spaceBetween: 15,
                        },
                        1280: {
                          slidesPerView: 5,
                          spaceBetween: 0,
                        },
                      }}
                    >
                      <SwiperSlide>
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_33_181Z.png"
                            className="position-relative"
                          />
                          <div className="dress-color1 text-center rounded-circle  position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div>
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
                      <SwiperSlide>
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_35_946Z.png"
                            className="position-relative"
                          />
                          <div className="dress-color1 text-center rounded-circle  position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div>                 
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
                      <SwiperSlide>
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_38_928Z.png"
                            className="position-relative"
                          />
                          <div className="dress-color1 text-center rounded-circle position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div> 
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
                      <SwiperSlide>
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_41_505Z.png"
                            className="position-relative"
                          />
                          <div className="dress-color1 text-center rounded-circle  position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div>
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
                      <SwiperSlide>
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_44_210Z.png"
                            className="position-relative"
                          />
                         <div className="dress-color1 text-center rounded-circle  position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div>
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
            
                      <SwiperSlide>
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_46_879Z.png"
                            className="position-relative"
                          />
                          <div className="dress-color1 text-center rounded-circle  position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div> 
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
                      <SwiperSlide>
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_49_496Z.png"
                            className="position-relative"
                          />
                         <div className="dress-color1 text-center rounded-circle  position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div>
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
                      <SwiperSlide >
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_52_002Z.png"
                            className="position-relative"
                          />
                         <div className="dress-color1 text-center rounded-circle  position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div>
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
                      <SwiperSlide >
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_54_617Z.png"
                            className="position-relative"
                          />
                         <div className="dress-color1 text-center rounded-circle  position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div>
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
                      <SwiperSlide >
                        <Card id="card" className="shadow">
                          <Card.Img
                            variant="top"
                            src="/assets/img/images/image_2022_11_21T05_15_57_204Z.png"
                            className="position-relative"
                          />
                         <div className="dress-color1 text-center rounded-circle  position-absolute">
                            {" "}
                            <HeartOutlined class="fs-4 " />{" "}
                          </div>
                          <Card.Body className="text-center">
                            <h4>Zara Tops</h4>
                            <h4>$1000</h4>
                            <h4 className="text">Size-M</h4>
                          </Card.Body>
                        </Card>
                      </SwiperSlide>
           </Swiper>
            </div>

            <div className="d-none d-lg-block">
            <Swiper 
               freeMode={true}
               grabCursor={true}
               modules={[FreeMode]}
               className="mySwipper1 "
               loop={true}
               slidesPerView={5}
               onBeforeInit={(swiper) => {
                 swiperRef2.current = swiper;
               }}
               breakpoints={{
                 0: {
                   slidesPerView: 5/2,
                   spaceBetween: 10,
                 },
                 480: {
                   slidesPerView: 5/2,
                   spaceBetween: 10,
                 },
                 768: {
                   slidesPerView: 3,
                   spaceBetween: 15,
                 },
                 1024: {
                   slidesPerView: 4,
                   spaceBetween: 15,
                 },
                 1280: {
                   slidesPerView: 5,
                   spaceBetween: 0,
                 },
               }}
            >
                      {
                        Trending?.slice(0,5).map((data, index) => {
                          return (
                            <>
                              <SwiperSlide >
                              <Card id="card" className="shadow-sm" onClick={()=>navigate('/clotheinfo',{state:data})}>
                              <Card.Img
                                variant="top"
                                src={data.thumbnail_image }
                                className="position-relative"
                              />
                              <div className="dress-color1 text-center rounded-circle  position-absolute">
                                {" "}
                                <HeartOutlined class="fs-4 " />{" "}
                              </div>
                              <Card.Body className="text-center ">
                                <h4 className="text-truncate">{data.name}</h4>
                                <h4>{data.main_price}</h4>
                                <h4 className="text">Size-M</h4>
                              </Card.Body>
                            </Card>
                              </SwiperSlide>
                            </>
                          );
                        })
                      }
            </Swiper>

            <Swiper
              freeMode={true}
              grabCursor={true}
              modules={[FreeMode]}
              className="mySwipper2 pb-4 "
              loop={true}
              slidesPerView={5}
              onBeforeInit={(swiper) => {
                swiperRef3.current = swiper;
              }}
              breakpoints={{
                0: {
                  slidesPerView: 2/2,
                  spaceBetween: 10,
                },
                480: {
                  slidesPerView: 2,
                  spaceBetween: 10,
                },
                768: {
                  slidesPerView: 3,
                  spaceBetween: 15,
                },
                1024: {
                  slidesPerView: 4,
                  spaceBetween: 15,
                },
                1280: {
                  slidesPerView: 5,
                  spaceBetween: 0,
                },
              }}
            >
                      {
                        Trending?.slice(5,10).map((data, index) => {
                          return (
                            <>
                              <SwiperSlide >
                              <Card id="card" className="shadow-sm" onClick={()=>navigate('/clotheinfo',{state:data})}>
                              <Card.Img
                                variant="top"
                                src={data.thumbnail_image }
                                className="position-relative"
                              />
                              <div className="dress-color1 text-center rounded-circle  position-absolute">
                                {" "}
                                <HeartOutlined class="fs-4 " />{" "}
                              </div>
                              <Card.Body className="text-center ">
                                <h4 className="text-truncate">{data.name}</h4>
                                <h4>{data.main_price}</h4>
                                <h4 className="text">Size-M</h4>
                              </Card.Body>
                            </Card>
                              </SwiperSlide>
                            </>
                          );
                        })
                      }
            </Swiper>
            </div>

            <div className="d-block d-lg-none">
            <Swiper 
               freeMode={true}
               grabCursor={true}
               modules={[FreeMode]}
               className="mySwipper1 "
              //  loop={true}
               slidesPerView={5}
               onBeforeInit={(swiper) => {
                 swiperRef.current = swiper;
               }}
               breakpoints={{
                 0: {
                   slidesPerView: 5/2,
                   spaceBetween: 10,
                 },
                 480: {
                   slidesPerView: 5/2,
                   spaceBetween: 10,
                 },
                 768: {
                   slidesPerView: 3,
                   spaceBetween: 15,
                 },
                 1024: {
                   slidesPerView: 4,
                   spaceBetween: 15,
                 },
                 1280: {
                   slidesPerView: 5,
                   spaceBetween: 0,
                 },
               }}
            >
                      {
                        Trending?.map((data, index) => {
                          return (
                            <>
                              <SwiperSlide >
                              <Card id="card" className="shadow-sm" onClick={()=>navigate('/clotheinfo',{state:data})}>
                              <Card.Img
                                variant="top"
                                src={data.thumbnail_image }
                                className="position-relative"
                              />
                              <div className="dress-color1 text-center rounded-circle  position-absolute">
                                {" "}
                                <HeartOutlined class="fs-4 " />{" "}
                              </div>
                              <Card.Body className="text-center ">
                                <h4 className="text-truncate">{data.name}</h4>
                                <h4>{data.main_price}</h4>
                                <h4 className="text">Size-M</h4>
                              </Card.Body>
                            </Card>
                              </SwiperSlide>
                            </>
                          );
                        })
                      }
            </Swiper>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Brands  */}
      <section className="feature-Brand">
        <div className="container">
          <div className="wabi-tittle pt-5 py-3 ">
            <h3><Link to='/brand'>Feature Brands</Link></h3>
          </div>
          <Swiper
            freeMode={true}
            grabCursor={true}
            modules={[FreeMode]}
            className="mySwipper"
            breakpoints={{
              0: {
                slidesPerView: 5,
                spaceBetween: 20,
              },
              480: {
                slidesPerView: 5,
                spaceBetween: 15,
              },
              768: {
                slidesPerView: 6,
                spaceBetween: 15,
              },
              1024: {
                slidesPerView: 7,
                spaceBetween: 15,
              },
              1280: {
                slidesPerView: 7,
                spaceBetween: 15,
              },
            }}
          >
            {
            brand?
            brand.map((data, index) => {
              return (
                <>
                  <SwiperSlide onClick={()=> navigate('/clothes',{state:{'brandId':data.id}})}>
                    <div className="brand">
                      {" "}
                      <img src={data.logo} />
                    </div>
                  </SwiperSlide>
                </>
              );
            }) : 
            <SwiperSlide>
              <div className="brand">
                {" "}
                <img src="/assets/img/Icons/6.png" />
              </div>
            </SwiperSlide>
            }
          </Swiper>
        </div>
      </section>

      {/*Wabi Environmental impact   */}
      <section className="mt-5">
        <div className="container">
          <div className="wabi-env text-center">
            <div className="sabi-env">
              <i className="fa fa-recycle" aria-hidden="true"></i>
            </div>
            <h3>Wabi Sabi Environmental Impact</h3>
            <p>Recycle, Reuse, Reduce</p>
          </div>
        </div>
      </section>

      {/* Wabi  Sabi Environmental impact */}
      <section className="Envir-imp ">
        <div className="container">
          <div className="text-center wabi-tittle py-5">
            <h3>Wabi Sabi Environmental Impact</h3>
          </div>

          <div className="d-flex text-center">
            <div className="env">
              <img src="/assets/img/images/image_2022_11_21T05_16_05_471Z.png" />
              <div className="env-t text-center">
                <h4>10 MILES OF DRIVING EMISSION AVOIDED</h4>
              </div>
            </div>
            <div className="env">
              <img src="/assets/img/images/image_2022_11_21T05_16_08_567Z.png" />
              <div className="env-t text-center">
                <h4>3000 CLOTHES SAVED FROM BEING DUMPED INTO LANDFILLS</h4>
              </div>
            </div>
            <div className="env">
              <img src="/assets/img/images/image_2022_11_21T05_16_11_242Z.png" />
              <div className="env-t text-center">
                <h4>67 DAYS OF DRINKING WATER SAVED</h4>
              </div>
            </div>
            <div className="env">
              <img src="/assets/img/images/image_2022_11_21T05_16_14_160Z.png" />
              <div className="env-t text-center">
                <h4>40,000 CLOTHES RECYCLED TILL DATE</h4>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Wabi  Sabi Environmental impact 2*/}
      <section className="Envir-imp ">
        <div className="container">
          <div className="text-center wabi-tittle py-5 ">
            <h3>Wabi Sabi Environmental Impact</h3>
          </div>

          <div className="banner-env ">
            <div className="env2">
              <img src="/assets/img/images/image_2022_11_21T05_17_36_755Z.png" />
            </div>
          </div>
        </div>
      </section>

      {/* wind */}
      <section id="wnt">
        <div className="container wind mt-5">
          <Row className="pb-4">
            <Col lg="3" className="">
              <div className="text-center p-3 mt-4 wind-1">
              <img src="assets/img/images/env-1.png" className="env-img"/>
                <h4 className="fw-light">
                  {/* <i className="fa fa-tint"></i><br/>       */}
                  <span>67 </span> day of drinking water saved
                </h4>
              </div>
            </Col>
            <Col lg="3" className=" ">
              <div className="text-center p-3 mt-4 wind-1">
              <img src="assets/img/images/env-2.png" className="env-img"/>
                <h4 className="fw-light">
                  <span>3000</span> clothes being saved from dumped into
                  landfill
                </h4>
              </div>
            </Col>
            <Col lg="3" className="">
              <div className="text-center p-3 mt-4 wind-1 ">
              <img src="assets/img/images/env-3.png" className="env-img"/>
                <h4 className="fw-light">
                  {/* <i className="fa fa-cloud"/><br/> */}
                  <span>10.6</span> miles of driving emissions avoided
                </h4>
              </div>
            </Col>
            <Col lg="3" className="">
              <div className="text-center p-3 mt-4">
              <img src="assets/img/images/env-4.png" className="env-img"/>
                <h4 className="fw-light">
                  <span>723</span> days of powering an LED light prevented
                </h4>
              </div>
            </Col>
          </Row>
        </div>
      </section>

      {/* Deal of The Day */}
      <section className="deal-day ">
        <div className="container">
          <div className="deal ">
            <div className="text-center wabi-tittle pt-5">
              <h3>Deal Of The Day</h3>
            </div>

            <div className="text-end d-lg-block d-none arr">
              <button
                onMouseOver={() => setPrebtn(true)}
                onMouseOut={() => setPrebtn(false)}
                onClick={() => swiperRef.current?.slidePrev()}
                className={`previous text-center ${
                  btnPre ? "shadow" : ""
                }  mx-2 text-dark`}
              >
                &#8249;
              </button>
              <button
                onMouseOver={() => setNxtbtn(true)}
                onMouseOut={() => setNxtbtn(false)}
                onClick={() => swiperRef.current?.slideNext()}
                className={`next  ${btnNxt ? "shadow" : ""} mx-auto`}
              >
                &#8250;
              </button>
            </div>
            

            <Swiper
              freeMode={true}
              grabCursor={true}
              // modules={[FreeMode]}
              className="mySwipper2 "
              loop={true}
              // loopFillGroupWithBlank={true}
              // pagination={{
              //   clickable: true,
              // }}
              // navigation={true}
              // modules={[ Navigation]}
              slidesPerView={3}
              onBeforeInit={(swiper) => {
                swiperRef.current = swiper;
              }}
              breakpoints={{
                0: {
                  slidesPerView: 5/2,
                  spaceBetween: 5,
                },
                480: {
                  slidesPerView: 5/2,
                  spaceBetween: 10,
                },
                768: {
                  slidesPerView: 3,
                  spaceBetween: 15,
                },
                1024: {
                  slidesPerView: 4,
                  spaceBetween: 15,
                },
                1280: {
                  slidesPerView: 5,
                  spaceBetween: 0,
                },
              }}
            >
              {
                deal.map((data,key)=>{
                  return(
                    <SwiperSlide>
                    <Card id="card" className="shadow" onClick={()=>navigate('/clotheinfo',{state:data})}>
                      <Card.Img
                        variant="top"
                        src={data.thumbnail_image}
                        className="position-relative dealDay-img"
                      />
                      <div className="dress-color1 text-center rounded-circle  position-absolute">
                        {" "}
                        <HeartOutlined class="fs-4 " />
                      </div>
                      <Card.Body className="text-center " id='cardBody'>
                        <h4 className="text-truncate">{data.name}</h4>
                        <div className="d-flex align-items-center overflow-auto">
                        {data.main_price}
                          <small className="text-decoration-line-through fw-light mx-1">
                           {data.stroked_price}
                          </small>
                          <small className="text-danger">({data.discount})</small>
                        </div>
                        <h4 className="text">Size-M</h4>
                      </Card.Body>
                    </Card>
                  </SwiperSlide>
                  )
                })
              }
            </Swiper>
          </div>
        </div>
      </section>

      {/* popular Category */}
      <section className="popular-products">
        <div className="popular-cat">
          <div className="container mt-5">
            <div className="text-center wabi-tittle py-4">
              <h3><Link to="category">Popular Categories</Link></h3>
            </div>
            <div>
              {
                category ? 
                <Row className="justify-content-lg-center">
                  {
                     category.map((data,index)=>{
                                      return(
                                        <Col lg="2" md="3" sm="4" xs="4" className="mx-lg-3 mx-md-0"  onClick={()=> navigate('/clothes',{state:data})}>
                                         <div className="popular-items">
                                           <img src={data.banner} />
                                         </div>
                                         <h4 className="text-center mt-3 text-truncate">{data.name}</h4>
                                       </Col> 
                                      )
                                    })
                  }
               </Row>
                :
                <Row className="justify-content-md-center">
                <Col lg="2" md="2" sm="3" xs="3" className="mx-3">
                  <div className="popular-items">
                    <img src="/assets/img/images/1.png" />
                  </div>
                  <h4 className="text-center mt-3">MEN SHIRTS</h4>
                </Col>
                <Col lg="2" md="2" sm="3" xs="3" className="mx-3">
                  <div className="popular-items">
                    <img src="/assets/img/images/3.png" />
                  </div>
                  <h4 className="text-center mt-3">WOMEN JEANS</h4>
                </Col>
                <Col lg="2" md="2" sm="3" xs="3" className="mx-3">
                  <div className="popular-items">
                    <img src="/assets/img/images/2.png" />
                  </div>
                  <h4 className="text-center mt-3">WOMEN DRESSES</h4>
                </Col>
                <Col lg="2" md="2" sm="3" xs="3" className="mx-3">
                  <div className="popular-items">
                    <img src="/assets/img/images/4.png" />
                  </div>
                  <h4 className="text-center mt-3">KIDS UPPER</h4>
                </Col>
                <Col lg="2" md="2" className="mx-3 d-md-block d-none">
                  <div className="popular-items">
                    <img src="/assets/img/images/6.png" />
                  </div>
                  <h4 className="text-center mt-3">TOP BRAND</h4>
                </Col>
                <Col lg="2" md="2" sm="3" xs="3" className="mx-3">
                  <div className="popular-items ">
                    <img src="/assets/img/images/7.png" />
                  </div>
                  <h4 className="text-center mt-3">WOMEN BLOUSES</h4>
                </Col>
                <Col lg="2" md="2" sm="3" xs="3" className="mx-3">
                  <div className="popular-items">
                    <img src="/assets/img/images/8.png" />
                  </div>
                  <h4 className="text-center mt-3">WOMEN JEANS</h4>
                </Col>
                <Col lg="2" md="2" sm="3" xs="3" className="mx-3">
                  <div className="popular-items">
                    <img src="/assets/img/images/5.png" />
                  </div>
                  <h4 className="text-center mt-3">WOMEN DRESSES</h4>
                </Col>
                <Col lg="2" md="2" sm="3" xs="3" className="mx-3">
                  <div className="popular-items">
                    <img src="/assets/img/images/9.png" />
                  </div>
                  <h4 className="text-center mt-3">KIDS UPPER</h4>
                </Col>
                <Col lg="2" md="2" className="mx-3 d-md-block d-none">
                  <div className="popular-items">
                    <img src="/assets/img/images/10.png" />
                  </div>
                  <h4 className="text-center mt-3">TOP BRAND</h4>
                </Col>
              </Row>
              }
            </div>
          </div>
        </div>

        <div className="bulk-buy container ">
          <div className="position-relative">
              <img
                src="/assets/img/images/image_2022_12_16T08_56_24_717Z.png"
                className="img-fluid"
              />
            <div className="text-left bulk-buy-t">
              <h1>Looking to Buy in Bulk?</h1>
              <p>
                Lorem ipsum dolor sit amet. Ut quibusdam voluptas et aliquam
                aliquam aut sapiente magni. A magnam iure ut nisi maiores a
                explicabo consequatur. Sit ipsam soluta{" "}
              </p>
              <button type="button" className="btn btn-dark bulk-buy-b  ">
                BUY IN BULK
              </button>
            </div>
          </div>

          {/* <div className="div2">
             <img
                src="/assets/img/images/image_2022_12_16T08_56_24_717Z.png"
                className="w-100 h-100"
              />
              <div className="text-left col-5">
              <h1>Looking to Buy in Bulk?</h1>
              <p>
                Lorem ipsum dolor sit amet. Ut quibusdam voluptas et aliquam
                aliquam aut sapiente magni. A magnam iure ut nisi maiores a
                explicabo consequatur. Sit ipsam soluta{" "}
              </p>
              <button type="button" className="btn btn-dark bulk-buy-b  ">
                BUY IN BULK
              </button>
            </div>
          </div> */}
        </div>

        <div className="bulk-buy container d-none">
          <div className="position-relative">
              <img
                src="/assets/img/images/image_2022_12_16T08_56_24_717Z.png"
                className="img-fluid"
              />
            <div className="position-absolute start-50 top-0 mt-lg-5 ">
              <h1>Looking to Buy in Bulk?</h1>
              <p className="w-75">
                Lorem ipsum dolor sit amet. Ut quibusdam voluptas et aliquam
                aliquam aut sapiente magni. A magnam iure ut nisi maiores a
                explicabo consequatur. Sit ipsam soluta{" "}
              </p>
              <button type="button" className="btn btn-dark bulk-buy-b  ">
                BUY IN BULK
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Top pic of the seasion */}
      <section className="top-picks mt-5">
        <div className="container">
          <div className="text-center wabi-tittle py-5">
            <h3> Top Picks Of The Season</h3>
          </div>
          <Swiper
            freeMode={true}
            grabCursor={true}
            modules={[FreeMode]}
            className="mySwipper2"
            breakpoints={{
              0: {
                slidesPerView: 2,
                spaceBetween: 10,
              },
              480: {
                slidesPerView: 2,
                spaceBetween: 10,
              },
              768: {
                slidesPerView: 3,
                spaceBetween: 15,
              },
              1024: {
                slidesPerView: 4,
                spaceBetween: 15,
              },
              1280: {
                slidesPerView: 5,
                spaceBetween: 0,
              },
            }}
          >
            <SwiperSlide>
              <Card id="card-2" className="px-2">
                <Card.Img variant="top" src="/assets/img/images/Top-1.png" />
                <Card.Body className="text-center" id="card-body-2">
                  <h3 className="text-capitalize mx-4 complete1">
                    TOPS
                    UNDER X
                  </h3>
                </Card.Body>
              </Card>
            </SwiperSlide>
            <SwiperSlide>
              <Card id="card-2" className="px-2">
                <Card.Img variant="top" src="/assets/img/images/Top-2.png" />
                <Card.Body className="text-center" id="card-body-2">
                  <h3 className="mx-4 complete1">
                  SHIRTS
                  UNDER X
                  </h3>
                </Card.Body>
              </Card>
            </SwiperSlide>
            <SwiperSlide>
              <Card id="card-2" className="px-2">
                <Card.Img variant="top" src="/assets/img/images/Top-3.png" />
                <Card.Body className="text-center" id="card-body-2">
                <h3 className="mx-4 complete1">
                    JEANS
                    UNDER X
                  </h3>
                </Card.Body>
              </Card>
            </SwiperSlide>
            <SwiperSlide>
              <Card id="card-2" className="px-2">
                <Card.Img variant="top" src="/assets/img/images/Top-4.png" />
                <Card.Body className="text-center" id="card-body-2">
                <h3 className="mx-4 complete1">
                    T-SHIRT
                    UNDER X
                  </h3>
                </Card.Body>
              </Card>
            </SwiperSlide>
            <SwiperSlide>
              <Card id="card-2" className="px-2">
                <Card.Img variant="top" src="/assets/img/images/Top-5.png" />
                <Card.Body className="text-center" id="card-body-2">
                <h3 className="mx-4 complete1">
                    WINTER
                    UNDER X
                  </h3>
                </Card.Body>
              </Card>
            </SwiperSlide>
          </Swiper>

          <div className="d-flex justify-content-center mt-5 ">
            <div className="pic-buttons">
              <button type="button">BUY MORE</button>
            </div>
            <div className="pic-buttons mx-3">
              <button type="button">GUILT FREE</button>
            </div>
            <div className="pic-buttons">
              <button type="button">SHOP CONSCIOUS</button>
            </div>
          </div>
        </div>
      </section>

      {/* customer Testimonials  */}
      <section className="customer-test mt-5">
        <div className="container">
          <div className="text-center wabi-tittle py-5">
            <h3><Link to='/testimonial'>Customer Testimonials</Link></h3>
          </div>
          <div>
            <Swiper
              freeMode={true}
              grabCursor={true}
              pagination={{
                dynamicBullets: true,
              }}
              modules={[Pagination]}
              className="mySwipper2"
              breakpoints={{
                0: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                480: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                768: {
                  slidesPerView: 2,
                  spaceBetween: 15,
                },
                1024: {
                  slidesPerView: 3,
                  spaceBetween: 15,
                },
                1280: {
                  slidesPerView: 3,
                  spaceBetween: 10,
                },
              }}
            >
              {
               testmon ?
               testmon.map((data,key)=>{
                return(
                  <SwiperSlide>
                  <div className="card custom-card shadow-sm p-2 mb-5 bg-body rounded ">
                    <i className="fa fa-quote-left " aria-hidden="true"></i>
                    <img src={data.banner} className="mx-auto" />
                    <div className="card-body">
                      <h5 className="card-title text-center text-truncate">{data.short_description}</h5>
                      <p className="card-text complete text-center">
                        {data.description.replace( /(<([^>]+)>)/ig, '')}
                      </p>
                    </div>
                  </div>
                </SwiperSlide>
                )
               })
              : 
              <SwiperSlide>
              <div className="card custom-card shadow-sm p-2 mb-5 bg-body rounded ">
                <i className="fa fa-quote-left " aria-hidden="true"></i>
                <img src="/assets/img/logo/1.jpg" className="mx-auto" />
                <div className="card-body">
                  <h5 className="card-title text-center">EMMA WATSON</h5>
                  <p className="card-text text-center">
                    With supporting text below as a natural lead-in to
                    additional content. With supporting text below as a
                    natural lead-in
                  </p>
                </div>
              </div>
            </SwiperSlide>
              }
            </Swiper>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default HomeWabisabi;
