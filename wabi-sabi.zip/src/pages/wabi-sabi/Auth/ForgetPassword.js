import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Modal from "react-bootstrap/Modal";
import Row from "react-bootstrap/Row";
import {forgetPassword} from "./core/_request";
import axios from "axios";
import bootstrap from "bootstrap/dist/js/bootstrap.min";




const ForgetPassword = (props) => {
  const [email, setEmail] = useState("");
  const passwordRequest = async() =>{
    console.log('email',email)
    const passwordReq = await forgetPassword(email)
    console.log("pass",passwordReq)
    if(passwordReq){
      alert("code successfully send your mail.");
      var myModalEl = document.getElementById('exampleModalToggleLabel3');
      var modal = bootstrap.Modal.getInstance(myModalEl)
      modal.hide();
    }else{
      alert('mail id not valid!')
    }
  }

  return (
    <>
    <Container>
            <Row className="log2">
              <Col lg={5} md={5} sm="12" className="Log-mg">
                <img
                  src="/assets/img/Images/login_img-1.png"
                  alt="Log-mg"
                  className="img-fluid"
                />
              </Col>
              <Col lg={7} md={7} sm="12">
                <div className="text-center mt-4">
                  {" "}
                  <h2>WABI SABI</h2>
                  <span>Recover Password</span>{" "}
                </div>
                <form className="px-4">
                  <div className="mb-5">
                    <input
                      type="email"
                      name="email"
                      className="form-control mb-2"
                      placeholder="Enter you Email"
                      aria-describedby="emailHelp"
                      id="email"
                      onChange={(e) => setEmail(e.target.value)}
                    />
                    <small>
                      We will send the instruction to reset your password
                      through the email.
                    </small>
                  </div>
                  <button type="button" 
                  className="btn"
                  onClick={passwordRequest} 
                  data-bs-target="#exampleModalToggle4"
                  data-bs-toggle="modal"
                  >
                    RESET PASSWORD
                  </button>
                </form>
              </Col>
            </Row>
          </Container>
    </>
  );
};

export default ForgetPassword;
