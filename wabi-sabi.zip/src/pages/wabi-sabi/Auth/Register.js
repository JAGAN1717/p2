import React, { useState, useEffect } from "react";
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Modal from "react-bootstrap/Modal";
import Row from "react-bootstrap/Row";
import { useFormik } from "formik";
// import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import {register} from "./core/_request";
import bootstrap from "bootstrap/dist/js/bootstrap.min";




const Register = (props) => {
  const [show, setShow] = useState("password");
  const [firstname, setFirstname] = useState("");
  const [lastname, setlastname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function showpassword() {
    const type = show === "password" ? "text" : "password";
    setShow(type);
  }

  const initialValues = { username: "", LastName: "", email: "", password: "" };
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
  const [sign, setSign] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handleSubmit = async(e) => {
    e.preventDefault();
    setFormErrors(validate(formValues));
    setIsSubmit(true);

    let email = formValues.email
    let name = formValues.username 
    let password = formValues.password

    const Signin = await register(email,name,password)
    console.log('regis',Signin)
    setSign(Signin);
    var myModalEl = document.getElementById('exampleModalToggle2');
    var modal = bootstrap.Modal.getInstance(myModalEl)
    modal.hide();
  };

  useEffect(() => {
    console.log(formErrors);
    if (Object.keys(formErrors).length === 0 && isSubmit) {
      // console.log(formValues);
    }
  }, [formErrors]);
  const validate = (values) => {
    const errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.username) {
      errors.username = "Username is required!";
    }
    if (!values.LastName) {
      errors.LastName = "LastName is required!";
    }
    if (!values.email) {
      errors.email = "Email is required!";
    } else if (!regex.test(values.email)) {
      errors.email = "This is not a valid email format!";
    }
    if (!values.password) {
      errors.password = "Password is required";
    } else if (values.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    } else if (values.password.length > 10) {
      errors.password = "Password cannot exceed more than 10 characters";
    }
    return errors;
  };

  console.log("value", formValues);
  return (
    <>
          <Container>
            <Row className="log2">
              <Col lg={5} md={5} sm="12" className="Log-mg">
                <img
                  src="/assets/img/images/login_img-2.png"
                  alt="Log-mg"
                  className="img-fluid"
                />
              </Col>
              <Col lg={7} md={7} sm="12">
                <div className="text-center">
                  {" "}
                  <span>Sign-In To Your Account</span>{" "}
                </div>

                <form className="px-4" onSubmit={handleSubmit}>
                  <div className="mb-2">
                    <input
                      type="text"
                      name="username"
                      className="form-control"
                      placeholder="First Name"
                      value={formValues.username}
                      onChange={handleChange}
                      // onChange={(e) => setFirstname(e.target.value)}
                    />
                  </div>
                  <p>{formErrors.username}</p>
                  <div className="mb-2">
                    <input
                      type="text"
                      name="LastName"
                      className="form-control"
                      placeholder="Last Name"
                      value={formValues.LastName}
                      onChange={handleChange}

                      // onChange={(e) => setlastname(e.target.value)}
                    />
                  </div>
                  <p>{formErrors.LastName}</p>
                  <div className="mb-2">
                    <input
                      type="text"
                      name="email"
                      className="form-control"
                      placeholder="E Mail Address"
                      aria-describedby="emailHelp"
                      id="email"
                      // onChange={(e) => setEmail(e.target.value)}
                      value={formValues.email}
                      onChange={handleChange}
                    />
                  </div>
                  <p>{formErrors.email}</p>
                  <div className="mb-2">
                    <input
                      type={show}
                      className="form-control"
                      placeholder="password"
                      name="password"
                      id="password-field"
                      // onChange={(e) => setPassword(e.target.value)}
                      value={formValues.password}
                      onChange={handleChange}
                    />
                    <span
                      toggle="#password-field"
                      className="fa fa-fw fa-eye field-icon toggle-password"
                      onClick={() => showpassword()}
                    ></span>
                    <p>{formErrors.password}</p>
                  </div>
                  <div className="mb-3 form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="exampleCheck1"
                    />
                    <label className="form-check-label" for="exampleCheck1">
                      I agree to the terms and conditions
                    </label>
                  </div>
                  <div className="mb-3 form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="exampleCheck1"
                    />
                    <label className="form-check-label" for="exampleCheck1">
                      Subscribe for a New & Updates
                    </label>
                  </div>
                  <button type="submit" className="btn">
                    CREATE AN ACCOUNT
                  </button>
                </form>
                <div className="log-foot">
                  <div className="text-center mt-3">
                    <span>Or Continue With</span>
                    <span className="text-dark d-flex justify-content-center mt-4 ">
                      <div className="social2 text-center">
                        {" "}
                        <i className="fa fa-facebook"></i>
                      </div>
                      <div className="social2 text-center">
                        {" "}
                        <i className="fa fa-google" aria-hidden="true"></i>
                      </div>
                      <div className="social2 text-center">
                        {" "}
                        <i className="fa fa-instagram"></i>
                      </div>
                    </span>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
    </>
  );
};

export default Register;
