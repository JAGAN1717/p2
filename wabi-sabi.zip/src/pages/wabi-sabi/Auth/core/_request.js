import React from "react";
// Axios
import axios from "axios";

const API_URL = process.env.REACT_APP_WABI

export const SIGNIN_URL = `${API_URL}/auth/signup`
export const LOGIN_URL = `${API_URL}/auth/login`
export const FORGET_PASSWORD_URL = `${API_URL}/auth/password/forget_request`
export const CONFIRM_PASSWORD_URL = `${API_URL}/auth/password/confirm_reset`
export const RESEND_PASSWORD_URL = `${API_URL}/auth/password/resend_code`
export const CONFIRMCODE_URL = `${API_URL}/auth/confirm_code`


// auth
// Register Api
export function register(email,name,password){
    return axios.post(SIGNIN_URL,{
        register_by :"email",
        email_or_phone : email,
        name : name,
        password :password
    }).then(response => response.data)
}

// Login API
export function login(email,password){
    return axios.post(LOGIN_URL,{
        email,
        password,
    }).then(response =>response.data)
}

// forget password request
export function forgetPassword(email){
    return axios.post(FORGET_PASSWORD_URL,{
        send_code_by : "email",
        email_or_phone : email
        }).then(response => response.data)
}

// confirm password request
export function confirmPassword(code,password){
    return axios.post(CONFIRM_PASSWORD_URL,{
        verification_code :code ,
        password : password
        }).then(response => response.data)
}
