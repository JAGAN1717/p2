import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Modal from "react-bootstrap/Modal";
import Row from "react-bootstrap/Row";
import {confirmPassword} from "./core/_request";
import axios from "axios";
import bootstrap from "bootstrap/dist/js/bootstrap.min";




const ConfirmPassword = (props) => {
  const [password, setpassword] = useState("");
  const [ConfirmPassword, setconPassword] = useState("");
  const [code, setCode] = useState("");
  
  const passwordConfirm = async() => {
    console.log('password',password)
    if(password === ConfirmPassword){
        const verifyPassword = await confirmPassword(code,password);
        var myModalEl = document.getElementById('exampleModalToggle4');
        var modal = bootstrap.Modal.getInstance(myModalEl)
        modal.hide();
    }else{
        alert("password not same")
    }
  }

  return (
    <>
    <Container>
            <Row className="log2">
              <Col lg={5} md={5} sm="12" className="Log-mg">
                <img
                  src="/assets/img/Images/login_img-1.png"
                  alt="Log-mg"
                  className="img-fluid"
                />
              </Col>
              <Col lg={7} md={7} sm="12">
                <div className="text-center mt-2 ">
                  {" "}
                  <h2>WABI SABI</h2>
                  <span>Confirm Password</span>{" "}
                </div>
                <form className="px-4 ">
                  <div className="mb-5">
                    <input
                      type="text"
                      name="code"
                      className="form-control mb-2"
                      placeholder="Enter your OTP"
                      onChange={(e) => setCode(e.target.value)}
                    />
                    <input
                      type="password"
                      name="password"
                      className="form-control mb-2"
                      placeholder="New Password"
                      onChange={(e) => setpassword(e.target.value)}
                    />
                    <input
                      type="password"
                      name="confirm_password"
                      className="form-control mb-2"
                      placeholder="Confirm Password"
                      aria-describedby="emailHelp"
                      onChange={(e) => setconPassword(e.target.value)}
                    />
                    <a href="#" className="float-end ">Resend</a>
                  </div>
                  <button type="button" className="btn mt-2" onClick={passwordConfirm}>
                    CONFIRM PASSWORD
                  </button>
                </form>
              </Col>
            </Row>
          </Container>
    </>
  );
};

export default ConfirmPassword;
