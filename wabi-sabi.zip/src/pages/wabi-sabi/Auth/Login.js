import React, { useState, useEffect } from "react";

import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Modal from "react-bootstrap/Modal";
import Row from "react-bootstrap/Row";
import { useFormik } from "formik";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import {login} from "./core/_request";
import {getSocialLink} from '../Products/core/_request'
import Register from "./Register";
import ForgetPassword from "./ForgetPassword";
import bootstrap from "bootstrap/dist/js/bootstrap.min";

//swall
import swal from "sweetalert";

const Login = (props) => {
  const navigate = useNavigate();

  const [show, setShow] = useState("password");
  function showpassword() {
    const type = show === "password" ? "text" : "password";
    setShow(type);
  }

  const [Sociallink,setSocialLinks]=useState([])

  const SocilaLink = async() => {
    const links = await getSocialLink()
    console.log('Link2',links.data)
    setSocialLinks(links.data);
  }

  useEffect(() =>{
    SocilaLink();
  },[])

  const [logindata, setLogindata] = useState("");
  const [email, setEmail] = useState("sd");
  const [password, setPassword] = useState("");

  const [modalShow, setModalShow] = useState(false);
  const [modalShow2, setModalShow2] = useState(false);
  const [modalShow3, setModalShow3] = useState(false);

  const initialValues = { email: "", password: "" };
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handleSubmit = async(e) => {
    e.preventDefault();
    setFormErrors(validate(formValues));
    setIsSubmit(true);

    let email = formValues.email
    let password = formValues.password
    const userLogin = await login(email,password);
    setLogindata(userLogin.data);
    console.log("userLogin",userLogin);
    let token = userLogin.access_token
    let id = userLogin.user.id;
    let role = userLogin.user.type;
    localStorage.setItem("id", id);
    localStorage.setItem("role",role)
    localStorage.setItem("token",token)
    var myModalEl = document.getElementById('exampleModalToggle');
   var modal = bootstrap.Modal.getInstance(myModalEl)
   modal.hide();
   window.location.reload();
   document.getElementById('overAllcountData')?.click()
  };

  useEffect(() => {
    // console.log(formErrors);
    if (Object.keys(formErrors).length === 0 && isSubmit) {
      // console.log(formValues);
    }
  }, [formErrors]);
  
  const validate = (values) => {
    const errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.email) {
      errors.email = "Email is required!";
    } else if (!regex.test(values.email)) {
      errors.email = "This is not a valid email format!";
    }
    if (!values.password) {
      errors.password = "Password is required";
    }
    return errors;
  };

  return (
    <>
      <Container>
        <Row className="log2">
          <Col lg={5} md={5} sm="12" className="Log-mg">
            <img
              src="/assets/img/images/login_img-1.png"
              alt="Log-mg"
              className="img-fluid"
            />
          </Col>
          <Col lg={7} md={7} sm="12">
            <div className="text-center">
              {" "}
              <span>Sign-In To Your Account </span>{" "}
            </div>
            <form className="px-4" onSubmit={handleSubmit}>
              <div className="mb-4">
                <input
                  type="email"
                  name="email"
                  className="form-control"
                  placeholder="Enter you Email"
                  aria-describedby="emailHelp"
                  id="email"
                  // onChange={(e) => setEmail(e.target.value)}
                  value={formValues.email}
                  onChange={handleChange}
                />
                <p>{formErrors.email}</p>
              </div>

              <div className="mb-4">
                <input
                  type={show}
                  className="form-control"
                  placeholder="password"
                  name="password"
                  id="password-field"
                  // onChange={(e) => setPassword(e.target.value)}
                  value={formValues.password}
                  onChange={handleChange}
                />
                <span
                  toggle="#password-field"
                  className="fa fa-fw fa-eye field-icon toggle-password"
                  onClick={() => showpassword()}
                ></span>
                <p>{formErrors.password}</p>
              </div>
              <div className="mb-3 form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="exampleCheck1"
                />
                <label className="form-check-label" for="exampleCheck1">
                  Keep me Sign in
                </label>
              </div>
              <button type="submit" className="btn"
              // data-bs-dismiss="modal" aria-label="Close"
              >
                Login
              </button>
              <div className="text-end mt-2">
                <a
                  href="#"
                  data-bs-target="#exampleModalToggle3"
                  data-bs-toggle="modal"
                >
                  Forgot Password ?
                </a>
              </div>
            </form>
            <div className="log-foot">
              <div className="text-center mt-3 ">
                <span>Or Continue With</span>
                <span className="text-dark d-flex justify-content-center  mt-4 ">
                  <div className="social2 text-center mx-1">
                    {" "}
                    <i className="fa fa-facebook"></i>
                  </div>
                  <div className="social2 text-center  mx-1">
                    {" "}
                    <i className="fa fa-google" aria-hidden="true"></i>
                  </div>
                  <div className="social2 text-center mx-1">
                    {" "}
                    <i className="fa fa-instagram"></i>
                  </div>
                </span>
              </div>
              <div className="text-center mt-3" >
                <span>
                  Dont't Hav an account?{" "}
                  <a
                    href="#"
                    data-bs-target="#exampleModalToggle2"
                    data-bs-toggle="modal"
                  >
                    Signup
                  </a>
                </span>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      {/* 
      <Register show={modalShow2} onHide={() => setModalShow2(false)} />
      <ForgetPassword show={modalShow3} onHide={() => setModalShow3(false)} /> */}
    </>
  );
};

export default Login;
