import React from "react";
// Axios
import axios from "axios";

const API_URL = process.env.REACT_APP_WABI


export const SEARCH_URL = `${API_URL}/products/search`
export const MENUE_URL = `${API_URL}/business-settings/header_menu`
export const COUNTERS_URL = `${API_URL}/profile/counters`


const token = localStorage.getItem('token')
const config = {
    headers: { Authorization: `Bearer ${token}` }
};

let axioInstance = axios.create({
    headers : {
        Authorization : `Bearer ${token}`
    }
})

// search
export function search(name){
    return axios.get(SEARCH_URL,{params:{name}})
    .then(response => response.data);
}

// menu
export function getmenu(){
    return axios.get(MENUE_URL)
    .then(response => response.data);
}

// COUNTERS_URL
export function getCountList(){
    return axios.get(COUNTERS_URL,config)
    .then(response => response.data)
    .catch(err => console.log("err",err.message))
}