import React, { useState, useEffect } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import Modal from "react-bootstrap/Modal";
import Offcanvas from "react-bootstrap/Offcanvas";
import { search, getmenu, getCountList } from "./core/_request";
import { getSocialLink } from "../Products/core/_request";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { ReactSearchAutocomplete } from "react-search-autocomplete";

import Login from "../Auth/Login";
import Register from "../Auth/Register";
import ForgetPassword from "../Auth/ForgetPassword";
import ConfirmPassword from "../Auth/ConfirmPassword";

const Header = () => {
  const navigate = useNavigate();

  const [modalShow, setModalShow] = React.useState(false);
  const [modalShow2, setModalShow2] = useState(false);
  const [show, setShow] = useState(false);
  const [fullscreen, setFullscreen] = useState(true);
  const [searchName, setsearchName] = useState("");
  const [productList, setProductlist] = useState([]);
  const [menuLable, setMenuLable] = useState([]);
  const [menuLink, setMenuLink] = useState([]);
  const [menuValue, setValue] = useState([]);
  const initialValues = { nameSeach: "" };
  const [formValues, setFormValues] = useState(initialValues);
  const [Sociallink, setSocialLinks] = useState([]);
  const [counters, setCounters] = useState();

  const Search = async (name) => {
    const searchList = await search(name);
    console.log("search", searchList);
    // setProductlist(searchList.data);
    if (searchList) {
      navigate("/clothes", { state: searchList.data });
      window.location.reload();
    }
    // navigate('/clothes',{state:id})
  };
  console.log("searchName", formValues);

  const menubars = async () => {
    const menuLable = await getmenu();
    console.log("menu", menuLable.data);
    setMenuLable(menuLable.data.menu_labels);
    setMenuLink(menuLable.data.menu_links);
  };

  const searchSuggion = async () => {
    const searchList = await search();
    console.log("search23", searchList);
    // setProductlist(searchList.data);
    var productDropList = [];
    searchList.data.map((p, k) => {
      var data = { id: p.id, name: p.name };
      productDropList.push(data);
    });
    setProductlist(productDropList);
    console.log("sug", productDropList);
  };

  const SocilaLink = async () => {
    const links = await getSocialLink();
    console.log("Link2", links.data);
    setSocialLinks(links.data);
  };

  const Counts = async () => {
    const countData = await getCountList();
    setCounters(countData);
  };

  console.log("count", counters);

  useEffect(() => {
    // Search();
    menubars();
    SocilaLink();
    searchSuggion();
    Counts();
  }, []);

  function handleShow(breakpoint) {
    setFullscreen(breakpoint);
    setShow(true);
  }
  const handSubmit = (e) => {
    e.preventDefault();
    let name = formValues.nameSeach;
    Search(name);
  };

  const handleOnSearch = (string, results) => {
    console.log(string, results);
  };
  const handleOnHover = (result) => {
    console.log(result);
  };
  const handleOnFocus = () => {
    console.log("Focused");
  };
  const formatResult = (item) => {
    return (
      <>
        <span style={{ display: "block", textAlign: "left" }}>{item.name}</span>
      </>
    );
  };

  const mystyle = {
    padding: "0px",
    height: "35px",
    maxHeight: "300px",
    overflowY: "scroll",
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  return (
    <>
      <button
        type="button"
        id="overAllcountData"
        className="d-none"
        onClick={() => Counts()}
      ></button>
      <div className="">
        {/* header top */}
        <section className="heder-top ">
          <div className="head-top p-2 ">
            <div className="head-flex ">
              <div className="d-flex justify-content-between container">
                <div>
                  <span className="text-light">
                    <i className="fa fa-phone" aria-hidden="true"></i>{" "}
                    +919876543210
                  </span>
                </div>
                <div>
                  <span className="text-white">
                    get Up to 40% OFF New Session Style{" "}
                  </span>
                </div>
                <span className=" social-logo">
                  {Sociallink.slice(0, 3).map((data, index) => {
                    return (
                      <>
                        <i
                          className={`fa fa-${
                            data.type.split("_", 1)[0]
                          } text-center text-white mx-2`}
                          onClick={() => window.open(data.value, "_blank")}
                        ></i>
                      </>
                    );
                  })}
                </span>
              </div>
            </div>
          </div>
          <div className="head-sm ">
            <div className="d-flex justify-content-between">
              <div>
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="offcanvas"
                  data-bs-target="#offcanvasNavbar"
                  aria-controls="offcanvasNavbar"
                >
                  <i className="fa fa-bars" aria-hidden="true"></i>
                </button>
              </div>
              <div className="text-center">
                <span>WABI SABI</span>
              </div>
              <div>
                <a
                  data-bs-toggle="modal"
                  href="#exampleModalToggle"
                  role="button"
                ></a>
                <i
                  data-bs-toggle="modal"
                  href="#exampleModalToggle"
                  role="button"
                  className="fa fa-bell"
                  aria-hidden="true"
                  // onClick={() => setModalShow(true)}
                ></i>
              </div>
            </div>
          </div>
        </section>

        {/* header bottom navbar */}
        <header className="header-buttom">
          <div className="containe">
            <nav className="navbar navbar-expand-lg bg-light py-3 mb-3 shadow-sm">
              <div className="container">
                <a className="navbar-brand" id="nav-brand" href="#">
                  <Link to="/">
                    <img src="\assets\img\logo\WABI SABI LOGO 2.png" />
                  </Link>
                </a>
                <div
                  className="offcanvas offcanvas-end"
                  id="offcanvasNavbar"
                  aria-labelledby="offcanvasNavbarLabel"
                >
                  <div className="offcanvas-header">
                    <h5 className="offcanvas-title" id="offcanvasNavbarLabel">
                      {" "}
                      <a href="/">Wabi Sabi</a>
                    </h5>
                    <button
                      type="button"
                      className="btn-close"
                      data-bs-dismiss="offcanvas"
                      aria-label="Close"
                    ></button>
                  </div>
                  <div className="offcanvas-body">
                    <ul className="navbar-nav justify-content-start flex-grow-1 pe-3">
                      {menuLable.map((data, index) => {
                        return (
                          <>
                            <li
                              className="nav-item"
                              onClick={() => window.open(menuLink[index])}
                            >
                              <a
                                className="nav-link text-truncate"
                                id="navbarScrollingDropdown"
                                href="#"
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                              >
                                {data}
                              </a>
                            </li>
                            <div></div>
                          </>
                        );
                      })}
                    </ul>
                    {/* <ul className="navbar-nav justify-content-start flex-grow-1 pe-3">
                      <li className="nav-item dropdown">
                        <a
                          className="nav-link dropdown-toggle"
                          id="navbarScrollingDropdown"
                          href="#"
                          role="button"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                        >
                          Men
                        </a>
                        <ul className="dropdown-menu">
                          <li>
                            <a className="dropdown-item" href="#">
                              1
                            </a>
                          </li>
                          <li>
                            <a className="dropdown-item" href="#">
                              2
                            </a>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item dropdown">
                        <a
                          className="nav-link dropdown-toggle"
                          href="#"
                          role="button"
                          id="navbarScrollingDropdown"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                        >
                          Women
                        </a>
                        <ul className="dropdown-menu">
                          <li>
                            <a className="dropdown-item" href="#">
                              1
                            </a>
                          </li>
                          <li>
                            <a className="dropdown-item" href="#">
                              2
                            </a>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item dropdown">
                        <a
                          className="nav-link dropdown-toggle"
                          id="navbarScrollingDropdown"
                          href="#"
                          role="button"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                        >
                          Kids
                        </a>
                        <ul className="dropdown-menu">
                          <li>
                            <a className="dropdown-item" href="#">
                              1
                            </a>
                          </li>
                          <li>
                            <a className="dropdown-item" href="#">
                              2
                            </a>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item dropdown">
                        <a
                          className="nav-link dropdown-toggle"
                          id="navbarScrollingDropdown"
                          href="#"
                          role="button"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                        >
                          Homes & Livings
                        </a>
                        <ul className="dropdown-menu">
                          <li>
                            <a className="dropdown-item" href="#">
                              1
                            </a>
                          </li>
                          <li>
                            <a className="dropdown-item" href="#">
                              2
                            </a>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item dropdown">
                        <a
                          className="nav-link dropdown-toggle"
                          id="navbarScrollingDropdown"
                          href="#"
                          role="button"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                        >
                          Beauty
                        </a>
                        <ul className="dropdown-menu">
                          <li>
                            <a className="dropdown-item" href="#">
                              1
                            </a>
                          </li>
                          <li>
                            <a className="dropdown-item" href="#">
                              2
                            </a>
                          </li>
                          <li>
                            <hr className="dropdown-divider" />
                          </li>
                          <li>
                            <a className="dropdown-item" href="#">
                              3
                            </a>
                          </li>
                        </ul>
                      </li>
                    </ul> */}
                  </div>
                </div>
                <form onSubmit={handSubmit} className="d-flex serchbox">
                  <input
                    type="text"
                    placeholder="Search..."
                    name="nameSeach"
                    // onChange={(e)=>setsearchName(e.target.value)}
                    // value={formValues.nameSeach}
                    onChange={handleChange}
                  />
                  <button
                    type="submit"
                    className="searchButton"
                    // onClick={()=>Search()}
                  >
                    <i className="fa fa-search"></i>
                  </button>
                </form>
                {/* <div className="react-search">
                                        <ReactSearchAutocomplete
                                            items={productList}
                                            onSearch={handleOnSearch}
                                            onHover={handleOnHover}
                                            onSelect={(val) => Search(val.id)}
                                            onFocus={handleOnFocus}
                                            placeholder="Search.."
                                            styling={mystyle}
                                            autoFocus
                                            formatResult={formatResult}
                                        />  
                </div>                                       */}
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="offcanvas"
                  id="nav-toggle"
                  data-bs-target="#offcanvasNavbar"
                  aria-controls="offcanvasNavbar"
                >
                  <span className="navbar-toggler-icon"></span>
                </button>
                <div className="d-md-flex align-items-center sh-i d-none ">
                  {/* <i className='fa fa-heart mx-4'></i> */}
                  {localStorage.getItem("role") == "customer" ? (
                    <Link to="/wishlist" className="position-relative">
                      <i className="fa fa-heart mx-3" aria-hidden="true"></i>
                      {counters ? (
                        <span className="position-absolute top-0 start-100  translate-middle badge rounded-pill bg-dark pt-1 d-none d-md-block">
                          {/* {counters ? counters.wishlist_item_count : 0} */}
                          {counters.wishlist_item_count}
                          <span className="visually-hidden">New alerts</span>
                        </span>
                      ) : (
                        ""
                      )}
                    </Link>
                  ) : (
                    ""
                  )}
                  <Link to="/cart" className="position-relative">
                    {/* <i
                    className="fa fa-shopping-cart mx-3 "
                    aria-hidden="true"
                    ></i> */}
                    <img
                      src="assets/img/images/127.png"
                      className="nav-img mx-3"
                    />
                    {counters ? (
                      <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-dark pt-1 d-none d-md-block">
                        {/* { counters ? counters.cart_item_count : 0} */}
                        {counters.cart_item_count}
                        <span className="visually-hidden">New alerts</span>
                      </span>
                    ) : (
                      ""
                    )}
                  </Link>
                  <a
                    data-bs-toggle="modal"
                    href="#exampleModalToggle"
                    role="button"
                  >
                    <img
                      src="assets/img/images/128.png"
                      className="nav-img mx-3"
                    />
                    {/* <i
                    className="fa fa-user mx-3"
                    aria-hidden="true"
                    // onClick={() => setModalShow(true)}
                  ></i> */}
                  </a>
                </div>
              </div>
            </nav>
            <div className="d-none">
              {["lg"].map((expand) => (
                <Navbar
                  key={expand}
                  bg="light"
                  expand={expand}
                  className="mb-3"
                >
                  <Container fluid>
                    <Navbar.Brand href="#" id="nav-brand">
                      <img src="/assets/img/logo/WABI SABI LOGO 2.png" />
                    </Navbar.Brand>
                    <Navbar.Offcanvas
                      id={`offcanvasNavbar-expand-${expand}`}
                      aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
                      placement="end"
                    >
                      <Offcanvas.Header closeButton>
                        <Offcanvas.Title
                          id={`offcanvasNavbarLabel-expand-${expand}`}
                        >
                          Wabi Sabi
                        </Offcanvas.Title>
                      </Offcanvas.Header>
                      <Offcanvas.Body>
                        <Nav className="me-auto my-2 my-lg-0">
                          <NavDropdown title="Men" id="navbarScrollingDropdown">
                            <NavDropdown.Item href="#action3">
                              1
                            </NavDropdown.Item>
                            <NavDropdown.Item href="#action4">
                              2
                            </NavDropdown.Item>
                          </NavDropdown>
                          <NavDropdown
                            title="Women"
                            id="navbarScrollingDropdown"
                          >
                            <NavDropdown.Item href="#action3">
                              1
                            </NavDropdown.Item>
                            <NavDropdown.Item href="#action4">
                              2
                            </NavDropdown.Item>
                          </NavDropdown>
                          <NavDropdown
                            title="Kids"
                            id="navbarScrollingDropdown"
                          >
                            <NavDropdown.Item href="#action3">
                              1
                            </NavDropdown.Item>
                            <NavDropdown.Item href="#action4">
                              2
                            </NavDropdown.Item>
                          </NavDropdown>
                          <NavDropdown
                            title="Homes & Livings"
                            id="navbarScrollingDropdown"
                          >
                            <NavDropdown.Item href="#action3">
                              1
                            </NavDropdown.Item>
                            <NavDropdown.Item href="#action4">
                              2
                            </NavDropdown.Item>
                          </NavDropdown>
                          <NavDropdown
                            title="Beauty"
                            id="navbarScrollingDropdown"
                          >
                            <NavDropdown.Item href="#action3">
                              1
                            </NavDropdown.Item>
                            <NavDropdown.Item href="#action4">
                              2
                            </NavDropdown.Item>
                          </NavDropdown>
                        </Nav>
                      </Offcanvas.Body>
                    </Navbar.Offcanvas>

                    <div className="d-flex serchbox">
                      <input type="text" placeholder="Search..." />
                      <button type="submit" className="searchButton">
                        <i className="fa fa-search"></i>
                      </button>
                    </div>
                    <Navbar.Toggle
                      aria-controls={`offcanvasNavbar-expand-${expand}`}
                      id="nav-toggle"
                    />
                    <div className="d-flex sh-i">
                      {/* <i className='fa fa-heart mx-4'></i> */}
                      <i
                        className="fa fa-shopping-cart mx-4 "
                        aria-hidden="true"
                      ></i>
                      <i
                        className="fa fa-user mx-4"
                        aria-hidden="true"
                        onClick={() => setModalShow(true)}
                      ></i>
                    </div>
                  </Container>
                </Navbar>
              ))}
            </div>
          </div>
        </header>
      </div>

      {/* login */}
      <section>
        {/* <Login show={modalShow} onHide={() => setModalShow(false)} /> */}
        {/* <Register show={modalShow2} onHide={() => setModalShow2(false)} /> */}
      </section>

      <section>
        <div className="popup ">
          {/* Login */}
          <div
            className="modal fade"
            id="exampleModalToggle"
            aria-hidden="true"
            aria-labelledby="exampleModalToggleLabel"
            tabindex="-1"
          >
            <div className="modal-dialog modal-xl modal-dialog-centered modal-fullscreen-md-dowm">
              <div className="modal-content">
                <div className="modal-body px-2">
                  <div className="modal-header border border-0">
                    <div className="log1"></div>
                    <div className="log-2">
                      <button
                        type="button"
                        className="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                      ></button>
                    </div>
                  </div>
                  <Login />
                </div>
              </div>
            </div>
          </div>

          {/* Regidter */}
          <div
            className="modal fade"
            id="exampleModalToggle2"
            aria-hidden="true"
            aria-labelledby="exampleModalToggleLabel2"
            tabindex="-1"
          >
            <div className="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
              <div className="modal-content">
                <div className="modal-body">
                  <div className="modal-header border border-0">
                    <div className="log1"></div>
                    <div className="log-2">
                      <button
                        type="button"
                        className="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                      ></button>
                    </div>
                  </div>
                  <Register />
                </div>
              </div>
            </div>
          </div>

          {/* forget Password request */}
          <div
            className="modal fade"
            id="exampleModalToggle3"
            aria-hidden="true"
            aria-labelledby="exampleModalToggleLabel3"
            tabindex="-1"
          >
            <div className="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
              <div className="modal-content">
                <div className="modal-body">
                  <div className="modal-header border border-0">
                    <div className="log1"></div>
                    <div className="log-2">
                      <button
                        type="button"
                        className="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                      ></button>
                    </div>
                  </div>
                  <ForgetPassword />
                </div>
              </div>
            </div>
          </div>

          {/* confirm password verify */}
          <div
            className="modal fade"
            id="exampleModalToggle4"
            aria-hidden="true"
            aria-labelledby="exampleModalToggleLabel4"
            tabindex="-1"
          >
            <div className="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
              <div className="modal-content">
                <div className="modal-body">
                  <div className="modal-header border border-0">
                    <div className="log1"></div>
                    <div className="log-2">
                      <button
                        type="button"
                        className="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                      ></button>
                    </div>
                  </div>
                  <ConfirmPassword />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Header;
