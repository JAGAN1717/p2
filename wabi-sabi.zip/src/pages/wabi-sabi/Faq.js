import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "./Header/Header";
import Footer from "./Footer/Footer";

const Faq = () => {
  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>

      <section id="faq">
        <div className="container">
          <h5 className="mb-5 mt-5 head-path1 d-lg-block d-md-block d-none">
            <a href="#">Home</a> / <a href="#">Faq</a>
          </h5>
          <h4 className="text-center ">Frequently asked questions</h4>

          <div className="faq mt-3">
            <div class="accordion shadow mb-4" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                  <button
                    class="accordion-button "
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseOne1"
                    aria-expanded="true"
                    aria-controls="collapseOne"
                  >
                    what are the 3 type of e-commerce?
                  </button>
                </h2>
                <div
                  id="collapseOne1"
                  class="accordion-collapse collapse show"
                  aria-labelledby="headingOne"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body ">
                    <strong>This is the first item's accordion body.</strong> It
                    is shown by default, until the collapse plugin adds the
                    appropriate classes that we use to style each element. These
                    classes control the overall appearance, as well as the
                    showing and hiding via CSS transitions. You can modify any
                  </div>
                </div>
              </div>
            </div>

            <div class="accordion shadow mb-4" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                  <button
                    class="accordion-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseOne2"
                    aria-expanded="true"
                    aria-controls="collapseOne"
                  >
                    what E business means?
                  </button>
                </h2>
                <div
                  id="collapseOne2"
                  class="accordion-collapse collapse show"
                  aria-labelledby="headingOne"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <strong>This is the first item's accordion body.</strong> It
                    is shown by default, until the collapse plugin adds the
                    appropriate classes that we use to style each element. These
                    classes control the overall appearance, as well as the
                    showing and hiding via CSS transitions. You can modify any
                  </div>
                </div>
              </div>
            </div>

            <div class="accordion shadow mb-4" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                  <button
                    class="accordion-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseOne3"
                    aria-expanded="true"
                    aria-controls="collapseOne"
                  >
                    How do I start an ecommerce business?
                  </button>
                </h2>
                <div
                  id="collapseOne3"
                  class="accordion-collapse collapse show"
                  aria-labelledby="headingOne"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <strong>This is the first item's accordion body.</strong> It
                    is shown by default, until the collapse plugin adds the
                    appropriate classes that we use to style each element. These
                    classes control the overall appearance, as well as the
                    showing and hiding via CSS transitions. You can modify any
                  </div>
                </div>
              </div>
            </div>

            <div class="accordion shadow mb-4" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                  <button
                    class="accordion-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseOne4"
                    aria-expanded="true"
                    aria-controls="collapseOne"
                  >
                    what is e-commerce essay?
                  </button>
                </h2>
                <div
                  id="collapseOne4"
                  class="accordion-collapse collapse show"
                  aria-labelledby="headingOne"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <strong>This is the first item's accordion body.</strong> It
                    is shown by default, until the collapse plugin adds the
                    appropriate classes that we use to style each element. These
                    classes control the overall appearance, as well as the
                    showing and hiding via CSS transitions. You can modify any
                  </div>
                </div>
              </div>
            </div>

            <div class="accordion shadow mb-4" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                  <button
                    class="accordion-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseOne5"
                    aria-expanded="true"
                    aria-controls="collapseOne"
                  >
                    what is ecommerce risk?
                  </button>
                </h2>
                <div
                  id="collapseOne5"
                  class="accordion-collapse collapse show"
                  aria-labelledby="headingOne"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <strong>This is the first item's accordion body.</strong> It
                    is shown by default, until the collapse plugin adds the
                    appropriate classes that we use to style each element. These
                    classes control the overall appearance, as well as the
                    showing and hiding via CSS transitions. You can modify any
                  </div>
                </div>
              </div>
            </div>

            <div class="accordion shadow mb-4" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                  <button
                    class="accordion-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseOne6"
                    aria-expanded="true"
                    aria-controls="collapseOne"
                  >
                    what is ecommerce business and its advantages?
                  </button>
                </h2>
                <div
                  id="collapseOne6"
                  class="accordion-collapse collapse show"
                  aria-labelledby="headingOne"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <strong>This is the first item's accordion body.</strong> It
                    is shown by default, until the collapse plugin adds the
                    appropriate classes that we use to style each element. These
                    classes control the overall appearance, as well as the
                    showing and hiding via CSS transitions. You can modify any
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Faq;
