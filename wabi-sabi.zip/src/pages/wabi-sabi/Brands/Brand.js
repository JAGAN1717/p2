import React, { useState, useEffect } from "react";
import axios from "axios";
import {getBrand} from "../core/_request";

import Header from "../Header/Header";
import Footer from "../Footer/Footer";

import { Alert, Space, Spin } from "antd";
import {useNavigate,Link } from "react-router-dom";

//React bootstrap
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

const Brand = () => {
  const navigate = useNavigate();

  const [brand, setBrand] = useState([]);

  const Brands = async() => {
        const clotheBrands = await getBrand()
        console.log("data", clotheBrands)
        setBrand(clotheBrands.data);
    };

    useEffect(() => {
      Brands();
    }, []);

  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>

      <section id="brand-1">
        <div className="container mb-5">
          <h4 className="mb-5 mt-5 head-path1">
            <a href="#">Home</a> / <a href="#">Brand</a>
          </h4>
          <div className="feature-Brand">
            <Row>
              {   brand.length > 0 ? (
                          brand.map((data, index) => {
                            return(<>
                          <Col lg='2' md='2' sm='2' xs='2' className="mx-3">
                          <div className="brand mb-5"onClick={()=> navigate('/clothes',{state:{'brandId':data.id}})} > 
                          <img src={data.logo}/></div>
                          </Col>
                            </>)
                          })
                          )
                          :
                          (
                        <div className="spin-h">
                        <Spin tip="Loading" size="large">
                          <div className="content" />
                        </Spin>
                        </div>
                        )
                    }
                    <div className="d-none">
                    <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
              <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
              <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
              <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
              <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
              <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
              <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
              <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
              <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
              <Col lg="2" md="2" sm="2" xs="2" className="mx-3">
                <div className="brand mb-5">
                  {" "}
                  <img src="/assets/img/Icons/6.png" />
                </div>
              </Col>
                    </div>
            </Row>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default Brand;
