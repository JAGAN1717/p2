import React from "react";
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Card from "react-bootstrap/Card";
import {testimonialsList} from "./core/_request"
import { Alert, Space, Spin } from 'antd';


import Header from "./Header/Header";
import Footer from "./Footer/Footer";
import { useState } from "react";
import { useEffect } from "react";

const Testimonial = () => {
  const[testmon,setTestmon] = useState([])

  const TestimonialList = async() =>{
    const Testlist = await testimonialsList()
    console.log("testmonial",Testlist.data)
    setTestmon(Testlist.data)  
  }

  useEffect(() =>{
    TestimonialList();
  },[])

  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>
      <section id="test-mon">
        <div className="container testmon">
          <h4 className="mb-5 mt-5 head-path1">
            <a href="#">Home</a> / <a href="#">Testimonial</a>
          </h4>
          <h4 className="mb-5 head-path2 text-center">
            <a href="#">Testimonial</a>
          </h4>
          <Row>
            {
              testmon ? 
              testmon.map((data,index)=>{
                return(
                  <Col lg="3" md="4" sm="6" xs="6">
                  <div className="card custom-card shadow mb-4">
                    <i className="fa fa-quote-left " aria-hidden="true"></i>
                    <img
                      src={data.banner}
                      className="mx-auto img-fluid"
                    />
                    <div className="card-body">
                      <h5 className="card-title text-center text-truncate">{data.short_description}</h5>
                      <p className="card-text text-center complete fw-light">
                      {data.description.replace( /(<([^>]+)>)/ig, '')}
                      </p>
                    </div>
                  </div>
                </Col> 
                )
              })
            :
          //   <Col lg="3" md="4" sm="6" xs="6">
          //   <div className="card custom-card shadow mb-4">
          //     <i className="fa fa-quote-left " aria-hidden="true"></i>
          //     <img
          //       src="/assets/img/logo/1.jpg"
          //       className="mx-auto img-fluid"
          //     />
          //     <div className="card-body">
          //       <h5 className="card-title text-center">EMMA WATSON</h5>
          //       <p className="card-text text-center fw-light">
          //         With supporting text below as a natural lead-in to
          //         additional content. With supporting text below as a natural
          //         lead-in
          //       </p>
          //     </div>
          //   </div>
          // </Col>
          <Spin tip="Loading" size="large">
          <div className="content" />
        </Spin>
            }
          </Row>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Testimonial;
