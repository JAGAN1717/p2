import React from "react";
// Axios
import axios from "axios";

const API_URL = process.env.REACT_APP_WABI


export const ALLPRODUCTS_URL = `${API_URL}/products`
export const PRODUCT_URL = `${API_URL}/products/category`
export const FILTER_CATEGORY_URL = `${API_URL}/filter/categories`   
export const FILTER_BRAND_URL = `${API_URL}/filter/brands`   
export const RELATED_URL = `${API_URL}/products/related`
export const IMG_URL = `${API_URL}/products`
export const SOCIALLINK_URL = `${API_URL}/business-settings/social_links`
export const BRAND_PRODUCT_URL = `${API_URL}/products/brand`
export const ADD_CART_URL = `${API_URL}/carts/add`
export const ADD_WISHLISTS_URL = `${API_URL}/wishlists-add-product`

const token = localStorage.getItem('token')
const config = {
    headers: { Authorization: `Bearer ${token}` }
};

// filter category
export function getAllproducts(pageNo){
    return axios.get(ALLPRODUCTS_URL,{params:{page:pageNo}})
    .then(responce => responce.data)
}

// product?category
export function getproducts(categoryId){
    return axios.get(PRODUCT_URL + '/' +categoryId)
    .then(responce => responce.data)
}

// filter category
export function filterCategory(){
    return axios.get(FILTER_CATEGORY_URL)
    .then(responce => responce.data)
}

// filter brands
export function filterBrands(){
    return axios.get(FILTER_BRAND_URL)
    .then(responce => responce.data)
}

// realated products
export function getRelatedproducts(id){
    return axios.get(RELATED_URL + '/' + id)
    .then(responce => responce.data)
}

// product variant images
export function getVariantImg(id){
    return axios.get(IMG_URL + '/' + id)
    .then(responce => responce.data)
}

export function getIndProduct(id){
    return axios.get(IMG_URL + '/' + id)
    .then(responce => responce.data)
}

// social Link
export function getSocialLink(){
    return axios.get(SOCIALLINK_URL)
    .then(responce => responce.data)
}

// BRANDS BASSED PRODUCT
export function getBarndedproducts(id){
    return axios.get(BRAND_PRODUCT_URL + '/' + id)
    .then(responce => responce.data)
}

// add to cart
export function addToCat(id,vari,qnt){
    return axios.post(ADD_CART_URL,{
        id,
   variant:vari,
  quantity:qnt
    },config)
    .then(responce => responce.data)
}

// add to cart
export function addWishlists(id){
    return axios.post(ADD_WISHLISTS_URL,{
        product_id:id
    },config)
    .then(responce => responce.data)
}
