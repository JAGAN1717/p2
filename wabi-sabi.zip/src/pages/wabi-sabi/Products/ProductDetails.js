import React, { useEffect, useRef, useState } from "react";

import Header from "../Header/Header";
import Footer from "../Footer/Footer";

//react bootstrap
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Card from "react-bootstrap/Card";
import { useLocation, useNavigate } from "react-router-dom";
import {
  getRelatedproducts,
  getVariantImg,
  getSocialLink,
  addToCat,
  addWishlists
} from "./core/_request";
import { ToastContainer, toast } from 'react-toastify';
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Navigation, Controller } from "swiper";
import { FreeMode } from "swiper";
import "swiper/css";
import "swiper/css/free-mode";

// antd icon
import { HeartOutlined } from "@ant-design/icons";
//carousal
import Carousel from "react-elastic-carousel";

// breakpoint
const breakpoints = [
  { width: 1, itemsToShow: 1 },
  { width: 550, itemsToShow: 1 },
  { width: 768, itemsToShow: 1 },
  { width: 1200, itemsToShow: 1 },
];
const ProductDetails = () => {
  const navigate = useNavigate();
  const { state } = useLocation();

  const [btnPre, setPrebtn] = useState(false);
  const [btnNxt, setNxtbtn] = useState(false);
  const swiperRef = useRef();

  console.log("state", state);
  const [product, setProduct] = useState(state);
  const [related, setRelated] = useState([]);
  const [variantPic, setVariantPic] = useState([]);
  const [desc, setDes] = useState("");
  const [Sociallink, setSocialLinks] = useState([]);
  const [cartMsg, setcartMsg] = useState([]);
  const [qnt, setQnt] = useState(1);
  const [price,setPrice] = useState();

  const addQnt = () => {
    let val = qnt + 1;
    setQnt(val);
    let Rs = product.main_price.replace(/[^\d @ $/.]/g, '')
    console.log("price1",parseInt(Rs) * val)
    let total = parseInt(Rs) * val
    setPrice(total)
  };
  const decQnt = () => {
    let Rs = product.main_price.replace(/[^\d @ $/.]/g, '')
    console.log("price1",parseInt(price) )
    let total = parseInt(price) - parseInt(Rs)
    let val = qnt - 1;
    if (val < 1 ) val = 1;
    setQnt(val);
    setPrice(total)
  };

  const pagination = {
    clickable: true,
    // renderBullet: function (index, className) {
    //   return '<span class="' + className + '">' + "</span>";
    // },
  };

  const detailpage = (data) => {
    navigate("/clotheinfo", { state: data });
    window.location.reload();
  };

  const RelatedProduct = async () => {
    console.log("id", product.id);
    let id = product.id;
    const relatedprod = await getRelatedproducts(id);
    console.log("related", relatedprod.data);
    setRelated(relatedprod.data);
  };

  const addTocart = async () => {
    console.log("id", product.id);
    let id = product.id;
    const addCart = await addToCat(id, "", 1);
    console.log("cart", addCart);
    toast.success(addCart.message, {
      position: toast.POSITION.BOTTOM_RIGHT
  });
  document.getElementById('overAllcountData')?.click()
  };

  const AddWisglist = async () => {
    console.log("id", product.id);
    let id = product.id;
    const Wishlists = await addWishlists(id);
    console.log("wishlist", Wishlists);
    toast.success('SUCCESSFULLY ADDED!', {
      position: toast.POSITION.BOTTOM_RIGHT
  });
  document.getElementById('overAllcountData')?.click()
  };

  const variantImg = async () => {
    let id = product.id;
    const photo = await getVariantImg(id);
    console.log("photoe", photo.data);

    photo.data.map((res) => {
      setDes(res);
      setVariantPic(res.photos);
      //  res.photos.map((pic)=>{
      //   console.log("photoee",pic.path);
      //  })
    });
  };
  console.log("photoe222", desc);

  const SocilaLink = async () => {
    const links = await getSocialLink();
    console.log("Link", links.data);
    setSocialLinks(links.data);
  };

  useEffect(() => {
    RelatedProduct();
    variantImg();
    SocilaLink();
    window.scrollTo(0, 0);
  }, []);

  console.log("ddddddd",desc.description)
  return (
    <>
      <div className="head-fixed d-sm-block d-none">
        <Header />
      </div>

      <div className="product-details">
        <section id="product-details">
          <div className="container">
            <div className="productDetails">
              <h4 className="mb-2 mt-5 pd-tittle">
                <a href="#">Home</a> / <a href="#">Clothing</a> /{" "}
                <a href="#">Men Clothing</a> / <a href="#">T shirts</a> /{" "}
                <a href="#">U.S POLO</a>
              </h4>      <ToastContainer />
              {product ? (
                <div className="product-1 mt-5">
                  <Row>
                    <Col lg="2" className="d-none d-lg-block ">
                      {variantPic.slice(0, 4).map((photos,index) => {
                        return (
                          <div className="p-view mx-3  rounded text-center  ">
                            <img
                              src={photos.path}
                              className={`img-fluid rounded ${index === 0 ? 'active' : ''}`}
                              data-bs-target="#carouselExampleCaptions"
                              aria-current={`${index === 0 ? 'true' : ''}`}
                              data-bs-slide-to={index}
                              aria-label={`Slide ${index+1}`}
                            />
                          </div>
                        );
                      })}
                    </Col>
                    <Col lg="5" md="6">
                      <div className="p-mg rounded mb-3 d-none">
                        <img src={product.thumbnail_image} />
                      </div>
                      <div className="d-block d-lg-none">
                      <Swiper
                        freeMode={true}
                        grabCursor={true}
                        // pagination={{
                        //   dynamicBullets: true,
                        //   // bulletActiveClass:""
                        // }}
                        // modules={[Pagination]}
                        pagination={pagination}
                        modules={[Pagination]}
                        className="mySwipper2 "
                        breakpoints={{
                          0: {
                            slidesPerView: 1,
                            spaceBetween: 10,
                          },
                          480: {
                            slidesPerView: 1,
                            spaceBetween: 10,
                          },
                          768: {
                            slidesPerView: 1,
                            spaceBetween: 15,
                          },
                          1024: {
                            slidesPerView: 1,
                            spaceBetween: 15,
                          },
                          1280: {
                            slidesPerView: 1,
                            spaceBetween: 0,
                          },
                        }}
                      >
                        {variantPic.slice(0, 4).map((photos) => {
                          return (
                            <SwiperSlide>
                              <div className="p-mg mb-3 ">
                                <img
                                  src={photos.path}
                                  className="position-relative card-img-top rounded-3"
                                />
                                <div className="dress-color2 bg-white rounded text-center position-absolute">
                                  {" "}
                                  <HeartOutlined class="fs-4" />{" "}
                                </div>
                                <div className="position-absolute top-0 p-3 d-sm-none">
                                  <i class="fa fa-chevron-left fs-3"></i>
                                </div>
                              </div>
                            </SwiperSlide>
                          );
                        })}
                      </Swiper>
                      </div>
                      <div
                        id="carouselExampleCaptions"
                        class="carousel slide d-none d-lg-block"
                        data-bs-ride="false"
                      >
                        <div class="carousel-inner ">
                          {variantPic.slice(0, 4).map((photos,index) => {
                            return (
                              <div
                                class={`carousel-item  ${
                                  index === 0 ? "active" : ""
                                }`}
                              >
                                <div className="p-mg  mb-3 ">
                                  <img
                                    src={photos.path}
                                    className="position-relative card-img-top rounded-3"
                                  /> 
                                  <div className="dress-color2 bg-white rounded text-center position-absolute d-none">
                                    {" "}
                                    <HeartOutlined class="fs-4" />{" "}
                                  </div>
                                  <div className="position-absolute top-0 p-3 d-sm-none">
                                    <i class="fa fa-chevron-left fs-3"></i>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </Col>
                    <Col lg="5" md="6">
                      <div className="p-info px-2 ">
                        <div>
                          {/* <h4 className="fw-light">U.S POLO ASSN.</h4> */}
                          <h4 className="fw-semibold">{product.name}</h4>
                          <span class="badge rating text-bg-success ">
                            {" "}
                            <i
                              class="fa fa-star text-start"
                              aria-hidden="true"
                            ></i>{" "}
                            <span>4.5</span>
                          </span>
                        </div>

                        <div className="d-flex mt-3">
                         {price  ?  <h3>Rs{price}.00</h3>  :  <h3>{product.main_price}</h3>}
                          <p class="text-decoration-line-through fw-light mx-3">
                            {product.stroked_price}
                          </p>
                          <h4 className="mx-3 text-danger">
                            ({product.discount} OFF)
                          </h4>
                        </div>

                        <div className="mt-2">
                          <h4>Item Color</h4>
                          <div className="d-flex">
                            <div className="d-color rounded mx-auto"></div>
                            <div className="d-color rounded bg-secondary mx-auto "></div>
                            <div className="d-color rounded bg-success mx-auto"></div>
                            <div className="d-color rounded bg-danger mx-auto"></div>
                            <div className="d-color rounded bg-info mx-auto"></div>
                            <div className="d-color rounded bg-light shadow mx-auto"></div>
                            <div className="d-color rounded bg-dark mx-auto"></div>
                          </div>
                        </div>

                        <div className="mt-3">
                          <div className="d-flex">
                            <h4 className=" ">Item Size</h4>
                            <h4 className="mx-auto">Size Chart</h4>
                          </div>
                          <div className="d-flex">
                            <div className="d-size rounded mx-2 py-2">
                              <span>S</span>
                            </div>
                            <div className="d-size rounded mx-2 py-2">
                              <span>M</span>
                            </div>
                            <div className="d-size rounded mx-2 py-2">
                              <span>L</span>
                            </div>
                            <div className="d-size rounded mx-2 py-2">
                              <span>XL</span>
                            </div>
                          </div>
                        </div>
                        <div className="mt-3">
                          <h4>Quantity</h4>
                          <div className="d-flex">
                            <div
                              className="d-size border mx-2 py-2"
                              onClick={decQnt}
                            >
                              <span>
                                <a>-</a>
                              </span>
                            </div>
                            <div className="rounded mx-2 py-2">
                              <span>{qnt}</span>
                            </div>
                            <div
                              className="d-size border mx-2 p-1 py-2"
                              onClick={addQnt}
                            >
                              <span>
                                <a>+</a>
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="d-flex p-buy mt-3 mb-2">
                          <button className=" mx-2 bg-dark text-white ">
                            BUY NOW
                          </button>
                          <button
                            className="btn mx-2"
                            type="button"
                            onClick={addTocart}
                          >
                            ADD TO CART
                          </button>
                        </div>

                        <div className="add-wish">
                          <div className="mt-3">
                            <button type="button" onClick={AddWisglist}>ADD TO WISHLIST</button>
                          </div>

                          <div className="mt-2 d-none ">
                            <span>Share</span>
                            <div className="d-flex">
                              <div className="d-icon rounded  mx-2 ">
                                <span>
                                  <i
                                    class="fa fa-twitter"
                                    aria-hidden="true"
                                  ></i>
                                </span>
                              </div>
                              <div className="d-icon rounded  mx-2 ">
                                <span>
                                  <i class="fa fa-facebook-f"></i>
                                </span>
                              </div>
                              <div className="d-icon rounded  mx-2">
                                <span>
                                  <i
                                    class="fa fa-instagram"
                                    aria-hidden="true"
                                  ></i>
                                </span>
                              </div>
                              <div className="d-icon rounded  mx-2">
                                <span>
                                  <i
                                    class="fa fa-whatsapp"
                                    aria-hidden="true"
                                  ></i>
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="mt-2 ">
                            <span>Share</span>
                            <div className="d-flex">
                              {Sociallink ? (
                                Sociallink.map((data, key) => {
                                  // console.log('12345678',data.type.split('_',1)[0])
                                  return (
                                    <div className="d-icon rounded  mx-2 " 
                                    onClick={() =>
                                      window.open(data.value, "_blank")
                                    }                                    >
                                      <span>
                                        {/* <a href={data.value}><i class={`fa fa-${data.type.split('_',1)[0]}`} aria-hidden="true"></i></a>   */}
                                        <i
                                          className={`fa fa-${
                                            data.type.split("_", 1)[0]
                                          }`}
                                          aria-hidden="true"
                                          onClick={() =>
                                            window.open(data.value, "_blank")
                                          }
                                        ></i>
                                      </span>
                                    </div>
                                  );
                                })
                              ) : (
                                <span>
                                  <i
                                    class="fa fa-twitter"
                                    aria-hidden="true"
                                  ></i>
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </Col>
                  </Row>
                </div>
              ) : (
                <div className="product-1 mt-5">
                  <Row>
                    <Col lg="2" className="d-none d-lg-block ">
                      <div className="p-view mx-3 rounded">
                        <img
                          src="assets\img\images\2.png"
                          className="img-fluid "
                          data-bs-target="#carouselExampleCaptions"
                          data-bs-slide-to="0"
                          class="active"
                          aria-current="true"
                          aria-label="Slide 1"
                        />
                      </div>
                      <div className="p-view mx-3 my-3 rounded">
                        <img
                          src="assets\img\images\2.png"
                          className="img-fluid"
                          data-bs-target="#carouselExampleCaptions"
                          data-bs-slide-to="1"
                          aria-label="Slide 2"
                        />
                      </div>
                      <div className="p-view mx-3 my-3 rounded">
                        <img
                          src="assets\img\images\2.png"
                          className="img-fluid"
                          data-bs-target="#carouselExampleCaptions"
                          data-bs-slide-to="2"
                          aria-label="Slide 3"
                        />
                      </div>
                      <div className="p-view mx-3 my-3 rounded">
                        <img
                          src="assets\img\images\2.png"
                          className="img-fluid"
                        />
                      </div>
                    </Col>
                    <Col lg="5" md="6">
                      <div className="p-mg rounded mb-3 d-none">
                        <img src="assets\img\images\2.png" />
                      </div>
                      {/* <Swiper
                            freeMode={true}
                            grabCursor={true}
                            // pagination={{
                            //   dynamicBullets: true,
                            //   // bulletActiveClass:""
                            // }}
                            // modules={[Pagination]}
                            pagination={pagination}
                            modules={[Pagination]}
                            className="mySwipper2"
                            breakpoints={{
                              0: {
                                slidesPerView: 1,
                                spaceBetween: 10,
                              },
                              480: {
                                slidesPerView: 1,
                                spaceBetween: 10,
                              },
                              768: {
                                slidesPerView: 1,
                                spaceBetween: 15,
                              },
                              1024: {
                                slidesPerView: 1,
                                spaceBetween: 15,
                              },
                              1280: {
                                slidesPerView: 1,
                                spaceBetween: 0,
                              },
                            }}
                          >
                            <SwiperSlide>
                            <div className="p-mg rounded-3 mb-3 ">
                                    <img src="assets\img\images\2.png" className="position-relative card-img-top" />
                                    <div className="dress-color2 bg-white rounded text-center position-absolute">
                                          {" "}
                                          <HeartOutlined class="fs-4"/>{" "}
                                        </div>
                                        <div className="position-absolute top-0 p-3 d-sm-none" >
                                        <i class="fa fa-chevron-left fs-3"></i>
                                        </div>
                                  </div>
                            </SwiperSlide>
                            <SwiperSlide>
                            <div className="p-mg rounded mb-3 ">
                                    <img src="assets\img\images\2.png" className="position-relative card-img-top" />
                                    <div className="dress-color2 bg-white rounded text-center position-absolute">
                                          {" "}
                                          <HeartOutlined class="fs-4 " />{" "}
                                        </div>
                                  </div>
                            </SwiperSlide>
                            <SwiperSlide>
                            <div className="p-mg rounded mb-3 ">
                                    <img src="assets\img\images\2.png" className="position-relative card-img-top" />
                                    <div className="dress-color2 bg-white rounded text-center position-absolute">
                                          {" "}
                                          <HeartOutlined class="fs-4 " />{" "}
                                        </div>
                                  </div>
                            </SwiperSlide>
                          </Swiper> */}
                      <div
                        id="carouselExampleCaptions"
                        class="carousel slide"
                        data-bs-ride="false"
                      >
                        <div class="carousel-inner">
                          <div class="carousel-item active">
                            <div className="p-mg rounded-3 mb-3 ">
                              <img
                                src="assets\img\images\2.png"
                                className="position-relative card-img-top"
                              />
                              <div className="dress-color2 bg-white rounded text-center position-absolute">
                                {" "}
                                <HeartOutlined class="fs-4" />{" "}
                              </div>
                              <div className="position-absolute top-0 p-3 d-sm-none">
                                <i class="fa fa-chevron-left fs-3"></i>
                              </div>
                            </div>
                          </div>
                          <div class="carousel-item">
                            <div className="p-mg rounded-3 mb-3 ">
                              <img
                                src="assets\img\images\2.png"
                                className="position-relative card-img-top"
                              />
                              <div className="dress-color2 bg-white rounded text-center position-absolute">
                                {" "}
                                <HeartOutlined class="fs-4" />{" "}
                              </div>
                              <div className="position-absolute top-0 p-3 d-sm-none">
                                <i class="fa fa-chevron-left fs-3"></i>
                              </div>
                            </div>
                          </div>
                          <div class="carousel-item">
                            <div className="p-mg rounded-3 mb-3 ">
                              <img
                                src="assets\img\images\2.png"
                                className="position-relative card-img-top"
                              />
                              <div className="dress-color2 bg-white rounded text-center position-absolute">
                                {" "}
                                <HeartOutlined class="fs-4" />{" "}
                              </div>
                              <div className="position-absolute top-0 p-3 d-sm-none">
                                <i class="fa fa-chevron-left fs-3"></i>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Col>
                    <Col lg="5" md="6">
                      <div className="p-info px-2 ">
                        <div>
                          <h4 className="fw-light">U.S POLO ASSN.</h4>
                          <h4 className="fw-semibold">
                            Brand Embroidered Pique Polo Shirt
                          </h4>
                          <span class="badge text-bg-success py-3">
                            {" "}
                            <i
                              class="fa fa-star text-start"
                              aria-hidden="true"
                            ></i>{" "}
                            <span>4.5</span>
                          </span>
                        </div>

                        <div className="d-flex mt-3">
                          <h3>₹ 600.00</h3>
                          <p class="text-decoration-line-through fw-light mx-3">
                            ₹ 1,249.00
                          </p>
                          <h4 className="mx-3 text-danger">(60% OFF)</h4>
                        </div>

                        <div className="mt-2">
                          <h4>Item Color</h4>
                          <div className="d-flex">
                            <div className="d-color rounded mx-auto"></div>
                            <div className="d-color rounded bg-secondary mx-auto "></div>
                            <div className="d-color rounded bg-success mx-auto"></div>
                            <div className="d-color rounded bg-danger mx-auto"></div>
                            <div className="d-color rounded bg-info mx-auto"></div>
                            <div className="d-color rounded bg-light shadow mx-auto"></div>
                            <div className="d-color rounded bg-dark mx-auto"></div>
                          </div>
                        </div>

                        <div className="mt-3">
                          <div className="d-flex">
                            <h4 className=" ">Item Size</h4>
                            <h4 className="mx-auto">Size Chart</h4>
                          </div>
                          <div className="d-flex">
                            <div className="d-size rounded mx-2 py-2">
                              <span>S</span>
                            </div>
                            <div className="d-size rounded mx-2 py-2">
                              <span>M</span>
                            </div>
                            <div className="d-size rounded mx-2 py-2">
                              <span>L</span>
                            </div>
                            <div className="d-size rounded mx-2 py-2">
                              <span>XL</span>
                            </div>
                          </div>
                        </div>

                        <div className="mt-3">
                          <h4>Quantity</h4>
                          <div className="d-flex">
                            <div
                              className="d-size border mx-2 py-2"
                              onClick={decQnt}
                            >
                              <span>
                                <a>-</a>
                              </span>
                            </div>
                            <div className="rounded mx-2 py-2">
                              <span>{qnt}</span>
                            </div>
                            <div
                              className="d-size border mx-2 p-1 py-2"
                              onClick={addQnt}
                            >
                              <span>
                                <a>+</a>
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="d-flex p-buy mt-3 mb-2">
                          <button className=" mx-2 bg-dark text-white ">
                            BUY NOW
                          </button>
                          <button className="btn mx-2" onClick={addTocart}>ADD TO CART</button>
                        </div>

                        <div className="add-wish">
                          <div className="mt-3">
                            <button type="button" onClick={AddWisglist}>ADD TO WISHLIST</button>
                          </div>

                          <div className="mt-2 ">
                            <span>Share</span>
                            <div className="d-flex">
                              <div className="d-icon rounded  mx-2 ">
                                <span>
                                  <i
                                    class="fa fa-twitter"
                                    aria-hidden="true"
                                  ></i>
                                </span>
                              </div>
                              <div className="d-icon rounded  mx-2 ">
                                <span>
                                  <i class="fa fa-facebook-f"></i>
                                </span>
                              </div>
                              <div className="d-icon rounded  mx-2">
                                <span>
                                  <i
                                    class="fa fa-instagram"
                                    aria-hidden="true"
                                  ></i>
                                </span>
                              </div>
                              <div className="d-icon rounded  mx-2">
                                <span>
                                  <i
                                    class="fa fa-whatsapp"
                                    aria-hidden="true"
                                  ></i>
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Col>
                  </Row>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* product-info */}
        <section id="product-info">
          <div className="container mt-3 mb-5">
            <div className="m-productDetails">
              <h5 className="fw-bold">Roadster Time Travlr Men Black Casual</h5>
              <h5 className="fw-bold">Shirt</h5>

              <p>
                Style - Enhance your look by wearing this Casual Stylish Men's
                shirt, Team it with a pair of tapered denims Or Solid Chinos and
                Loafers for a fun Smart Casual look... Read More
              </p>

              <div className="mt-3">
                <div className="d-flex ">
                  <h4 className=" ">Item Size</h4>
                  <h4 className="mx-auto">Size Chart</h4>
                </div>
                <div className="d-flex">
                  <div className="d-size rounded mx-1  ">
                    <span>S</span>
                  </div>
                  <div className="d-size rounded mx-1 ">
                    <span>M</span>
                  </div>
                  <div className="d-size rounded mx-1">
                    <span>L</span>
                  </div>
                  <div className="d-size rounded mx-1 ">
                    <span>XL</span>
                  </div>
                </div>
              </div>

              <div className="mt-4">
                <h4>Item Color</h4>
                <div className="d-flex">
                  <div className="d-color rounded bg-primary mx-1 p-3 "></div>
                  <div className="d-color rounded bg-secondary mx-1 p-3"></div>
                  <div className="d-color rounded bg-success mx-1 p-3"></div>
                  <div className="d-color rounded bg-danger mx-1 p-3"></div>
                  <div className="d-color rounded bg-info mx-1 p-3"></div>
                  <div className="d-color rounded bg-light shadow mx-1 p-3"></div>
                  <div className="d-color rounded bg-dark mx-1 p-3"></div>
                </div>
              </div>

              <div className="Qnt row mt-4">
                <div className="col d-flex">
                  <span className="fw-light mx-2 text-truncate">Qty :</span>
                  <div className="d-flex">
                            <div
                              className="d-size border mx-2 py-1"
                              onClick={decQnt}
                            >
                              <span>
                                <a>-</a>
                              </span>
                            </div>
                            <div className="rounded mx-2 py-1">
                              <span>{qnt}</span>
                            </div>
                            <div
                              className="d-size border mx-2  py-1"
                              onClick={addQnt}
                            >
                              <span>
                                <a>+</a>
                              </span>
                            </div>
                          </div>
                </div>
                <div className="col text-end text-truncate">
                  <span className="fw-light ">
                    Total: <span className="fw-bold">₹ 600.00</span>
                  </span>
                  <br></br>
                  {/* <small class="text-decoration-line-through fw-light mx-3"> ₹ 1,249.00 </small>
                <small className="mx-3 text-danger">(60% OFF)</small> */}
                </div>
              </div>

              <div className="mt-4">
                <h5 className="fw-bold">Returns</h5>
                <p>
                  Easy 30 days return and exchange. Return Policies may vary
                  based on products and promotions. For full details on our
                  Returns policies, please click here
                </p>
              </div>

              <div className="d-flex p-buy mt-4 justify-content-center">
                <button type="button" className="btn btn-dark">
                  BUY NOW
                </button>
                <button type="button" className="btn" onClick={addTocart}>
                  <i class="fa fa-heart" aria-hidden="true"></i> ADD TO CART
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Product disc */}
        <section id="product-disc" className="mt-5">
          <div className="container">
            <div className="productDisc">
              <div class="d-flex justify-content-evenly">
                <div>
                  <h4>DETAILS</h4>
                </div>
                <div>
                  <h4 className="fw-light">SHIPPING & RETURNS</h4>
                </div>
                <div>
                  <h4 className="fw-light">AUTHENTICATION</h4>
                </div>
              </div>
              <div className="disc mt-4">
                <h3>PRODUCT DETAILS:</h3>
                {desc.description != null ? (
                  desc.description.replace(/(<([^>]+)>)/gi, "")
                ) : (
                  <p>
                    U.S. POLO ASSN. captures the authenticity of polo and stays
                    true to a classic American style updated to complement
                    today's onthego lifestyle. Officially sanctioned by the
                    United States Polo Association (the governing body of polo
                    in the USA since 1890), the brand carries clothing for men,
                    women and children, as well as accessories, luggage,
                    watches, shoes, home furnishings and more.
                  </p>
                )}
              </div>
            </div>
          </div>
        </section>

        {/*Wabi Environmental impact   */}
        <section id="P-wabi-env" className="mt-5">
          <div className="container">
            <div className="wabi-env text-center">
              <div className="sabi-env">
                <i className="fa fa-recycle" aria-hidden="true"></i>
              </div>
              <h3>Wabi Sabi Environmental Impact</h3>
              <p>Recycle, Reuse, Reduce</p>
            </div>
          </div>
        </section>

        {/* SIMILAR PRODUCTS */}
        <section className="deal-day">
          <div className="container">
            <div className="deal mt-5">
              <div className="text-start wabi-tittle ">
                <h3>SIMILAR PRODUCTS</h3>
              </div>

              <div className="text-end d-xxl-block d-none arr">
                <button
                  onMouseOver={() => setPrebtn(true)}
                  onMouseOut={() => setPrebtn(false)}
                  onClick={() => swiperRef.current?.slidePrev()}
                  className={`previous text-center ${
                    btnPre ? "shadow" : ""
                  }  mx-2 text-dark`}
                >
                  &#8249;
                </button>
                <button
                  onMouseOver={() => setNxtbtn(true)}
                  onMouseOut={() => setNxtbtn(false)}
                  onClick={() => swiperRef.current?.slideNext()}
                  className={`next  ${btnNxt ? "shadow" : ""} mx-auto`}
                >
                  &#8250;
                </button>
              </div>

              <Swiper
                freeMode={true}
                grabCursor={true}
                // modules={[FreeMode]}
                className="mySwipper2"
                // loop={true}
                slidesPerView={3}
                onBeforeInit={(swiper) => {
                  swiperRef.current = swiper;
                }}
                breakpoints={{
                  0: {
                    slidesPerView: 2,
                    spaceBetween: 10,
                  },
                  480: {
                    slidesPerView: 2,
                    spaceBetween: 10,
                  },
                  768: {
                    slidesPerView: 3,
                    spaceBetween: 15,
                  },
                  1024: {
                    slidesPerView: 4,
                    spaceBetween: 15,
                  },
                  1280: {
                    slidesPerView: 4,
                    spaceBetween: 10,
                  },
                }}
              >
                {  
                related.length > 0 ?
                related.map((data, key) => {
                  return (
                    <SwiperSlide>
                      <Card
                        id="card"
                        className="shadow"
                        onClick={() => detailpage(data)}
                      >
                        <Card.Img variant="top" src={data.thumbnail_image} />
                        <Card.Body className="text-start ">
                          <h4 className="text-truncate">{data.name}</h4>
                          {/* <h6 className="fw-light">Adidas</h6> */}
                          <div className="d-flex mt-4 text-truncate">
                            <p>{data?.main_price}</p>
                            <p class="text-decoration-line-through fw-light mx-2">
                              {data?.stroked_price}
                            </p>
                            <p className=" text-danger">({data.discount}OFF)</p>
                          </div>
                        </Card.Body>
                      </Card>
                    </SwiperSlide>
                  );
                }) 
                : 
                ""
                }
              </Swiper>
            </div>
          </div>
        </section>
      </div>
      <Footer />
    </>
  );
};

export default ProductDetails;
