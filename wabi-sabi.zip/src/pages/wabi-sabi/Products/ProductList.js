import { useState, useEffect } from "react";

import Header from "../Header/Header";
import Footer from "../Footer/Footer";

import { LoadingOutlined } from "@ant-design/icons";
import { Alert, Space, Spin } from "antd";

// import axios from "axios";

import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Card from "react-bootstrap/Card";
import { useLocation, useNavigate } from "react-router-dom";
import {
  getproducts,
  filterCategory,
  getBarndedproducts,
  filterBrands,
  getAllproducts,
  getIndProduct,
  addWishlists
} from "./core/_request";
import {getWishlist} from '../core/_request'
// antd icon
import { HeartOutlined } from "@ant-design/icons";
// antd
import { Checkbox } from "antd";
import { Breadcrumb, Layout, Menu, theme } from "antd";

const { Content, Sider } = Layout;

const items2 = [
  "CATEGORY",
  "METERIALS",
  "PRICE",
  "FASHION SIZE",
  "FASHION STYLE",
  "FASHION COLOR",
  "DISCOUNT RANGE",
  "BRAND",
].map((icon, index) => {
  const key = String(index + 1);
  return {
    key: `sub${key}`,
    //   icon: React.createElement(icon),
    label: icon,
    children: ["Men", "Women", "Kids"].map((_, j) => {
      const subKey = index * 4 + j + 1;
      return {
        key: subKey,
        label: ` ${_}`,
      };
    }),
  };
});

const ProductList = () => {
  const { state } = useLocation();

  const navigate = useNavigate();

  console.log("state", state);

  const [collapsed, setCollapsed] = useState(false);
  const [Categorylist, setCategorylist] = useState([]);
  const [Brandslist, setBrandslist] = useState([]);
  const [productlist, setProductlist] = useState(state);
  const [product, setProduct] = useState([]);
  const [brabdeditems, setBrandeditems] = useState([]);
  const [pages, setPages] = useState(1);
  const [pageBtn, setPageBtn] = useState([]);
  const [wishBtn, setWishbtn] = useState([]);
  const [wishList, setWishlist] = useState([]);

  const wishlistShow = () => {
    setWishbtn(true)
  }

  function getItem(label, key, children, icon) {
    return {
      key,
      children,
      label,
      icon,
    };
  }

  const items = [
    getItem(
      "CATEGORY",
      "sub1",
      Categorylist?.map((list, index) =>
        getItem(
          list.name,
          index,
          "",
          <Checkbox onClick={() => filter(list.id)} />
        )
      )
    ),
    getItem("METERIALS", "sub2", [
      getItem("Cotton", "3", "", <Checkbox />),
      getItem("Peach", "4", "", <Checkbox />),
      getItem("Lilac", "5", "", <Checkbox />),
    ]),
    getItem("PRICE", "sub3", [
      getItem("Under1,000", "3", "", <Checkbox />),
      getItem("Under15,000", "4", "", <Checkbox />),
      getItem("Under20,000", "5", "", <Checkbox />),
    ]),

    getItem("FASHION SIZE", "sub4", [
      getItem("XS", "3", "", <Checkbox />),
      getItem("S", "4", "", <Checkbox />),
      getItem("M", "5", "", <Checkbox />),
      getItem("L", "6", "", <Checkbox />),
      getItem("XL", "7", "", <Checkbox />),
    ]),

    getItem("FASHION STYLE", "sub5", [
      getItem("Above Knee", "3", "", <Checkbox />),
      getItem("Blow Knee", "4", "", <Checkbox />),
      getItem("Slim Fit", "5", "", <Checkbox />),
      getItem("Ankle Length", "6", "", <Checkbox />),
      getItem("Wide Leg", "7", "", <Checkbox />),
    ]),

    getItem("ASHION COLOR", "sub6", [
      getItem("Men", "3", "", <Checkbox />),
      getItem("Women", "4", "", <Checkbox />),
      getItem("Kids", "5", "", <Checkbox />),
    ]),

    getItem("DISCOUNT RANGE", "sub7", [
      getItem("Men", "3", "", <Checkbox />),
      getItem("Women", "4", "", <Checkbox />),
      getItem("Kids", "5", "", <Checkbox />),
    ]),

    getItem(
      "BRAND",
      "sub8",
      Brandslist?.map((list, index) =>
        getItem(
          list.name,
          index,
          "",
          <Checkbox onClick={() => filter(list.id)} />
        )
      )
    ),
  ];

  const {
    token: { colorBgContainer },
  } = theme.useToken();

  const wishlistProduct = async() => {
    const productData = await getWishlist()
    console.log('wishlist',productData);
    setWishlist(productData.data);
    productData.data.forEach((c) =>{
      setWishbtn(c.id)
    })
    
}


  const categoryList = async () => {
    const categoryFilter = await filterCategory();
    console.log("filter", categoryFilter);
    setCategorylist(categoryFilter.data);
  };

  const BrandsList = async () => {
    const brandFilter = await filterBrands();
    console.log("filterbrands", brandFilter);
    setBrandslist(brandFilter.data);
  };

  const productData = async (categoryId) => {
    const productList = await getproducts(categoryId);
    if (productList) {
      setProduct(productList.data);
      console.log("productlist", productList);
    }
  };
  const allProducts = async (pages) => {
    const productList = await getAllproducts(pages);
    if (productList) {
      setProduct(productList.data);
      console.log("ALLproduct", productList.meta.links);
      setPageBtn(productList.meta.links)
    }
  };
  const AddWisglist = async (id) => {
    setWishbtn(id);
    const Wishlists = await addWishlists(id);
    console.log("wishlist", Wishlists);
  };

  const SearchProdut = async() => {
    let id = state.id
    const Product = await getIndProduct(state)
    setProduct(product.data);
    console.log('djhkgjkjkjlljkl;',product)
  }

  const pagination = (no) => {
    if(no === 0) no = pages -1
    if(pageBtn.length-2 < no) no=pages +1 
    if(no > pageBtn.length-2) no= pageBtn.length-2
    console.log('no', pageBtn.length-2)
    allProducts(no)
    setPages(no)
  }

  const brandedProducts = async () => {
    let id = state.brandId;
    const branded = await getBarndedproducts(id);
    setProduct(branded.data);
    console.log("branded123", branded, product);
  };

  const filter = (id) => {
    productData(id);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    categoryList();
    BrandsList();
    wishlistProduct()
    if(!state){
      allProducts(pages)
    }
   else if (state.brandId) {
      brandedProducts();
    } else if (productlist.length == undefined) {
      let categoryId = state.id;
      productData(categoryId);
    } else {
      // SearchProdut();
      setProduct(state);
    }
  }, []);

  return (
    <>
      <Layout>
        <div className="head-fixed">
          <Header />
        </div>

        <div className="container">
          <Content>
            <Breadcrumb>
              <Breadcrumb.Item>Home</Breadcrumb.Item>
              <Breadcrumb.Item>Men</Breadcrumb.Item>
            </Breadcrumb>
            <div className="row sort  d-lg-flex d-md-flex d-none productlist1  ">
              <h4 className="col-9 text-end pt-2">Sort By: </h4>
              <select
                className="col form-select border border-0 shadow-sm"
                name="price"
              >
                <option value="High-Low">Price High-Low</option>
                <option value="Low-High">Price Low-High</option>
                <option value="High">Price High</option>
                <option value="Low">Price Low</option>
              </select>
            </div>
            <Layout className="py-4">
              <Sider className="productList-slide" width={300}>
                <Menu>
                  <div className="d-flex  justify-content-between pb-2">
                    <h3 className="fw">Filters</h3>
                    <small
                      className="text-danger pt-3 fw-bold user-select-none"
                      onClick={allProducts}
                    >
                      CLEAR ALL
                    </small>
                  </div>
                </Menu>
                <div className="border border-1"></div>
                <Menu
                  mode="inline"
                  defaultSelectedKeys={["1"]}
                  defaultOpenKeys={["sub1"]}
                  items={items}
                />
              </Sider>

              <Content className="px-4">
                {/* product list */}
                <section id="product-list1">
                  <div className="productlist1">
                    <div className="d-flex">
                      <div class="dropdown d-lg-none d-md-none border border-dark mx-1 rounded">
                        <a
                          class="btn  dropdown-toggle"
                          href="#"
                          role="button"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                        >
                          FILTER
                        </a>

                        <ul class="dropdown-menu">
                          <li>
                            <a class="dropdown-item" href="#">
                              1
                            </a>
                          </li>
                          <li>
                            <a class="dropdown-item" href="#">
                              2
                            </a>
                          </li>
                          <li>
                            <a class="dropdown-item" href="#">
                              3
                            </a>
                          </li>
                        </ul>
                      </div>
                      <div class="dropdown d-lg-none d-md-none border border-dark mx-1 rounded">
                        <a
                          class="btn  dropdown-toggle"
                          href="#"
                          role="button"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                        >
                          SORT BY
                        </a>

                        <ul class="dropdown-menu">
                          <li>
                            <a class="dropdown-item" href="#">
                              1
                            </a>
                          </li>
                          <li>
                            <a class="dropdown-item" href="#">
                              2
                            </a>
                          </li>
                          <li>
                            <a class="dropdown-item" href="#">
                              3
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>

                    <Row className="mt-4">
                      {
                        product.length !== 0 ? (
                          product.map((data, index) => {
                            console.log('fgfgfgfgfghfhfh', data.id ,wishBtn)
                            return (
                              <Col md="4" sm="6" xs="6">
                                <div
                                  className="shadow-sm mb-5 border-0 card "
                                >
                                  <div className="p-2 rounded">
                                    <img
                                      // variant="top"
                                      src={data.thumbnail_image}
                                      className="card-img-top"
                                      onClick={() =>
                                        navigate("/clotheinfo", { state: data })
                                      }
                                    />
                                 <div className="dress-color1 text-center rounded position-absolute">
                                {" "}
                                 {
                               
                                  data.id == wishBtn ?
                                  <i class="fa fa-heart pt-2" onClick={()=>setWishbtn()}></i> 
                                  :
                                  <HeartOutlined class="fs-4 "  onClick={()=>AddWisglist(data.id)}  />
                                }
                                {/* <HeartOutlined class="fs-4 " onClick={()=>wishlistShow(index)} />{" "} */}
                                {/* <i class="fa fa-heart pt-2"></i> */}
                              </div>
                                  </div>
                                  <div className="card-body">
                                    <a onClick={() => navigate("/clotheinfo", { state: data }) }>
                                    <div className="p-menu">
                                      <h4>{data.name}</h4>
                                    </div></a>
                                    {/* <small>Levis</small> */}
                                    <div className="d-flex pl-price ">
                                      <p className="fw-bolder">
                                        {data.main_price}
                                      </p>
                                      <p class="text-decoration-line-through fw-light mx-1">
                                        {data.stroked_price}
                                      </p>
                                      <p className="text-danger">
                                        ({data.discount}OFF)
                                      </p>
                                    </div>
                                    <div className="d-flex">
                                      <div className="pl-size rounded mx-1 p-sm-2 ">
                                        <span>S</span>
                                      </div>
                                      <div className="pl-size rounded mx-1 p-sm-2 ">
                                        <span>M</span>
                                      </div>
                                      <div className="pl-size rounded mx-1 p-sm-2">
                                        <span>L</span>
                                      </div>
                                      <div className="pl-size rounded mx-1 p-sm-2">
                                        <span className="text-truncate">
                                          XL
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </Col>
                            );
                          })
                        ) : (
                          //   <Col md="4" sm="6" xs="6">
                          //   <div class="card border border-0 shadow mb-4">
                          //     <img
                          //       src="/assets/img/images/image_2022_11_21T05_17_21_764Z.png"
                          //       className="position-relative card-img-top"
                          //       alt="..."
                          //     />
                          //     <div className="dress-color1 rounded text-center position-absolute">
                          //       {" "}
                          //       <HeartOutlined class="fs-4 " />{" "}
                          //     </div>
                          //     <div class="card-body">
                          //       <div className="p-menu">
                          //         <h4 className="m-0" >Zara Top</h4>
                          //         <small className="d-none d-sm-block">Levis</small>
                          //       </div>
                          //       <div className="d-flex pl-price  ">
                          //         <h4 className="mb-0" >₹6000.00</h4>
                          //         <p class="text-decoration-line-through fw-light mb-0 mx-2">
                          //         ₹1,249.00
                          //         </p>
                          //         <p className="text-danger mb-0">(60%OFF)</p>
                          //       </div>
                          //       <div className="row p-size">
                          //         <div className="border border-2 text-center rounded p-md-2 p-0 col-2">
                          //           <span>S</span>
                          //         </div>
                          //         <div className="border border-2 text-center rounded p-md-2 p-0 mx-1 col-2">
                          //           <span>M</span>
                          //         </div>
                          //         <div className="border border-2 text-center rounded p-md-2 p-0 col-2">
                          //           <span>L</span>
                          //         </div>
                          //         <div className="border border-2 text-center rounded p-md-1 py-md-2 p-0 py-0 mx-1 col-2">
                          //           <span>XL</span>
                          //         </div>
                          //       </div>
                          //     </div>
                          //   </div>
                          // </Col>
                        <div className="spin-h">
                          <Spin tip="Loading" size="large">
                            <div className="content" />
                          </Spin>
                          </div>
                        )
                        //   <LoadingOutlined
                        //   style={{
                        //     fontSize: 24,
                        //   }}
                        //   spin
                        // />
                      }
                    </Row>
                    <div className="float-end">
                      <nav aria-label="Page navigation example">
                      <ul class="pagination">
                        {
                          pageBtn?
                          pageBtn.map((page,index)=>{
                            return(<>
                            <li class="page-item">
                            <a class={`page-link  ${pages == index ? 'active' : ''}`} href="#" onClick={()=>pagination(index)}>
                              {page.label}
                            </a>
                          </li>
                            </>)
                          }) :
                          ''
                        }
                        </ul>
                        {/* <ul class="pagination ">
                          <li class="page-item">
                            <a class="page-link" href="#" aria-label="Previous" onClick={()=>pagination(pages-1)}>
                              <span aria-hidden="true">&laquo;</span>
                            </a>
                          </li>
                          <li class="page-item">
                            <a class="page-link" href="#" onClick={()=>pagination(1)}>
                              1
                            </a>
                          </li>
                          <li class="page-item">
                            <a class="page-link" href="#" onClick={()=>pagination(2)}>
                              2
                            </a>
                          </li>
                          <li class="page-item">
                            <a class="page-link" href="#" onClick={()=>pagination(3)}>
                              3
                            </a>
                          </li>
                          <li class="page-item">
                            <a class="page-link" href="#" onClick={()=>pagination(4)}>
                              4
                            </a>
                          </li>
                          <li class="page-item">
                            <a class="page-link" href="#" aria-label="Next" onClick={()=>pagination(pages+1)}>
                              <span aria-hidden="true">&raquo;</span>
                            </a>
                          </li>
                        </ul> */}
                      </nav>
                    </div>
                  </div>
                </section>
              </Content>
            </Layout>
          </Content>
        </div>
        <Footer />
      </Layout>
    </>
  );
};

export default ProductList;
