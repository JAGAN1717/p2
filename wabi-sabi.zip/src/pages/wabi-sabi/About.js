import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "./Header/Header";
import Footer from "./Footer/Footer";

const About = () => {
  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>

      <section id="about">
        <div className="container mb-5">
          <h4 className="mb-5 mt-5 head-path1">
            <a href="#">Home</a> / <a href="#">About Us</a>
          </h4>
          <div className="about-mg">
            <div className="d-flex">
              <img src="assets\img\images\about-img-02.jpg" />
              <div className="about-info px-3 py-3">
                <h4>Who we are</h4>
                <br />
                <small>
                  Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                  diam nonumy eirmod tempor invidunt ut labore et dolore magna
                  aliquyam erat, sed diam voluptua. At vero eos et accusam et
                  justo duo dolores et ea rebum. Stet clita kasd gubergren, no
                  sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem
                  ipsum dolor sit amet, consetetur sadipscing elitr, sed diam
                  nonumy eirmod tempor invidunt ut labore et
                  <br />
                  <br />
                  Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                  diam nonumy eirmod tempor invidunt ut labore et dolore magna
                  aliquyam erat, sed diam voluptua. At vero
                </small>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default About;
