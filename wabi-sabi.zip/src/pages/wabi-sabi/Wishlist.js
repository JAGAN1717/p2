import { useState,  useEffect } from "react";
import Header from "./Header/Header";
import Footer from "./Footer/Footer";

// react bootstrap
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Card from "react-bootstrap/Card";
import { Alert, Space, Spin } from "antd";


import { HeartOutlined, } from "@ant-design/icons";
import {getWishlist} from "./core/_request"


const Wishlist = () =>{

    const [productList,setProductList] = useState([])

    const wishlistProduct = async() => {
        const productData = await getWishlist()
        console.log('wishlist',productData);

        setProductList(productData.data);
    }
  
    useEffect(()=>{
        wishlistProduct();
    },[])

    return(<>
        <div className="head-fixed">
          <Header />
        </div>

        <div className="container">
            <div className="wishlist">
        <h4 className="mb-2 mt-5 pd-tittle">
                <a href="#">Home</a> / <a href="#">Wishlist</a> /{" "}
              </h4>
              </div>
              <div className="wishlistProduct">
              <Row className="mt-4">
                {
                  productList.length !== 0 ? 

                  productList.map((data,index)=>{
                    return(<>
                <Col lg="3" md='4' sm='6' xs='6'>
                  <Card  className="shadow mb-5" >
                    <Card.Img
                      variant="top"
                      src={data.product.thumbnail_image} 
                      className="position-relative"
                      />
                      <div className="dress-color1 text-center rounded-circle  position-absolute">
                      {" "}
                      {/* <HeartOutlined class="fs-4 " />{" "} */}
                      <i class="fa fa-heart pt-2"></i>
                    </div>
                    <Card.Body>
                      <div className="p-menu">
                        <h4 className="text-truncate">{data.product.name}</h4>
                      </div>
                      {/* <small>Levis</small> */}
                      <div className="d-block d-sm-flex pl-price text-truncate ">
                        <p>{data.product.base_price}</p>
                        <p class="text-decoration-line-through fw-light mx-2">
                          $1,249.00
                        </p>
                        <p className="text-danger">(60%OFF)</p>
                      </div>
                      <div className="d-flex">
                        <div className="pl-size rounded mx-1 p-2">
                          <span>S</span>
                        </div>
                        <div className="pl-size rounded mx-1 p-2 ">
                          <span>M</span>
                        </div>
                        <div className="pl-size rounded mx-1 p-2">
                          <span>L</span>
                        </div>
                        <div className="pl-size rounded mx-1 p-2">
                          <span>XL</span>
                        </div>
                      </div>
                    </Card.Body>
                  </Card>
                </Col> 
                    </>)
                  })
                : 
                // <h3 className="text-center"> Wishlist Empty !</h3>
                <Spin tip="Loading" size="large">
                <div className="content" />
              </Spin>
                }


                          
                          
                          
              </Row>

              </div>
        </div>
    
    </>)
}


export default Wishlist;