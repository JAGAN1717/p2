import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "./Header/Header";
import Footer from "./Footer/Footer";

const TermsConditon = () => {
  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>

      <section id="terms">
        <div className="container">
          <h5 className="mb-5 mt-5 head-path1 d-lg-block d-md-block d-none">
            <a href="#">Profile</a> / <a href="#">Terms & Condition</a>
          </h5>

          <h5 className="text-center">Terms & Condition</h5>

          <div className="terms mb-5">
            <p className="fw-light">
              <p className="fw-bold">
                What is a Terms and Conditions Agreement?
              </p>
              A terms and conditions agreement outlines the website
              administrator's rules regarding user behavior, and provides
              information about the actions the website administrator can and
              will perform.
            </p>
            <p>
              Your terms and conditions text is a contract between your website
              and its users. In the event of a legal dispute, arbitrators will
              look to this agreement to determine whether each party acted
              within their rights.
            </p>

            <p className="fw-light">
              <p className="fw-bold">
                What Should I Include in a Standard Terms and Conditions?
              </p>
              Even a short terms and conditions agreement should include several
              key clauses to safeguard your business. For example, if you're
              selling online and incorrectly price an item, your terms and
              conditions are what will enable you to cancel the order. The
              following are some of the most important sections of your terms
              and conditions for ensuring user clarity and preventing
              misunderstandings:
            </p>

            <p className="fw-light">
              <p className="fw-bold">Disclaimer</p>A disclaimer states that your
              site is available on an "as-is and as-available basis," and that
              users use it at their own risk. A basic disclaimer template should
              include these terms.
            </p>

            <p className="fw-light">
              <p className="fw-bold">Corrections</p>
              We're all human. If you make errors on your site, you need to show
              that you're not liable. This section covers your back just in case
              there are any mistakes in your content, allowing you to update it
              with the correct information at any time.
            </p>

            <p className="fw-light">
              <p className="fw-bold">Term and Terminations</p>
              Particularly useful if you offer software as a service (SaaS)
              applications, this section protects you from abusive users by
              giving you the right to suspend user accounts and delete any
              content they post.
            </p>
            <p className="fw-light">
              For example, Etsy has a termination clause in their terms of use
              that outlines the circumstances and consequences of termination
              either by Etsy or the user.
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default TermsConditon;
