import React from "react";
// Axios
import axios from "axios";

const API_URL = process.env.REACT_APP_WABI

export const SUBCATEGORIES_URL = `${API_URL}/products/sub-category`


export function getSubCategories(id){
    axios.get(SUBCATEGORIES_URL + '/' + id)
    .then(response => response.data)
}

