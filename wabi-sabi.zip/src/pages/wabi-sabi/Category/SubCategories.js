import React from "react";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import {getCategories} from "../core/_request";
import {getSubCategories} from './core/_request';
//react bootstrap
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import axios from "axios";
import { useEffect } from "react";
import { useState, createContext } from "react";
import {useNavigate,Link} from "react-router-dom";



const SubCategories = () => {
  const navigate = useNavigate();

  const [category, setCategory] = useState([]);
  const [dress, setDress] = useState({});

  const Category = async(id) => {
      const clotheCategory = await getSubCategories(id)
      console.log("categories", clotheCategory);
      setCategory(clotheCategory.data)
  };

  useEffect(() => {
    // Category();
  }, []);



  return (
    <>
      <div className="contact-head head-fixed">
        <Header />
      </div>
      <div className="head-sm ">
        <div className="d-flex justify-content-between">
          <div>
            <button
              class="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNavDropdown"
              aria-controls="navbarNavDropdown"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <i class="fa fa-chevron-left"></i>
            </button>
          </div>
          <div className="text-center">
            <span>Women</span>
          </div>
          <div>
            <i className="fa fa-bell" aria-hidden="true"></i>
          </div>
        </div>
      </div>

      <div className="d-sm-none container position-relative mt-2">
        <input type='text' placeholder="Search..." className="rounded-pill " />
          <i className="fa fa-search searchButton position-absolute"></i>
      </div>

      <section id="product-list">
        <div className="container">
          <div className="productList">
            <h4 className="mb-2 mt-5 d-sm-block d-none">
              <a href="#">Home</a> / <a href="#">Women</a>
            </h4>

            <nav class="navbar navbar-expand bg-light overflow-hidden">
              <div class="">
                {/* <a class="navbar-brand" href="#">
                  Navbar
                </a> */}
                {/* <button
                  class="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarNavDropdown"
                  aria-controls="navbarNavDropdown"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span class="navbar-toggler-icon"></span>
                </button> */}
                <div class="collapse navbar-collapse " id="navbarNavDropdown">
                  <ul class="navbar-nav ">
                    <li class="nav-item px-md-3">
                      <a class="nav-link active " aria-current="page" href="#">
                        Popular
                      </a>
                    </li>
                    <li class="nav-item px-md-3 ">
                      <a class="nav-link fw-light" href="#">
                        New
                      </a>
                    </li>
                    <li class="nav-item px-md-3">
                      <a class="nav-link fw-light" href="#">
                        Tops
                      </a>
                    </li>
                    <li class="nav-item px-md-3">
                      <a class="nav-link fw-light" href="#">
                        Saree
                      </a>
                    </li>
                    <li class="nav-item px-md-3">
                      <a class="nav-link fw-light" href="#">
                        Jeans
                      </a>
                    </li>
                    <li class="nav-item px-md-3">
                      <a class="nav-link fw-light" href="#">
                        T-shirts
                      </a>
                    </li>
                    <li class="nav-item px-md-3">
                      <a class="nav-link fw-light" href="#">
                        Dress
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>

            <div className="productGrid mt-3">
              <Row>
                {/* {
                 category.map((data,index) =>{
                  return(<>
              <Col md='3' sm='4' xs='6'  className="mb-5">
                <div className="product-mg mob-down2 " onClick={()=> navigate('/clothes',{state:data})} >
                    <img
                    src="/assets/img/images/image_2022_11_21T05_16_14_160Z.png"
                    className="img-fluid  "
                  />
                <div className="product-name">
                  <h3>{data.name}</h3>
                </div>
                    </div>
                </Col >
                  </>)
                 }) 
                } */}
      
                <Col lg="3" md="4" sm="6" xs="6">
                  <div className="product-mg mob-down2">
                    <img
                      src="/assets/img/images/image_2022_11_21T05_16_14_160Z.png"
                      className="img-fluid  "
                    />
                    <div className="product-name">
                      <h3>JACKETS</h3>
                    </div>
                  </div>
                </Col>
                <Col lg="3" md="4" sm="6" xs="6">
                  <div className="product-mg mob-down">
                    <img
                      src="/assets/img/images/login_img-2.png"
                      className="img-fluid "
                    />
                    <div className="product-name">
                      <h3>DENIM SHIRTS</h3>
                    </div>
                  </div>
                </Col>
                <Col lg="3" md="4" sm="6" xs="6">
                  <div className="product-mg mob-down2">
                    <img
                      src="/assets/img/images/login_img-2.png"
                      className="img-fluid "
                    />
                    <div className="product-name">
                      <h3>T-SHIRTS</h3>
                    </div>
                  </div>
                </Col>
                <Col lg="3" md="4" sm="6" xs="6">
                  <div className="product-mg">
                    <img
                      src="/assets/img/images/login_img-2.png"
                      className="img-fluid "
                    />
                    <div className="product-name">
                      <h3>MIDI DRESS</h3>
                    </div>
                  </div>
                </Col>
                <Col lg="3" md="4" sm="6" xs="6">
                  <div className="product-mg">
                    <img
                      src="/assets/img/images/login_img-2.png"
                      className="img-fluid "
                    />
                    <div className="product-name">
                      <h3>JEANS</h3>
                    </div>
                  </div>
                </Col>
                <Col lg="3" md="4" sm="6" xs="6">
                  <div className="product-mg">
                    <img
                      src="/assets/img/images/login_img-2.png"
                      className="img-fluid "
                    />
                    <div className="product-name">
                      <h3>HOODIES</h3>
                    </div>
                  </div>
                </Col>
                <Col lg="3" md="4" sm="6" xs="6">
                  <div className="product-mg">
                    <img
                      src="/assets/img/images/login_img-2.png"
                      className="img-fluid "
                    />
                    <div className="product-name">
                      <h3>KURTAS</h3>
                    </div>
                  </div>
                </Col>
                <Col lg="3" md="4" sm="6" xs="6">
                  <div className="product-mg">
                    <img
                      src="/assets/img/images/login_img-2.png"
                      className="img-fluid "
                    />
                    <div className="product-name">
                      <h3>SPORTS WEAR</h3>
                    </div>
                  </div>
                </Col>
                <Col lg="3" md="4" sm="6" xs="6">
                  <div className="product-mg">
                    <img
                      src="/assets/img/images/login_img-2.png"
                      className="img-fluid "
                    />
                    <div className="product-name">
                      <h3>TOPS</h3>
                    </div>
                  </div>
                </Col>
      
              </Row>
            </div>
            <div className="productGrid mt-5">
              {/* <Row>
                {
                    product.map((data,index) => {

                        return(
                            <Col md='3' sm='4' xs='6' >
                            <div className="product-mg mob-down">
                                <img
                                src={data.thumbnail_image}
                                className="img-fluid  "
                              />
                            <div className="product-name">
                              <h3>{data.name}</h3>
                            </div>
                                </div>
                            </Col >
                        )
                    })
                }
              </Row> */}
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default SubCategories;
