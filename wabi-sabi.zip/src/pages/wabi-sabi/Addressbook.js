import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "./Header/Header";
import Footer from "./Footer/Footer";

import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import { HeartOutlined,PlusSquareOutlined  } from "@ant-design/icons";


const Addressbook = () => {
  const [show, setShow] = useState(false);

  const [icon, setIcon] = useState(false)
  const [icon2, setIcon2] = useState(true)

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <div className="contact-head head-fixed">
        <Header />
      </div>
      <div className="head-sm mb-5">
        <div className="d-flex justify-content-between">
          <div>
            <i class="fa fa-chevron-left"></i>
          </div>
          <div className="text-center">
            <span>Address Book</span>
          </div>
          <div>
            <i className="fa fa-bell" aria-hidden="true"></i>
          </div>
        </div>
      </div>

      <section id="adress">
        <div className="container">
          <h4 className="mb-5 mt-5 head-path1">
            <a href="#">Profile</a> / <a href="#">Address Book</a>
          </h4>
          <h5 className="d-lg-none d-md-none d-sm-none d-none mb-4">
            AddYourAddressForShipping
          </h5>
          <div className="d-address">
            <h4 className="fw-light">DEFAULT ADDRESS</h4>

            <div className="row">
              <div className="col-sm-6 mb-3">
                <div className="card">
                  <div className="card-body">
                    <div className="float-end">
                      {/* <input
                        className="form-check-input  rounded-circle"
                        type="checkbox"
                        id="checkboxNoLabel"
                        value=""
                        aria-label="..."
                      /> */}
                   <h3 className={icon2 ? 'icon2' : 'icon1'} onClick={()=> setIcon2(icon2 ? false : true)}><i className="fa fa-check-circle"></i></h3>
                    </div>
                    <h4 className="card-title">Office</h4>
                    <h5 className="card-title">Aniruth Kumar</h5>
                    <small className="card-text fw-light">
                      796, Mellow designs, 1st floor, 3rd main, 4th block
                      <br />
                      Rajajinagar IVth Block <br />
                      Bangalore-560010 <br />
                      Karnataka Mobile: 7978488913 <br />
                    </small>
                    <div className="row mt-3">
                      <div className="col text-center">
                        <button className=" address-b">EDIT</button>
                      </div>
                      <div className="col b-cen  text-center">
                        <button className=" ">DELETE</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-sm-6 mb-3">
                <div className="card">
                  <div className="card-body">
                    <div className="float-end">
                      <h3 className={icon ? 'icon2' : 'icon1'} onClick={()=> setIcon(icon ? false : true)}><i className="fa fa-check-circle"></i></h3>
                    </div>
                    <h4 className="card-title">Home</h4>
                    <h5 className="card-title">Aniruth Kumar</h5>
                    <small className="card-text fw-light">
                      796, Mellow designs, 1st floor, 3rd main, 4th block
                      <br />
                      Rajajinagar IVth Block <br />
                      Bangalore-560010 <br />
                      Karnataka Mobile: 7978488913 <br />
                    </small>
                    <div className="row mt-3">
                      <div className="col text-center">
                        <button className=" address-b">EDIT</button>
                      </div>
                      <div className="col b-cen  text-center">
                        <button className=" ">DELETE</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="add-address  text-center rounded">
           
              <h4  
                    // data-bs-toggle="modal"
                    // href="#addressModalToggle"
                    // role="button"    
                     onClick={handleShow}          
                    >
                {" "}
                <span className="border border-warning text-warning mx-2 ">+</span> 
                Add an Address
              </h4>
            </div>
          </div>
          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>New Address</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Row>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      First Name
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Middle Name
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Last Name
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Country
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Street Address
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Street Address 2
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      City
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      State
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      ZIP/Postal Code
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col md="6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Phone Number
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </Col>
                <Col>
                  <div className="mb-3 form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="exampleCheck1"
                    />
                    <label className="form-check-label" for="exampleCheck1">
                      Make this my default address
                    </label>
                  </div>
                </Col>
                <div className="text-center">
                  <button className="address-b">SAVE</button>
                </div>
              </Row>
            </Modal.Body>
          </Modal>
          
          {/* <div
            class="modal fade"
            id="addressModalToggle"
            aria-hidden="true"
            aria-labelledby="addressModalToggleLabel"
            tabindex="-1"
          >
            <div class="modal-dialog modal-dialog-centered  modal-fullscreen-sm">
              <div class="modal-content">
                <div class="modal-header border border-0">
                <div className="modal-title text-center">New Address</div>
                  <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  ></button>
                </div>
                <div class="modal-body px-4">
                <div className="row">
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      First Name
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Middle Name
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Last Name
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Country
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Street Address
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Street Address 2
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      City
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      State
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      ZIP/Postal Code
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  {" "}
                  <div className="mb-3">
                    <label for="exampleInputEmail1" className="form-label">
                      Phone Number
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="exampleInputEmail1"
                      aria-describedby="emailHelp"
                    />
                  </div>
                </div>
                <div className="col">
                  <div className="mb-3 form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="exampleCheck1"
                    />
                    <label className="form-check-label" for="exampleCheck1">
                      Make this my default address
                    </label>
                  </div>
                </div>
                <div className="text-center">
                  <button className="address-b">SAVE</button>
                </div>
              </div>
                </div>
              </div>
            </div>
          </div> */}
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Addressbook;
