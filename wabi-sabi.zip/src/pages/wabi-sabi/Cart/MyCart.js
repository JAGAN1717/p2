import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import {getCart,getcartSummary,getcartCount,destroyCart,paymentType,getState,getContries} from "./core/_request";
import { Alert, Space, Spin } from "antd";
import { ToastContainer, toast } from 'react-toastify';
import { useNavigate } from "react-router-dom";
import Accordion from "react-bootstrap/Accordion";

const Mycart = () => {

  const navigate = useNavigate();
  const [cartData,setCartdata] = useState([]);
  const [cartsummary,setcartsummary] = useState();
  const [qnt,setQnt] = useState(1);
  const [state,setState] = useState([]);
  const [countries,setCountries] = useState([]);

  const addQnt = () => {
    let val = qnt + 1
    setQnt(val)
  }
  const decQnt = () => {
    let val = qnt - 1
    if(val < 1) val = 1
    setQnt(val)
  }

  const cartInfo = async() => {
    const cart = await getCart()
    cart.forEach(data =>{
      console.log('getcartmap',data.cart_items);
      setCartdata(data.cart_items)
    })
    console.log('getcart',cart);
  }

  const Cartsummary = async() => {
    const cart = await getcartSummary()
    console.log('Cartsummary',cart);
    setcartsummary(cart)
  }

  const PaymentMethod = async() => {
    navigate('/checkout')
    const payment = await paymentType()
    console.log('paymennt',payment);
  }

  const stateDropdown = async() => {
    const state = await getState()
    console.log('state',state);
    setState(state.data);
  }

  const contriesDropdown = async() => {
    const countries = await getContries()
    console.log('countries',countries);
    setCountries(countries.data);
  }

  const removeCart = async(id) => {
    const cart = await destroyCart(id)
    console.log('removed',cart);
    toast.success("REMOVED SUCCESSFULLY", {
      position: toast.POSITION.BOTTOM_RIGHT
  });
  cartInfo();
  Cartsummary();
  document.getElementById('overAllcountData')?.click()
  }
  
  const Cartcount = async() => {
    const cart = await getcartCount()
    console.log('Cartcount',cart);
  }
  useEffect(() =>{
    cartInfo();
    Cartsummary();
    Cartcount();
    stateDropdown();
    contriesDropdown();
  },[])

  return (
    <>
      <div className="contact-head head-fixed">
        <Header />
      </div>
      <ToastContainer />
      <div className="head-sm mb-5">
        <div className="d-flex justify-content-between">
          <div>
            <i class="fa fa-chevron-left"></i>
          </div>
          <div className="text-center">
            <span>My Cart</span>
          </div>
          <div>
            <i className="fa fa-bell" aria-hidden="true"></i>
          </div>
        </div>
      </div>

      <section id="cart">
        <div className="container">
          <h4 className="mb-5 mt-5 head-path1">
            <a href="#">Profile</a> / <a href="#">My Cart</a>
          </h4>

          <div className="row">
          <div className="cart-product col-md-6 col-12">
            {
              cartData.length > 0  ? 
              cartData.map((data,index)=>{
                return(<>
               <div class="card shadow mb-3">
                <div class="row g-0">
                  <div class="col-3">
                    <img
                      src={data.product_thumbnail_image}
                      class="mx-2"
                      alt="..."
                    />
                  </div>
                  <div class="col-9">
                    <div class="card-body">
                      <h4 class="card-title fw-semibold text-truncate">
                       {data.product_name}
                      </h4>
                      <div className="d-flex">
                        <p className="fw-light">Color:</p>{" "}
                        <p className=" color mx-2 p-2 my-1"></p>
                      </div>
                      <div className="d-flex">
                        <p className="fw-light">Size :</p>{" "}
                        <p className="fw-light px-2">L</p>
                      </div>
                      <h4 className="fw-bold">₹ {data.price}</h4>
                      <div className="">
                        <div className="d-flex">
                          <div className="d-size border mx-2 p-1 px-2" onClick={decQnt}>
                            <span><a>-</a></span>
                          </div>
                          <div className="rounded mx-2 p-1">
                            <span>{qnt}</span>
                          </div>
                          <div className="d-size border mx-2 p-1 px-2" onClick={addQnt}>
                            <span><a>+</a></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="row mb-4 cart-btn">
                    <div className="col text-center">
                      <button className=" address-b" onClick={()=>removeCart(data.id)}>REMOVE</button>
                    </div>
                    <div className="col b-cen  text-center">
                      <button className=" ">MOVE TO WISHLIST</button>
                    </div>
                  </div>
                </div>
              </div>
                </>)
              })
              :
              // <h3 className="text-center"> Your Cart is Empty !</h3>
              <div className="spin-h">
                <Spin tip="Loading" size="large">
                <div className="content" />
              </Spin>
              </div>
            //   <div class="card shadow mb-3">
            //     <div class="row g-0">
            //       <div class="col-3">
            //         <img
            //           src="assets\img\images\image_2022_11_21T05_15_54_617Z.png"
            //           class="mx-2"
            //           alt="..."
            //         />
            //       </div>
            //       <div class="col-9">
            //         <div class="card-body">
            //           <h4 class="card-title fw-semibold">
            //             Zara Men Solid Slim Shirt
            //           </h4>
            //           <div className="d-flex">
            //             <p className="fw-light">Color:</p>{" "}
            //             <p className=" color mx-2 p-2 my-1"></p>
            //           </div>
            //           <div className="d-flex">
            //             <p className="fw-light">Size :</p>{" "}
            //             <p className="fw-light px-2">L</p>
            //           </div>
            //           <h4 className="fw-bold">₹600.00</h4>
                        
            //           <div className="">
            //             <div className="d-flex">
            //               <div className="d-size border mx-2 p-1 px-2" onClick={decQnt}>
            //                 <span><a>-</a></span>
            //               </div>
            //               <div className="rounded mx-2 p-1">
            //                 <span>{qnt}</span>
            //               </div>
            //               <div className="d-size border mx-2 p-1 px-2" onClick={addQnt}>
            //                 <span><a>+</a></span>
            //               </div>
            //             </div>
            //           </div>
            //         </div>
            //       </div>
            //       <div className="row mb-4 cart-btn">
            //         <div className="col text-center">
            //           <button className=" address-b">REMOVE</button>
            //         </div>
            //         <div className="col b-cen  text-center">
            //           <button className=" ">MOVE TO WISHLIST</button>
            //         </div>
            //       </div>
            //     </div>
            //   </div>
            }
            </div>
            <div className="cart-total col-md-6 col-12 ">
              <div className="d-none d-md-block">
              {
                cartsummary ?
                <div class="card shadow mb-3 px-3 pt-3">
                <div class="row g-0">
                  <div class="col-6 text-start ">
                    <h4>Subtotal</h4>
                    <h4>Estimated Shipping</h4>
                    <h4>Estimated Total</h4>
                  </div>
                  <div class="col-6 text-end">
                    <div>
                      <h4>{cartsummary.sub_total}</h4>
                      <h4>{cartsummary.shipping_cost}</h4>
                      <h4>{cartsummary.grand_total}</h4>
                    </div>
                  </div>
                  <div className="mt-3 text-center mb-4">
                    <button className="mx-4 proceed" onClick={()=>PaymentMethod()}>
                      PROCEED TO CHECKOUT
                    </button>
                  </div>
                </div>
              </div>
              :
              <div class="card shadow mb-3 px-3 pt-3">
              <div class="row g-0">
                <div class="col-6 text-start ">
                  <h4>Subtotal</h4>
                  <h4>Estimated Shipping</h4>
                  <h4>Estimated Total</h4>
                </div>
                <div class="col-6 text-end">
                  <div>
                    <h4>₹ 2100.00</h4>
                    <h4>Free</h4>
                    <h4>₹ 2100.00</h4>
                  </div>
                </div>
                <div className="mt-3 text-center mb-4">
                  <button className="mx-4 proceed">
                    PROCEED TO CHECKOUT
                  </button>
                </div>
              </div>
            </div>
              }
              </div>
              <Accordion
                defaultActiveKey={["0"]}
                className="rounded mb-5"
                alwaysOpen
              >
                <Accordion.Item eventKey="0">
                  <Accordion.Header>Estimate Your Shipping</Accordion.Header>
                  <Accordion.Body>
                    For shipping estimates before proceeding to checkout, please
                    provide the Country, State, and ZIP for the destination of
                    your order.
                    <h4 className="mt-4">Destination</h4>
                    <div class="mb-4">
                      <label class="form-label">Country</label>
                      <select class="form-select">
                      {
                          countries.map((data)=>{
                            return(<>
                        <option value={data.id}>{data.name}</option>
                            </>)
                          })
                        }
                      </select>
                    </div>
                    <div class="mb-4">
                      <label class="form-label">State</label>
                      <select class="form-select">
                        {
                          state.map((data)=>{
                            return(<>
                        <option value={data.id}>{data.name}</option>
                            </>)
                          })
                        }
                      </select>
                    </div>
                    <div class="mb-4">
                      <label class="form-label">ZIP / Posted Code</label>
                      <input
                        type="text"
                        value="600068"
                        className="form-control"
                      />
                    </div>
                    <h5>Shipping Methods</h5>
                    <div class="form-check mb-3">
                      <input
                        class="form-check-input"
                        type="radio"
                        name="inlineRadioOptions"
                        id="inlineRadio1"
                        value="option1"
                      />
                      <label class="form-check-label" for="inlineRadio1">
                        Free
                      </label>
                    </div>
                    <div class="form-check ">
                      <input
                        class="form-check-input"
                        type="radio"
                        name="inlineRadioOptions"
                        id="inlineRadio2"
                        value="option2"
                      />
                      <label class="form-check-label" for="inlineRadio2">
                        Fixed
                      </label>
                    </div>
                  </Accordion.Body>
                </Accordion.Item>
                <Accordion.Item eventKey="1">
                  <Accordion.Header>Enter Promo Code</Accordion.Header>
                  <Accordion.Body>
                    <div class="mb-3">
                      <label class="form-label">Promo Code</label>
                      <div className="d-flex">
                        <input
                          type="text"
                          placeholder="Enter Code"
                          className="form-control "
                        />
                        <button className="float-end proceed rounded mx-5 ">
                          APPLY
                        </button>
                      </div>
                    </div>
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion>
              <div className="d-block d-md-none">
              {
                cartsummary ?
                <div class="card shadow mb-3 px-3">
                <div class="row g-0">
                  <div class="col-6 text-start ">
                    <h4>Subtotal</h4>
                    <h4>Estimated Shipping</h4>
                    <h4>Estimated Total</h4>
                  </div>
                  <div class="col-6 text-end">
                    <div>
                      <h4>{cartsummary.sub_total}</h4>
                      <h4>{cartsummary.shipping_cost}</h4>
                      <h4>{cartsummary.grand_total}</h4>
                    </div>
                  </div>
                  <div className="mt-3 text-center mb-4">
                    <button className="mx-4 proceed">
                      PROCEED TO CHECKOUT
                    </button>
                  </div>
                </div>
              </div>
              :
              <div class="card shadow mb-3 px-3">
              <div class="row g-0">
                <div class="col-6 text-start ">
                  <h4>Subtotal</h4>
                  <h4>Estimated Shipping</h4>
                  <h4>Estimated Total</h4>
                </div>
                <div class="col-6 text-end">
                  <div>
                    <h4>₹ 2100.00</h4>
                    <h4>Free</h4>
                    <h4>₹ 2100.00</h4>
                  </div>
                </div>
                <div className="mt-3 text-center mb-4">
                  <button className="mx-4 proceed">
                    PROCEED TO CHECKOUT
                  </button>
                </div>
              </div>
            </div>
              }
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Mycart;
