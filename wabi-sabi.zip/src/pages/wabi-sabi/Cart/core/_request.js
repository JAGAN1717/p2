import React from "react";
// Axios
import axios from "axios";

const API_URL = process.env.REACT_APP_WABI

const CART_URL = `${API_URL}/carts`
const CART_SUMMARY_URL = `${API_URL}/cart-summary`
const CART_COUNT_URL = `${API_URL}/cart-count`
const CART_DESTROY_URL = `${API_URL}/carts/destroy`
const PAYMENET_TYPE_URL = `${API_URL}/payment-types`
const STATES_DROPDOWN_URL = `${API_URL}/states`
const COUNTRIES_DROPDOWN_URL = `${API_URL}/countries`
const UPDATE_SHIPPING_TYPE_URL = `${API_URL}/update-shipping-type-in-cart`
const UPDATE_ADDRESS_CART_URL = `${API_URL}/update-address-in-cart`
const REMOVE_COUPON_URL = `${API_URL}/coupon-remove`
const DELIVERY_INFO_URL = `${API_URL}/delivery-info`

const token = localStorage.getItem('token')
const config = {
    headers: { Authorization: `Bearer ${token}` }
};

// get Cart List
export function getCart(){
    return axios.post(CART_URL,'',config)
    .then(response => response.data)
}

// get cart Details
export function getcartSummary(){
    return axios.get(CART_SUMMARY_URL,config)
    .then(response => response.data)
}

// cart count Details
export function getcartCount(){
    return axios.get(CART_COUNT_URL,config)
    .then(response => response.data)
}

// destroy cart items
export function destroyCart(id){
    return axios.post(CART_DESTROY_URL + '/' + id,'',config)
    .then(response => response.data)
}

// Payment Type 
export function paymentType(){
    return axios.get(PAYMENET_TYPE_URL,config)
    .then(response => response.data)
}

// state dropdown  
export function getState(){
    return axios.get(STATES_DROPDOWN_URL)
    .then(response => response.data)
}

// countries dropdown  
export function getContries(){
    return axios.get(COUNTRIES_DROPDOWN_URL)
    .then(response => response.data)
}

// update cart shipping type   
export function updateShippingType(id,type){
    return axios.post(UPDATE_SHIPPING_TYPE_URL,{
        shipping_type : type,
        shipping_id : id
    },config)
    .then(response => response.data)
}

// update Address in cart   
export function updateAddressCart(id){
    return axios.post(UPDATE_ADDRESS_CART_URL,{
        address_id : id
    },config)
    .then(response => response.data)
}

// Remove coupon code    
export function removeCoupon(id){
    return axios.post(REMOVE_COUPON_URL,{ },config)
    .then(response => response.data)
}

// Remove coupon code    
export function deliveryInfo(id){
    return axios.get(DELIVERY_INFO_URL,config)
    .then(response => response.data)
}