import React from "react";
// Axios
import axios from "axios";

const API_URL = process.env.REACT_APP_WABI

export const BRAND_URL = `${API_URL}/brands`
export const CATEGORIES_URL = `${API_URL}/categories`
export const PRODUCT_URL = `${API_URL}/products`
export const WISHLIST_URL = `${API_URL}/wishlists`
export const TESTMONIALS_URL = `${API_URL}/testimonials`
export const COUNTERS_URL = `${API_URL}/profile/counters`

const token = localStorage.getItem('token')
const config = {
    headers: { 
        "Authorization": `Bearer ${token}`,
     }
};

// Brand API
export function getBrand(){
    return axios.get(BRAND_URL)
    .then(response =>response.data)
}

// Categories API
export function getCategories(){
    return axios.get(CATEGORIES_URL)
    .then(response =>response.data)
}

// product list
export function product(){
    return axios.get(PRODUCT_URL)
    .then(response => response.data)
}

// wishlist 
export function getWishlist(){
    return axios.get(WISHLIST_URL,config)
    .then(response => response.data)
}

// testimonials list
export function testimonialsList(){
    return axios.get(TESTMONIALS_URL)
    .then(response => response.data)
}

// COUNTERS_URL
export function getCountList(){
    return axios.get(COUNTERS_URL,config)
    .then(response => response.data)
}