import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "./Header/Header";
import Footer from "./Footer/Footer";
import {paymentType} from './Cart/core/_request'

const Checkout = () => {
const [payType,setPaytype] = useState([])

const PaymentMethod = async() => {
    const payment = await paymentType()
    console.log('paymennt12',payment);
    setPaytype(payment)
  }

  useEffect(() =>{
  PaymentMethod()
  },[])

  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>
      <section id="check-out">
        <div className="container">
          <div className="checkOut">
            <div className="pay-h row py-3  border-bottom">
              <div className="hh d-flex col-6">
                <span className="fs-4 fw-bold">Wearup</span>
                <span className="text-muted mx-5 fs-6 text-truncate">Order OverView</span>
              </div>

              <div className="row col-6">
                <span className="fs-6 text-truncate col-4">Information</span>
                <span className="fs-6 text-truncate col-4">Payment Details</span>
                <span className="fs-6 text-truncate col-4">Complete Order</span>
              </div>
            </div>

            <div className="row mt-5">
              <div className="col-lg-6 col-md-12">
                <div className="text-start w-75">
                  <span className="fs-5 fw-bold">Summary Order</span>
                  <p>
                    Check your item and select your shipping for better
                    experiance order item
                  </p>
                </div>

                <div class="card mt-3">
                  <div class="card-body">
                    <div class="mb-3">
                      <div class="row g-0">
                        <div class="col-sm-2 col-3  border">
                          <img
                            src="\assets\img\logo\2.jpg"
                            className="img-fluid rounded-start h-100"
                          />
                        </div>
                        <div class="col-sm-7 col-6">
                          <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">
                              <small class="text-muted text-truncate">
                                Last updated 3 mins ago
                              </small>
                            </p>
                          </div>
                        </div>
                        <div className="col-sm-3 col-3">
                          <p className="text-muted text-truncate">42 EU -8.5 US</p>
                        </div>
                      </div>
                    </div>

                    <div class="mb-3">
                      <div class="row g-0">
                        <div class="col-sm-2 col-3  border">
                          <img
                            src="\assets\img\logo\2.jpg"
                            className="img-fluid rounded-start h-100"
                          />
                        </div>
                        <div class="col-sm-7 col-6">
                          <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">
                              <small class="text-muted text-truncate">
                                Last updated 3 mins ago
                              </small>
                            </p>
                          </div>
                        </div>
                        <div className="col-sm-3 col-3">
                          <p className="text-muted text-truncate">42 EU -8.5 US</p>
                        </div>
                      </div>
                    </div>

                    <div class="mb-3">
                      <div class="row g-0">
                        <div class="col-sm-2 col-3  border">
                          <img
                            src="\assets\img\logo\2.jpg"
                            className="img-fluid rounded-start h-100"
                          />
                        </div>
                        <div class="col-sm-7 col-6">
                          <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">
                              <small class="text-muted text-truncate">
                                Last updated 3 mins ago
                              </small>
                            </p>
                          </div>
                        </div>
                        <div className="col-sm-3 col-3">
                          <p className="text-muted text-truncate">42 EU -8.5 US</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-4">
                  <span className="fs-6">Avalible Shipping Method</span>
                  {
                    payType.map((data) =>{
                      return(<>
                  <div className="row mt-3 mb-3">
                    <div className="col-2">
                      <img
                        src={data.image}
                        className="img-fluid rounded-start "
                      />
                    </div>
                    <div className="col-7">
                      <div class="card-body">
                        <h5 class="card-title">{data.name
                    }</h5>
                        <p class="card-text">
                          <small class="text-muted">
                            {data.title}
                          </small>
                        </p>
                      </div>
                    </div>
                    <div className="col-3 d-flex">
                      <p className="fw-bold">$12.00</p>
                      <div class="form-check">
                        <input
                          className="form-check-input mx-1"
                          type="radio"
                          name="flexRadioDefault"
                          id="flexRadioDefault1"
                        />
                      </div>
                    </div>
                  </div>                   
                     </>)
                    })
                  }
                </div>
              </div>
              <div className="col-lg-6 col-md-12">
                <div className="text-start w-75">
                  <span className="fs-5 fw-bold">Payment Details</span>
                  <p>
                    Check your item and select your shipping for better
                    experiance order item
                  </p>
                </div>

                <form>
                  <div class="mb-3">
                    <label for="validationServerUsername" class="form-label">
                      Username
                    </label>
                    <div class="input-group has-validation">
                      <span class="input-group-text" id="inputGroupPrepend3">
                        @
                      </span>
                      <input
                        type="text"
                        class="form-control -valid"
                        id="validationServerUsername"
                        placeholder="Sample@gmail.com"
                        aria-describedby="inputGroupPrepend3 validationServerUsernameFeedback"
                        required
                      />
                    </div>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">
                      Card Details
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="exampleInputPassword1"
                    />
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">
                      Card Holder
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="exampleInputPassword1"
                    />
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">
                      Billing Address
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="exampleInputPassword1"
                    />
                    <input
                      type="text"
                      class="form-control"
                      id="exampleInputPassword1"
                    />
                  </div>

                  <div className="d-flex justify-content-between">
                    <div>
                    <p className="mb-2 text-start">Subtotal</p>
                    <p className="mb-2 text-start">Vat (20%)</p>
                    <p className="mb-2 text-start fw-bold">Total</p>
                    </div>
                    <div>
                    <p className="mb-2 text-end">$655.00</p>
                    <p className="mb-2 text-end">$655.00</p>
                    <p className="mb-2 text-end fw-bold">$655.00</p>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default Checkout;
