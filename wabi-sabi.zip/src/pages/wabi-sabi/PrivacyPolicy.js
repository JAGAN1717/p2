import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "./Header/Header";
import Footer from "./Footer/Footer";

const PrivacyPolicy = () => {
  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>

      <section id="privacy">
        <div className="container">
          <h4 className="mb-5 mt-5 head-path1 d-lg-block d-md-block d-none">
            <a href="#">Profile</a> / <a href="#">Privacy Policy</a>
          </h4>

          <h4 className="text-center">Privacy Policy</h4>

          <div className="privacy">
            <p className="fw-light">
              A Privacy Policy is a statement or a legal document that states
              how a company or website collects, handles and processes data of
              its customers and visitors. It explicitly describes whether that
              information is kept confidential, or is shared with or sold to
              third parties.
            </p>
            <p className="fw-light">
              Additionally, Pinterest also states that it collects user location
              data from mobile devices, and if someone makes a purchase on
              Pinterest, payment and contact information - including an address
              and phone number - will be collected. If users buy products or
              services for others, Pinterest gathers their contact information
              and shipping details, too.
            </p>
            <p className="fw-light">
              Users may also give Pinterest permission to access information
              that is shared with other websites like Facebook and Twitter by
              linking their Pinterest account with them. This information would
              also include information about their friends and followers. The
              account settings have information about how much access Pinterest
              has to their users' data.
            </p>
            <p className="fw-light">
              {" "}
              In sum, a Privacy Policy is where you let your users know all
              about how you make sure their privacy is respected by your
              business practices.
            </p>

            <p className="fw-light">
              <p className="fw-bold"> Why you Need a Privacy Policy</p>
              Privacy is not a new concept. Humans have always desired privacy
              in their social as well as private lives. But the idea of privacy
              as a human right is a relatively modern phenomenon.
            </p>
            <p className="fw-light">
              Around the world, laws and regulations have been developed for the
              protection of data related to government, education, health,
              children, consumers, financial institutions, etc.
            </p>
            <p className="fw-light">
              This data is critical to the person it belongs to. From credit
              card numbers and social security numbers to email addresses and
              phone numbers, our sensitive, personally identifiable information
              is important. This sort of information in unreliable hands can
              potentially have far-reaching consequences.
            </p>
            <p className="fw-light">
              Companies or websites that handle customer information are
              required to publish their Privacy Policies on their business
              websites. If you own a website, web app, mobile app or desktop app
              that collects or processes user data, you most certainly will have
              to post a Privacy Policy on your website (or give in-app access to
              the full Privacy Policy agreement).
            </p>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default PrivacyPolicy;
