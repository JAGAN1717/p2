import { useState, useEffect } from "react";

import Header from "../Header/Header";
import Footer from "../Footer/Footer";

//react bootstrap
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";


const Contact = () => {
  const [name, setName] = useState("");
  const [number, setNumber] = useState("");
  const [email, setEmail] = useState("");
  const [comment, setComment] = useState("");

  const initialValues = {
    fullName: "",
    email: "",
    phoneNumber: "",
    comment: "",
  };
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(formValues));
    setIsSubmit(true);
  };

  useEffect(() => {
    console.log(formErrors);
    if (Object.keys(formErrors).length === 0 && isSubmit) {
      // console.log(formValues);
    }
  }, [formErrors]);
  const validate = (values) => {
    const errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.fullName) {
      errors.fullName = " name is required!";
    }
    if (!values.email) {
      errors.email = "Email is required!";
    } else if (!regex.test(values.email)) {
      errors.email = "This is not a valid email format!";
    }
    if (!values.phoneNumber) {
      errors.phoneNumber = "Phone Number is required!";
    }
    if (!values.comment) {
      errors.comment = "comment is Empty";
    }
    return errors;
  };

  console.log("con", formValues);

  return (
    <>
      <div className="contact-head head-fixed">
        <Header />
      </div>

      <div className="head-sm">
        <div className="d-flex justify-content-between">
          <div>
            <i class="fa fa-chevron-left"></i>
          </div>
          <div className="text-center">
            <span>Contact Us</span>
          </div>
          <div>
            <i className="fa fa-bell" aria-hidden="true"></i>
          </div>
        </div>
      </div>

      {/* contact-Us */}
      <section id="contact">
        <div className="container contact-us">
          <h4 className="mb-5 mt-5 d-sm-block d-none">
            <a href="#">Home</a> / <a href="#">Contact Us </a>
          </h4>
          <Container>
            <Row className="log2">
              <Col lg={5} md={5} sm="12" className="Log-mg ">
                <img src="/assets/img/Images/contact.png" alt="Log-mg" />
              </Col>
              <Col lg={7} md={7} sm="12">
                <div className="contact-card py-3 shadow-sm">
                <div className="con-head mt-4 px-4">
                  <h1>Contact Us</h1>
                  <span>Wriyte Us</span>
                </div>
                <form className="px-4 mb-5" onSubmit={handleSubmit}>
                  <Row>
                    <Col md="6" sm="12" className="mb-5">
                      <input
                        type="text"
                        name="fullName"
                        className="form-control"
                        placeholder="Full Name"
                        value={formValues.fullName}
                        onChange={handleChange}
                        // onChange={(e)=>setName(e.target.value)}
                      />
                      <p>{formErrors.fullName}</p>
                    </Col>
                    <Col md="6" sm="12" className="mb-5">
                      <input
                        type="text"
                        name="email"
                        className="form-control"
                        placeholder="E-Mail"
                        value={formValues.email}
                        onChange={handleChange}
                        // onChange={(e)=>setEmail(e.target.value)}
                      />
                      <p>{formErrors.email}</p>
                    </Col>
                  </Row>
                  <Row>
                    <Col lg="6" className="mb-5">
                      <input
                        type="text"
                        name="phoneNumber"
                        className="form-control"
                        placeholder="Phone Number"
                        value={formValues.phoneNumber}
                        onChange={handleChange}
                        //   onChange={(e)=>setNumber(e.target.value)}
                      />
                      <p>{formErrors.phoneNumber}</p>
                    </Col>
                  </Row>
                  <div className="form-floating mb-5">
                    <textarea
                      className="form-control"
                      name="comment"
                      placeholder="Leave a comment here"
                      id="floatingTextarea2"
                      value={formValues.comment}
                      onChange={handleChange}
                      //   onChange={(e)=>setComment(e.target.value)}
                    ></textarea>
                    <label for="floatingTextarea2">What's on your Mind?</label>
                    <p>{formErrors.comment}</p>
                  </div>
                  <Row>
                    <Col lg="6">
                      <button type="submit" className="btn">
                        SUBMIT
                      </button>
                    </Col>
                  </Row>
                </form>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default Contact;
