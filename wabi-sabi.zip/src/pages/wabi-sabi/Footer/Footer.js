import {getSocialLink} from '../Products/core/_request'
import {useNavigate,Link } from "react-router-dom";
import React, { useState, useEffect } from "react";

const Footer = () => {
  
  const [Sociallink,setSocialLinks]=useState([])
  
  
  const SocilaLink = async() => {
    const links = await getSocialLink()
    console.log('Link2',links.data)
    setSocialLinks(links.data);
  }
  
  useEffect(() =>{
    SocilaLink();
  },[])
  
  
  return (
    <>
      <footer className="footer-wabi ">
        <div className="container">
          <div className="row pt-5">
            <div className="text-left col-3 foot-  mx-auto">
              <h1 className="text-white">WABI SABI</h1>
              <p className="text-light fw-lighter">
                Lorem ipsum dolor sit amet. Ut quibusdam voluptas et aliquam
                aliquam aut sapiente magni. A magnam iure ut nisi maiores a
                explicabo consequatur.
              </p>
            </div>
            <div className="text-left col-3 foot- text-white fw-light ">
              <h4 className="text-white">CONTACT INFO</h4>
              <span >ADDRESS:</span>
              <p className="text-light fw-lighter">123 Street Name,City,England</p>
              <span>PHONE:</span>
              <p className="text-light fw-lighter">+91 988765443</p>
              <span>EMAIL:</span>
              <p className="text-light fw-lighter">EXAMPLE@gmail.com</p>
              <span className="text-white d-flex ">
                {
                      Sociallink.slice(0,3).map((data,index) =>{

                        return(<>
                      <div className="social2 text-center">
                        <i className={`fa fa-${data.type.split('_',1)[0]}`} onClick={()=> window.open(data.value,'_blank')}></i>
                      </div>                        
                        </>)
                      })
                }
                {/* <div className="social2 text-center">
                  {" "}
                  <i className="fa fa-twitter"></i>
                </div>
                <div className="social2 text-center">
                  {" "}
                  <i className="fa fa-instagram"></i>
                </div> */}
              </span>
            </div>
            <div className="text-left col-2 foot-  mx-auto">
              <h4 className="text-light">CUSTERSERVICE</h4>
              <h5 className="text-light fw-lighter">Help & FAQs</h5>
              <h5 className="text-light fw-lighter">OrderTracking</h5>
              <h5 className="text-light fw-lighter">Shipping</h5>
              <h5 className="text-light fw-lighter">OrdersHistory</h5>
              <h5 className="text-light fw-lighter">Advancedsearch</h5>
              <h5 className="text-light fw-lighter">MyAccount</h5>
              <h5 className="text-light fw-lighter">Careers</h5>
              <h5 className="text-light fw-lighter">AboutUs</h5>
              <h5 className="text-light fw-lighter">CorporateSales</h5>
              <h5 className="text-light fw-lighter">Privacy</h5>
            </div>
            <div className="text-left col-3 foot-  mx-1">
              <h4 className="text-white">POPULAR TAGS</h4>
              <div className="d-flex justify-content-between mt-4 foot-b">
                <button type="button">Fashion</button>
                <button type="button">Blue</button>
                <button type="button">Clothes</button>
              </div>
              <div className="d-flex justify-content-between mt-2 foot-b">
                <button type="button">Jean</button>
                <button type="button">Shirt</button>
                <button type="button">Winter</button>
              </div>
              <div className="d-flex justify-content-between mt-2 foot-b">
                <button type="button">Sports</button>
                <button type="button">Black</button>
                <button type="button">Sweater</button>
              </div>
              <div className="row justify-content-between mt-4 foot-b2 d-none">
                <button type="button" className="col-4 mb-3">
                  Fashion
                </button>
                <button type="button" className="col-4 mb-3">
                  Blue
                </button>
                <button type="button" className="col-4 mb-3">
                  Clothes
                </button>
                <button type="button" className="col-4 mb-3">
                  Fashion
                </button>
                <button type="button" className="col-4 mb-3">
                  Blue
                </button>
                <button type="button" className="col-4 mb-3">
                  Clothes
                </button>
                <button type="button" className="col-4 mb-3">
                  Fashion
                </button>
                <button type="button" className="col-4 mb-3">
                  Blue
                </button>
                <button type="button" className="col-4 mb-3">
                  Clothes
                </button>
              </div>
            </div>
          </div>
        </div>
        <hr />
        <div className="container">
          <div className="foot-bottom ">
            <small className="text-start">
              Wabi.sabi.@ 2020.All Rights Reserved
            </small>
            <img src="assets\img\images\pay-img.png" className="float-end " />
          </div>
        </div>
      </footer>
      <footer className="m-foot p-3">
        <div className="container foot-icons">
          <div className="d-flex justify-content-evenly">
          <Link to='/'> <i className="fa fa-home" aria-hidden="true"></i></Link>
          <Link to='/wishlist'>  <i className="fa fa-heart " aria-hidden="true"></i></Link>
          <Link to='/cart'>  <i className="fa fa-shopping-cart " aria-hidden="true"></i></Link>
          <Link to='/account1'>  <i className="fa fa-user" aria-hidden="true"></i></Link>
            {/* <i className="fa fa-user page-link" aria-hidden="true"></i> */}
          </div>
        </div>
      </footer>
    </>
  )
};

export default Footer;
