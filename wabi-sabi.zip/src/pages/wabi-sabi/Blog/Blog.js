import React from "react";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";

const Blog = () => {
  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>
      <section id="blogInfo">
        <div className="container">
          <div className="">
            <div className="mb-4">
              <h2 className="mb-4">
                The Ultimate Comparison: Indiegogo vs Kickstarter
              </h2>
              <p class="text-muted">Last updated 3 mins ago</p>
              <hr />
            </div>
            <div className="row">
              <div className="d-1 col-lg-8 col-md-6 col-12 mb-3">
                {/* <div className=" d-none justify-content-center">
                  <div className="d-block mx-2">
                    <div className="d-icon rounded  mb-5 ">
                      <span>
                        <i class="fa fa-twitter fs-3" aria-hidden="true"></i>
                      </span>
                    </div>
                    <div className="d-icon rounded  mb-5">
                      <span>
                        <i class="fa fa-facebook-f fs-3"></i>
                      </span>
                    </div>
                    <div className="d-icon rounded  mb-5">
                      <span>
                        <i class="fa fa-instagram fs-3" aria-hidden="true"></i>
                      </span>
                    </div>
                    <div className="d-icon rounded  ">
                      <span>
                        <i class="fa fa-whatsapp fs-3" aria-hidden="true"></i>
                      </span>
                    </div>
                  </div>
                  <img
                    class="img-fluid w-50"
                    src="\assets\img\images\image_2022_11_21T05_15_15_581Z.png"
                    alt=""
                  />
                </div> */}
                <img
                  class="img-fluid w-75"
                  src="\assets\img\images\image_2022_11_21T05_15_15_581Z.png"
                  alt=""
                />
                <div className="d-flex mt-3">
                  <h5 className="mx-3 text-muted">
                    <i class="fa fa-user" aria-hidden="true"></i> Admin
                  </h5>
                  <h5 className="mx-3 text-muted">
                    <i class="fa fa-calendar" aria-hidden="true"></i> Jul
                    17,2023
                  </h5>
                  <h5 className="mx-3 text-muted">
                    <i class="fa fa-map-marker" aria-hidden="true"></i> London
                  </h5>
                </div>
                <hr />
                <div className="">
                  <p>
                    Save the date for this year’s virtual Google for Games
                    Developer Summit, happening on March 14 at 9 a.m. PT. You’ll
                    hear about product updates and discover new ways to build
                    great games, connect with players around the globe and grow
                    your business.
                  </p>
                  <p>
                    Here are three things you can expect during and after the
                    event:
                  </p>
                  <p className="fw-bold">
                    1. Hear about Google’s newest games products for developers
                  </p>
                  <p>
                    The summit kicks off at 9 a.m. PT, with keynotes from teams
                    across Android, Google Play, Ads and Cloud. They’ll discuss
                    the latest trends in the gaming industry and share new
                    products we’re working on to help developers build great
                    experiences for gamers everywhere.
                  </p>
                  <p className="fw-bold">
                    2. Learn how to grow your games business in on-demand
                    sessions
                  </p>
                  <p>
                    Following the keynotes, more than 15 on-demand sessions will
                    be available starting at 10 a.m. PT, where you can learn
                    more about upcoming products, watch technical deep dives and
                    hear inspiring stories from other game developers. Whether
                    you’re looking to expand your reach, reduce cheating or
                    better understand in-game ad formats, there will be plenty
                    of content to help you take your game to the next level.
                  </p>
                  <p className="fw-bold">
                    3. Join us at the Game Developers Conference{" "}
                  </p>
                  <p>
                    If you’re looking for even more gaming content after the
                    summit, join us in person for the Game Developers Conference
                    in San Francisco. We’ll host developer sessions on March 20
                    and 21 to share demos, technical best practices and more.
                  </p>
                  <p>
                    Visit g.co/gamedevsummit to learn more and get updates about
                    both events, including the full agendas. See you there!
                  </p>
                </div>
                <div className="my-2">
                  <h4>LEAVE A COMMENTS</h4>
                  <textarea
                    placeholder="Type your comment here.."
                    className="border border "
                  ></textarea>
                  <div className="mt-2 d-flex ">
                    <input
                      type="text"
                      placeholder="Your Name.."
                      className=" border border"
                    />
                    <input
                      type="text"
                      placeholder="Your Email.."
                      className="mx-2 border border"
                    />
                    <input
                      type="text"
                      placeholder="Your Website.."
                      className=" border border"
                    />
                  </div>
                </div>
                <div className="">
                  <button className=" mt-3 btn btn-outline-primary ">
                    POST COMMENTS
                  </button>
                </div>
              </div>
              <div className="d-2  col-lg-4 col-md-6 col-12 mb-3">
                <h4>Search</h4>
                <hr />
                <input
                  type="text"
                  placeholder="Type Keyword here"
                  className="mb-4"
                />
                <div
                  class="card border border shadow-sm mb-3 "
                  // style={{ width: "400px" }}
                >
                  <div class="card-header ">Recent Posts</div>
                  <div class="card-body text-secondary">
                    <ul>
                      <li className="">
                        <div class="card mb-2">
                          <div class="row g-0">
                            <div class="col-4">
                              <img
                                src="\assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                                class="img-fluid rounded-start h-100 w-100"
                                alt="..."
                              />
                            </div>
                            <div class="col-8">
                              <div class="card-body">
                                <p class="card-text text-truncate">
                                  This is a wider card with supporting text
                                </p>
                                <small class="text-muted">
                                  Last updated 3 mins ago
                                </small>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li className="">
                        <div class="card mb-3">
                          <div class="row g-0">
                            <div class="col-4">
                              <img
                                src="\assets\img\images\image_2022_11_21T05_17_27_658Z.png"
                                class="img-fluid rounded-start h-100 w-100 "
                                alt="..."
                              />
                            </div>
                            <div class="col-8">
                              <div class="card-body ">
                                <p class="card-text text-truncate">
                                  This is a wider card with supporting text
                                </p>
                                <small class="text-muted ">
                                  Last updated 3 mins ago
                                </small>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div
                  class="card border border shadow-sm mb-3"
                  // style={{ width: "400px" }}
                >
                  <div class="card-header">Categories</div>
                  <div class="card-body text-secondary">
                    <h5 class="card-title mb-3">Secondary List</h5>
                    <ul>
                      <li className="mb-3">itex</li>
                      <li className="mb-3">new</li>
                      <li className="mb-3">technical</li>
                      <li className="mb-3">tips & tricks</li>
                      <li className="mb-3">Web</li>
                    </ul>
                  </div>
                </div>
                <div
                  class="card border border shadow-sm mb-3 "
                  // style={{ width: "400px" }}
                >
                  <div class="card-header">SOCIAL</div>
                  <div class="card-body text-secondary">
                    <div className="d-flex ">
                      <div className="d-icon rounded  mx-3 ">
                        <span>
                          <i class="fa fa-twitter fs-3" aria-hidden="true"></i>
                        </span>
                      </div>
                      <div className="d-icon rounded   mx-3 ">
                        <span>
                          <i class="fa fa-facebook-f fs-3"></i>
                        </span>
                      </div>
                      <div className="d-icon rounded  mx-3 ">
                        <span>
                          <i
                            class="fa fa-instagram fs-3"
                            aria-hidden="true"
                          ></i>
                        </span>
                      </div>
                      <div className="d-icon rounded  mx-3 ">
                        <span>
                          <i class="fa fa-whatsapp fs-3" aria-hidden="true"></i>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="card border border shadow-sm mb-3 "
                  // style={{ width: "400px" }}
                >
                  <div class="card-header">Popular tags</div>
                  <div class="card-body text-secondary">
                    <button type="button" class="btn btn-outline-secondary m-1">
                      technical
                    </button>
                    <button type="button" class="btn btn-outline-secondary m-1">
                      technical
                    </button>
                    <button type="button" class="btn btn-outline-secondary m-1">
                      technical
                    </button>
                    <button type="button" class="btn btn-outline-secondary m-1">
                      tech
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};
export default Blog;
