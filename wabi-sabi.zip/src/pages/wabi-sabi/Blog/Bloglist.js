import React from "react";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import { useLocation,useNavigate,Link} from "react-router-dom";

const BlogList = () => {
  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>
      <section id="blog">
        <div className="container">
          <div className="row">
            <div className="col-3">
              <div class="card" >
                <img
                  class="card-img-top"
                  src="\assets\img\images\image_2022_11_21T05_15_15_581Z.png"
                  alt="Card image cap"
                />
                <div class="card-body">
                  <h5 class="card-title">Arnold</h5>
                  <p class="text-muted">Last updated 3 mins ago</p>

                  <p class="card-text complete">
                    Some quick example text to build on the card title and make
                    up the bulk of the card's content.
                  </p>
                  <Link to='/blog' class="btn btn-primary">Read More..</Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};
export default BlogList;
