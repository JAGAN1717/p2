import React, { useState, useEffect } from "react";
// import axios from "axios";

import Header from "./Header/Header";
import Footer from "./Footer/Footer";

const Faceback = () => {
  return (
    <>
      <div className="head-fixed">
        <Header />
      </div>
      <section id="feedback">
        <div className="container">
          <h5 className="mb-5 mt-5 head-path1 d-lg-block d-md-block d-none">
            <a href="#">Profile</a> / <a href="#">Return Policy</a>
          </h5>

          <h5 className="text-center mb-4">Feedback</h5>
          <div className="Feedback mb-5">
            <p className="fw-light">
              People are often hesitant to buy online, which can lead to low
              conversion rates and sales. Return and refund policies for
              ecommerce stores have been proven to increase the number of people
              who end up making a purchase once they're on your website.
            </p>
            <p className="fw-light">
              Perhaps more importantly, however, having a Return and Refund
              Policy in place can help reduce your expenses when it comes to
              return deliveries. For instance, consider the fact that in the
              United States alone, Statista's most up-to-date statistics show
              that return deliveries cost businesses ₹550 Billion between 2016
              and 2020. That's a 75.2% increase over five years ago.
            </p>
            <p className="fw-light">
              Of course, customers may be unhappy with their order for many
              reasons. It might arrive damaged, it was the wrong size or it
              didn't meet all their expectations. They may request a refund or a
              replacement.
            </p>

            <p className="fw-light">
              These requests can be overwhelming without a system to handle
              them. Think of all the time necessary to handle customer service
              emails and the money your company may have to spend to replace the
              returned product. Now think about those expenses just after Black
              Friday or Christmas!
            </p>
            <p className="fw-light">
              Thankfully, the solution is relatively simple. You can make
              returns and exchanges less of a problem by writing and posting a
              solid Return and Refund Policy for your website. Moreover, you can
              help increase customer loyalty and potentially generate new
              revenue by doing so.
            </p>
            <p className="fw-light">
              Evidence shows that eCommerce stores with lower volumes are
              inclined to have lower returns than those with greater volume.
              This may be a result of the fact that more established eCommerce
              businesses tend to have more flexible Return and Refund Policies,
              or because consumers feel less guilty about returning products to
              corporations than they do to small-scale online stores.
            </p>
            <p className="fw-light">
              Regardless of the size of your operations, it can be hard to
              decide the right approach for your business with regard to your
              Return and Refund Policy.
            </p>
            <p className="fw-light">
              Many eCommerce companies can't afford to offer free returns like
              big online retailers. However, that doesn't mean you can't provide
              your customers with a policy they'll appreciate.
            </p>
            <p className="fw-light">
              However, even without laws requiring one, there are still good
              reasons to put a Return and Refund Policy in place.
            </p>

            <p className="fw-light">
              For example, your customers expect to be informed about your
              policies and to know that you'll adhere to terms that have become
              commonplace within the eCommerce industry.
            </p>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Faceback;
