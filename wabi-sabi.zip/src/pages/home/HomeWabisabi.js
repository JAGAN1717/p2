import React from "react";
import '../../assets/css/homeWabisabi.css';
import { Helmet } from "react-helmet-async";
//React bootstrap
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Carousel from 'react-bootstrap/Carousel';
import Card from 'react-bootstrap/Card';

//reat slick slider
import Slider from "react-slick";


const HomeWabisabi = () =>{
  var settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 4,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };
  

    return(
        <>
        {/* header top */}
         <section className="heder-top">
            <div className="head-top p-2" >
                <div className="head-flex ">
                <div class="d-flex justify-content-between container">
                    <div>
                        <span className="text-light"><i class="fa fa-phone" aria-hidden="true"></i> +919876543210</span>
                    </div>
                    <div>
                        <span className="text-white">get Up to 40% OFF New Session Style</span>
                    </div>
                    {/* <div className="row text-white d-none">
                        <div className="col">
                        <div className="social-i rounded-circle">
                        <i class="fa fa-facebook-f "></i>
                        </div>
                        </div>
                        <div className="col">
                        <i class="fa fa-twitter"></i>
                        </div>
                        <div className="col">
                        <i class="fa fa-instagram"></i>
                        </div>
                    </div> */}
                    <span className="text-white social-logo  ">
                        <i class="fa fa-facebook-f mx-2 p-1 rounded-circle"></i>
                        <i class="fa fa-twitter p-1 mx-2 rounded-circle"></i>
                        <i class="fa fa-instagram p-1 mx-2 rounded-circle"></i>
                    </span>
                </div>
                </div>
            </div>
         </section>
         {/* header bottom navbar */}
         <header className="header-buttom">
            <div className="container">
            <Navbar bg="light" expand="lg" className="py-5">
      <Container fluid>
        <Navbar.Brand href="#" id="nav-brand">
          <img src="/assets/img/logo/WABI SABI LOGO 2.png"/>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            <NavDropdown title="Men" id="navbarScrollingDropdown" >
              <NavDropdown.Item href="#action3">1</NavDropdown.Item>
              <NavDropdown.Item href="#action4">2</NavDropdown.Item>
            </NavDropdown>
            <NavDropdown title="Women" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#action3">1</NavDropdown.Item>
              <NavDropdown.Item href="#action4">2</NavDropdown.Item>
            </NavDropdown>
            <NavDropdown title="Kids" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#action3">1</NavDropdown.Item>
              <NavDropdown.Item href="#action4">2</NavDropdown.Item>
            </NavDropdown>
            <NavDropdown title="Homes & Livings" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#action3">1</NavDropdown.Item>
              <NavDropdown.Item href="#action4">2</NavDropdown.Item>
            </NavDropdown>
            <NavDropdown title="Beauty" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#action3">1</NavDropdown.Item>
              <NavDropdown.Item href="#action4">2</NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
        <div className="d-flex serchbox">
          <input type='text' placeholder="search..." />
          <button type="submit" className="searchButton">
          <i class="fa fa-search"></i>
         </button>
        </div>
          <div className="d-flex sh-i">
          <i class="fa fa-shopping-cart mx-4" aria-hidden="true"></i>
          <i class="fa fa-user mx-4" aria-hidden="true" ></i>
          </div>
      </Container>
    </Navbar>
            </div>
         </header>

         {/* category section */}

         <section className="category-clothes">
          <div className="container">
            <div className="text-head">
            <Row className="justify-content-center  ">
              <Col lg='3' md='3' sm='3' xs='3' >
              <div className="d-flex mx-4">
                <img src='/assets/img/Icons/Imported_Cloths.svg'/>
              <h4 className="">Imported<br/>Clothes</h4>
                </div>
                </Col>
                <Col lg='3' md='3' sm='3' xs='3'>
              <div className="d-flex  mx-4">
                <img src='/assets/img/Icons/Free_Shipping.svg'/>
              <h4 className="">Free<br/>Shipping</h4>
                </div>
                </Col>
                <Col lg='3' md='3' sm='3' xs='3'>
              <div className="d-flex  mx-4">
                <img src='/assets/img/Icons/Easy Return.svg'/>
              <h4 className="">Easy<br/>Returns</h4>
                </div>
                </Col>
                <Col lg='3' md='3' sm='3' xs='3'>
              <div className="d-flex  mx-4">
                <img src='/assets/img/Icons/Quality Ass.svg'/>
              <h4 className="">Quality<br/>Assuarance</h4>
                </div>
                </Col>
            </Row>
            <div class="d-none justify-content-between">
            <div className="d-flex mx-4">
                <img src='/assets/img/Icons/Imported_Cloths.svg' className="img-fluid"/>
              <h4 className="mx-4">Imported<br/>Clothes</h4>
                </div>
                <div className="d-flex  mx-4">
                <img src='/assets/img/Icons/Free_Shipping.svg'/>
              <h4 className="mx-4">Free<br/>Shipping</h4>
                </div>
                <div className="d-flex  mx-4">
                <img src='/assets/img/Icons/Easy Return.svg'/>
              <h4 className="mx-4">Easy<br/>Returns</h4>
                </div>
                <div className="d-flex  mx-4">
                <img src='/assets/img/Icons/Quality Ass.svg'/>
              <h4 className="mx-4">Quality<br/>Assuarance</h4>
                </div>
            </div>
            </div>
         <div className="collection-i mt-5">
          <Row className="justify-content-md-center">
            <Col lg='4' md='4' sm='4' xs='4'>
              <div className="banner-grid">
                <img  src='/assets/img/images/image_2022_11_21T05_15_03_256Z.png'/>
                <div className='mask' style={{ backgroundColor: 'rgba(0, 0, 0, 0.6)' }}>
               <div className='d-flex justify-content-center align-items-center h-100'>
                <p className='text-white mb-0'>SUSTAINABILITY</p>
                </div></div>
         
              </div>
            </Col>
            <Col lg='8' md='8' sm='8' xs='8'>
            <div className="banner-grid bg-image">
                <img  src='/assets/img/images/image_2022_11_21T05_15_11_873Z.png' className="img-fluid"/>
              </div>
            </Col>
          </Row>
          <Row className="mt-4">
            <Col lg='4' md='4' sm='4' xs='4'>
              <div className="banner-grid">
                <img src="/assets/img/images/image_2022_11_21T05_15_15_581Z.png"/>
              </div>
            </Col>
            <Col lg='4' md='4' sm='4' xs='4'>
            <div className="banner-grid">
                <img src="/assets/img/images/image_2022_11_21T05_15_18_958Z.png"/>
              </div>
            </Col>
            <Col lg='4' md='4' sm='4' xs='4'>
            <div className="banner-grid">
                <img src="/assets/img/images/image_2022_11_21T05_15_21_895Z.png"/>
              </div>
            </Col>
          </Row>
         </div> 
         </div>
         </section>

         {/* trending product */}
         <section className="trending-products ">
          <div className="container">
            <div className="trend-prod mt-5">
            <div className="text-center py-5">
              <h3>Tranding Products</h3>
            </div>
            <div className="d-none">
        <h2> Responsive </h2>
        <Slider {...settings}>
          <div>
          <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_33_181Z.png" />
      <Card.Body className="text-center" >
        <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card> 
          </div>
          <div>
          <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_33_181Z.png" />
      <Card.Body className="text-center" >
        <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card> 
          </div>
          <div>
          <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_33_181Z.png" />
      <Card.Body className="text-center" >
        <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card> 
          </div>
          <div>
          <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_33_181Z.png" />
      <Card.Body className="text-center" >
        <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card> 
          </div>
          <div>
          <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_33_181Z.png" />
      <Card.Body className="text-center" >
        <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card> 
          </div>
          <div>
          <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_33_181Z.png" />
      <Card.Body className="text-center" >
        <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card> 
          </div>
        </Slider>
      </div>

 <div id="carouselExampleControls" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-inner ">
    <div class="carousel-item active d-flex mb-5">
    <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_33_181Z.png" />
      <Card.Body className="text-center" >
        <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card>  
    <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_35_946Z.png" />
      <Card.Body  className="text-center" >
      <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card>  
    <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_38_928Z.png" />
      <Card.Body  className="text-center" >
      <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card>  
    <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_41_505Z.png" />
      <Card.Body  className="text-center" >
      <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card>  
    <Card id='card' >
      <Card.Img variant="top" src="/assets/img/images/image_2022_11_21T05_15_44_210Z.png" />
      <Card.Body  className="text-center" >
      <h4>Zara Tops</h4>
        <h4>$1000</h4>
        <h4 className="text-danger">Size-M</h4>
      </Card.Body>
    </Card>  
    </div>
    <div class="carousel-item">
  
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

            </div>
          </div>
         </section>

         {/* Feature Brands  */}
        <section className="feature-Brand">
          <div className="container">
          <div className="text-center py-5">
              <h3>Feature Brands</h3>
            </div>
            <Row>
              <Col><div className="brand"> <img src="/assets/img/images/.png"/></div></Col>
              <Col><div className="brand"> <img src="/assets/img/images/.png"/></div></Col>
              <Col><div className="brand"> <img src="/assets/img/images/.png"/></div></Col>
              <Col><div className="brand"> <img src="/assets/img/images/.png"/></div></Col>
              <Col><div className="brand"> <img src="/assets/img/images/.png"/></div></Col>
              <Col><div className="brand"> <img src="/assets/img/images/.png"/></div></Col>
              <Col><div className="brand"> <img src="/assets/img/images/.png"/></div></Col>
            </Row>
          </div>
        </section>

        {/* Wabi  Sabi Environmental impact */}
        <section  className="Envir-imp">
          <div className="container">
          <div className="text-center py-5">
              <h3>Wabi Sabi Environmental Impact</h3>
            </div>

            <div className="d-flex ">
              <div className="env"><img src="/assets/img/images/image_2022_11_21T05_16_05_471Z.png"/></div>
              <div className="env"><img src="/assets/img/images/image_2022_11_21T05_16_08_567Z.png"/></div>
              <div className="env"><img src="/assets/img/images/image_2022_11_21T05_16_11_242Z.png"/></div>
              <div className="env"><img src="/assets/img/images/image_2022_11_21T05_16_14_160Z.png"/></div>
            </div>
          </div>
        </section>



        </>
    )
}


export default HomeWabisabi