export default {
    /** Reward point  */
    ADJUSTMENT_EARNED_KEY: 'refund_earned_points',
    RETURN_SPENT_KEY: 'refund_points',
    REWARDPOINTS_EARN: 'rewardpoints_earn',

    EXTENSION_ATTRIBUTES: 'extension_attributes',
}
