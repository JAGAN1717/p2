export default {
    PRE_FIX        : 'wpo_'
}
