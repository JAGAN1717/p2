/**
 * Plugin to update label
 */
export default {
    getPaymentList: {
        payment_offline: {
            sortOrder: 100,
            disabled: false,
            before: function (props) {
                let CreditmemoService = require("../../../../../../../../service/sales/order/CreditmemoService");
                let PaymentService = require("../../../../../../../../service/payment/PaymentService");
                let payments = PaymentService.default.getAll();
                let acceptedPaymentMethods = CreditmemoService.default.acceptedPaymentMethods;
                payments.then(data => {
                    data.forEach(function(payment) {
                        if (!payment.is_pay_later && !acceptedPaymentMethods.includes(payment.code)) {
                            acceptedPaymentMethods.push(payment.code);
                        }
                    });
                });
                CreditmemoService.default.acceptedPaymentMethods = acceptedPaymentMethods;
            },
        }
    }
};
