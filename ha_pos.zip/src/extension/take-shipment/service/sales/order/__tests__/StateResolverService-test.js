import StateResolverService from "../StateResolverService";
import OrderService from "../../../../../../service/sales/OrderService";

/**
 *  https://docs.google.com/spreadsheets/d/1t9OxHRxFMlXNrcccrYIb5JCPZhIMT_Sd1Tnv-5PQnBA/edit#gid=146736234
 */
describe('StateResolverService-test-isOrderComplete', () => {
    let data = [
        {
            testCaseId: 'SOSRSIOC01',
            title: '',
            order: {
                state: 'complete',
                base_grand_total: 0,
                total_paid: 0,
                total_refunded: 0,
                adjustment_negative: 0,
                extension_attributes: {}
            },
            expect: true,
        },
        {
            testCaseId: 'SOSRSIOC02',
            title: '',
            order: {
                state: 'canceled',
                base_grand_total: 0,
                total_paid: 0,
                total_refunded: 0,
                adjustment_negative: 0,
                extension_attributes: {},
            },
            expect: true,
        },
        {
            testCaseId: 'SOSRSIOC03',
            title: '',
            order: {
                state: 'closed',
                base_grand_total: 1,
                total_paid: 1,
                total_refunded: 0,
                adjustment_negative: 0,
                extension_attributes: {},
            },
            expect: false,
        },
        {
            testCaseId: 'SOSRSIOC04',
            title: '',
            order: {
                state: 'holded',
                base_grand_total: 1,
                total_paid: 0,
                total_refunded: 0,
                adjustment_negative: 0,
                extension_attributes: {},
            },
            expect: false,
        },
        {
            testCaseId: 'SOSRSIOC05',
            title: '',
            order: {
                state: 'payment_review',
                base_grand_total: 1,
                total_paid: 0,
                total_refunded: 0,
                adjustment_negative: 0,
                extension_attributes: {},
            },
            expect: false,
        },
        {
            testCaseId: 'SOSRSIOC06',
            title: '',
            order: {
                state: 'complete',
                base_grand_total: 1,
                total_paid: 1,
                total_refunded: 1,
                adjustment_negative: 0,
                extension_attributes: {},
            },
            expect: false,
        },
        {
            testCaseId: 'SOSRSIOC07',
            title: '',
            order: {
                state: 'complete',
                base_grand_total: 2,
                total_paid: 2,
                total_refunded: 1,
                adjustment_negative: 0,
                extension_attributes: {},
            },
            expect: true,
        },
        {
            testCaseId: 'SOSRSIOC08',
            title: '',
            order: {
                state: 'complete',
                base_grand_total: 2,
                total_paid: 2,
                total_refunded: 1,
                adjustment_negative: 1,
                extension_attributes: {},
            },
            expect: false,
        },
    ];

    data.forEach(testCase => {
        it(`[${testCase.testCaseId}] ${testCase.title}`, () => {
            let isOrderComplete = StateResolverService.isOrderComplete(testCase.order);
            expect(isOrderComplete).toBe(testCase.expect)
        })
    })
});
describe('StateResolverService-test-isOrderClosed', () => {
    let data = [
        {
            testCaseId: 'SOSRSIOC201',
            title: '',
            order: {
                total_refunded: 0,
            },
            Arguments: [],
            expect: false,
        },
        {
            testCaseId: 'SOSRSIOC202',
            title: '',
            order: {
                total_refunded: 1,
            },
            Arguments: [],
            expect: true,
        },
        {
            testCaseId: 'SOSRSIOC203',
            title: '',
            order: {
                total_refunded: 0,
            },
            Arguments: ["forced_creditmemo"],
            expect: true,
        },
        {
            testCaseId: 'SOSRSIOC204',
            title: '',
            order: {
                total_refunded: 1,
            },
            Arguments: ["forced_creditmemo"],
            expect: true,
        },
    ];

    data.forEach(testCase => {
        it(`[${testCase.testCaseId}] ${testCase.title}`, () => {
            let result = StateResolverService.isOrderClosed(testCase.order, testCase.Arguments);
            expect(result).toBe(testCase.expect)
        })
    })
});
describe('StateResolverService-test-isOrderProcessing', () => {
    let data = [
        {
            testCaseId: 'SOSRSIOP01',
            title: '',
            order: {
                state: 'new',
            },
            Arguments: ["order_in_progress"],
            expect: true,
        },
        {
            testCaseId: 'SOSRSIOP02',
            title: '',
            order: {
                state: 'new',
            },
            Arguments: [],
            expect: false,
        },
        {
            testCaseId: 'SOSRSIOP03',
            title: '',
            order: {
                state: 'complete',
            },
            Arguments: ["order_in_progress"],
            expect: false,
        },
        {
            testCaseId: 'SOSRSIOP04',
            title: '',
            order: {
                state: 'complete',
            },
            Arguments: [],
            expect: false,
        },
    ];

    data.forEach(testCase => {
        it(`[${testCase.testCaseId}] ${testCase.title}`, () => {
            let result = StateResolverService.isOrderProcessing(testCase.order, testCase.Arguments);
            expect(result).toBe(testCase.expect)
        })
    })
});
describe('StateResolverService-test-getInitialOrderState', () => {
    let data = [
        {
            testCaseId: 'SOSRSGIOS01',
            title: '',
            order: {
                state: 'processing',
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGIOS02',
            title: '',
            order: {
                state: 'new',
            },
            expect: 'new',
        },
        {
            testCaseId: 'SOSRSGIOS03',
            title: '',
            order: {
                state: 'complete',
            },
            expect: 'new',
        },
        {
            testCaseId: 'SOSRSGIOS04',
            title: '',
            order: {
                state: 'canceled',
            },
            expect: 'new',
        },
        {
            testCaseId: 'SOSRSGIOS05',
            title: '',
            order: {
                state: 'closed',
            },
            expect: 'new',
        },
    ];

    data.forEach(testCase => {
        it(`[${testCase.testCaseId}] ${testCase.title}`, () => {
            let result = StateResolverService.getInitialOrderState(testCase.order);
            expect(result).toBe(testCase.expect)
        })
    })
});
describe('StateResolverService-test-getStatusForOrderByState', () => {
    let data = [
        {
            testCaseId: 'SOSRSGSFOBS01',
            title: '',
            order: {
                state: 'new',
            },
            expect: 'pending',
        },
        {
            testCaseId: 'SOSRSGSFOBS02',
            title: '',
            order: {
                state: 'processing',
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFOBS03',
            title: '',
            order: {
                state: 'complete',
            },
            expect: 'complete',
        },
        {
            testCaseId: 'SOSRSGSFOBS04',
            title: '',
            order: {
                state: 'closed',
            },
            expect: 'closed',
        },
        {
            testCaseId: 'SOSRSGSFOBS05',
            title: '',
            order: {
                state: 'canceled',
            },
            expect: 'canceled',
        },
        {
            testCaseId: 'SOSRSGSFOBS06',
            title: '',
            order: {
                state: 'holded',
            },
            expect: 'holded',
        },
        {
            testCaseId: 'SOSRSGSFOBS07',
            title: '',
            order: {
                state: 'payment_review',
            },
            expect: 'payment_review',
        },
    ];

    data.forEach(testCase => {
        it(`[${testCase.testCaseId}] ${testCase.title}`, () => {
            let result = StateResolverService.getStatusForOrderByState(testCase.order.state);
            expect(result).toBe(testCase.expect)
        })
    })
});
describe('StateResolverService-test-getStateForOrder', () => {
    let mock = {};

    beforeAll(() => {
        mock.isOrderComplete = StateResolverService.isOrderComplete;
        OrderService.isOrderComplete = jest.fn(() => testCase.mock.self.isOrderComplete);
        mock.isOrderClosed = StateResolverService.isOrderClosed;
        OrderService.isOrderClosed = jest.fn(() => testCase.mock.self.isOrderClosed);
        mock.isOrderProcessing = StateResolverService.isOrderProcessing;
        OrderService.isOrderProcessing = jest.fn(() => testCase.mock.self.isOrderProcessing);


        mock.canUnhold = OrderService.canUnhold;
        OrderService.canUnhold = jest.fn(() => testCase.mock.OrderService.canUnhold);
        mock.isPaymentReview = OrderService.isPaymentReview;
        OrderService.isPaymentReview = jest.fn(() => testCase.mock.OrderService.isPaymentReview);
        mock.isCanceled = OrderService.isCanceled;
        OrderService.isCanceled = jest.fn(() => testCase.mock.OrderService.isCanceled);
        mock.canShip = OrderService.canShip;
        OrderService.canShip = jest.fn(() => testCase.mock.OrderService.canShip);
    });

    afterAll(() => {
        StateResolverService.isOrderComplete =  mock.isOrderComplete;
        StateResolverService.isOrderClosed =  mock.isOrderClosed;
        StateResolverService.isOrderProcessing =  mock.isOrderProcessing;

        OrderService.canUnhold =  mock.canUnhold;
        OrderService.isPaymentReview = mock.isPaymentReview;
        OrderService.isCanceled = mock.isCanceled;
        OrderService.canShip = mock.canShip
    });

    let data = [
        {
            testCaseId: 'SOSRSGSFO01',
            title: '',
            order: {
                state: 'new',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO02',
            title: '',
            order: {
                state: 'new',
            },
            mock: {
                OrderService: {
                    isCanceled: false,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO03',
            title: '',
            order: {
                state: 'new',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: false,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO04',
            title: '',
            order: {
                state: 'new',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: false,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO05',
            title: '',
            order: {
                state: 'new',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: false,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO06',
            title: '',
            order: {
                state: 'new',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: false,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO07',
            title: '',
            order: {
                state: 'new',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: false,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO08',
            title: '',
            order: {
                state: 'new',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: false,
                }
            },
            expect: 'new',
        },

        {
            testCaseId: 'SOSRSGSFO09',
            title: '',
            order: {
                state: 'processing',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO10',
            title: '',
            order: {
                state: 'processing',
            },
            mock: {
                OrderService: {
                    isCanceled: false,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO11',
            title: '',
            order: {
                state: 'processing',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: false,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO12',
            title: '',
            order: {
                state: 'processing',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: false,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO13',
            title: '',
            order: {
                state: 'processing',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: false,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO14',
            title: '',
            order: {
                state: 'processing',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: false,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO15',
            title: '',
            order: {
                state: 'processing',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: false,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO16',
            title: '',
            order: {
                state: 'processing',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: false,
                }
            },
            expect: 'processing',
        },

        {
            testCaseId: 'SOSRSGSFO17',
            title: '',
            order: {
                state: 'payment_review',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO18',
            title: '',
            order: {
                state: 'payment_review',
            },
            mock: {
                OrderService: {
                    isCanceled: false,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO19',
            title: '',
            order: {
                state: 'payment_review',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: false,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO20',
            title: '',
            order: {
                state: 'payment_review',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: false,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO21',
            title: '',
            order: {
                state: 'payment_review',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: false,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO22',
            title: '',
            order: {
                state: 'payment_review',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: false,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO23',
            title: '',
            order: {
                state: 'payment_review',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: false,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO24',
            title: '',
            order: {
                state: 'payment_review',
            },
            mock: {
                OrderService: {
                    isCanceled: true,
                    canUnhold: true,
                    canInvoice: true,
                    canShip: true,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: true,
                    isOrderProcessing: false,
                }
            },
            expect: 'new',
        },

        {
            testCaseId: 'SOSRSGSFO25',
            title: '',
            order: {
                state: 'closed',
            },
            mock: {
                OrderService: {
                    isCanceled: false,
                    canUnhold: false,
                    canInvoice: false,
                    canShip: false,
                },
                self: {
                    isOrderComplete: false,
                    isOrderClosed: true,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO26',
            title: '',
            order: {
                state: 'complete',
                items: [],
            },
            mock: {
                OrderService: {
                    isCanceled: false,
                    canUnhold: false,
                    canInvoice: false,
                    canShip: false,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: false,
                    isOrderProcessing: true,
                }
            },
            expect: 'processing',
        },
        {
            testCaseId: 'SOSRSGSFO27',
            title: '',
            order: {
                state: 'closed',
            },
            mock: {
                OrderService: {
                    isCanceled: false,
                    canUnhold: false,
                    canInvoice: false,
                    canShip: false,
                },
                self: {
                    isOrderComplete: false,
                    isOrderClosed: true,
                    isOrderProcessing: false,
                }
            },
            expect: 'closed',
        },
        {
            testCaseId: 'SOSRSGSFO28',
            title: '',
            order: {
                state: 'complete',
                items: [],
            },
            mock: {
                OrderService: {
                    isCanceled: false,
                    canUnhold: false,
                    canInvoice: false,
                    canShip: false,
                },
                self: {
                    isOrderComplete: true,
                    isOrderClosed: false,
                    isOrderProcessing: false,
                }
            },
            expect: 'complete',
        },
    ];

    data.forEach(testCase => {
        it(`[${testCase.testCaseId}] ${testCase.title}`, () => {
            StateResolverService.isOrderComplete = jest.fn(() => testCase.mock.self.isOrderComplete);
            StateResolverService.isOrderClosed = jest.fn(() => testCase.mock.self.isOrderClosed);
            StateResolverService.isOrderProcessing = jest.fn(() => testCase.mock.self.isOrderProcessing);

            OrderService.canUnhold = jest.fn(() => testCase.mock.OrderService.canUnhold);
            OrderService.isPaymentReview = jest.fn(() => testCase.mock.OrderService.isPaymentReview);
            OrderService.isCanceled = jest.fn(() => testCase.mock.OrderService.isCanceled);
            OrderService.canShip = jest.fn(() => testCase.mock.OrderService.canShip);
            let result = StateResolverService.getStateForOrder(testCase.order);
            expect(result).toBe(testCase.expect)
        })
    })
});