export default {
    payment: {
        title: 'Stripe Verifone P400',
        amount_paid: 1
    }
};
