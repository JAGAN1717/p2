const StripeTerminal = window.StripeTerminal || { create: () => {} };
export default StripeTerminal;