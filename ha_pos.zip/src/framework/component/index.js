export { default as CoreComponent } from './CoreComponent';
