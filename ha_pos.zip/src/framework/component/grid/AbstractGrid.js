import AbstractList from '../list/AbstractList';

export default class AbstractGrid extends AbstractList {
}