import {Component} from 'react';

export default class DataAbstract extends Component {
    // constructor(props) {
    //     super(props);
    // }
}