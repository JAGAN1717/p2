export default {
    empty: () => {
        return {
            type: 'EMPTY'
        }
    }
}

