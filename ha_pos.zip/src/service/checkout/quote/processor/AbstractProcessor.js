export class AbstractProcessor {
    static className = 'AbstractProcessor';

    execute() {

    }
}